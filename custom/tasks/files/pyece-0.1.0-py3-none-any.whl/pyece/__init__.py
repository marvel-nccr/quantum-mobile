"""pyeCE: Embedded cluster expansions made easy."""

__version__ = "0.1.0"
