"""Allow running pyeCE as ``python -m pyece``."""

from pyece.cli.ece import main

main()
