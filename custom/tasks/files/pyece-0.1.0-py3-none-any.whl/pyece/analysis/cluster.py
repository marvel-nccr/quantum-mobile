from __future__ import annotations

import json

import numpy as np
import torch
from numpy.typing import NDArray
from pymatgen.core import Structure

from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.core.prim import Prim
from pyece.utils.mapping import check_pass, ideal_map


class Cluster:
    """
    Object to investigate the average density of appearance for all clusters for all orbits.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    structure: Structure
        Pymatgen structure to evaluate the SRO from. An ideal structure is expected.
    cutoffs: list[float], default: [0, 0, 4]
        List with the nth value corresponds to the cutoff radius for clusters of nth body-order.
    density: bool, default: True
        Set to True to return a probability for a given cluster to appear.
    reduce: bool, default: True
        Set to True to compute the mean and standard deviation of each SRO among all occupations.

    Returns
    -------
    cluster_dict: dict
        Dictionary containing the average density of appearance for all clusters for all orbits.
    """

    def __init__(
        self,
        prim: Prim,
        structure: Structure,
        cutoffs: list[float] = [0.0, 0.0, 4.0],
        density: bool = True,
        reduce: bool = True,
    ) -> None:
        self.model = construct_occupation_model(prim, cutoffs)
        self.model.prod()
        self.transfo_dict = construct_transfo(self.model)
        self.config = Config.from_structure(
            structure,
            self.model.prim,
            list_try_maps=[ideal_map],
            list_checks=[check_pass],
        )
        self.density: bool = density
        self.reduce: bool = reduce
        return

    def __call__(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the cluster densities of occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        density_dict: dict
            Dictionary containing the cluster density for each orbit.
        """
        elements = self.model.prim.elements
        density_dict_unprocessed = self.compute_densities(occupations)
        density_dict = {}
        for orbit in density_dict_unprocessed:
            if "Orbit_1_" in orbit:
                continue
            dims = [
                len(ls_species)
                for ls_species in density_dict_unprocessed[orbit]["species"]
            ]
            if (
                self.reduce
                and (occupations is not None)
                and (len(occupations.shape) > 1)
            ):
                densities = (
                    np.stack(
                        [
                            density_dict_unprocessed[orbit]["densities"].mean(axis=0),
                            density_dict_unprocessed[orbit]["densities"].std(
                                axis=0, ddof=1
                            ),
                        ]
                    )
                    .reshape(-1, np.prod(dims))
                    .T.tolist()
                )
            else:
                densities = (
                    density_dict_unprocessed[orbit]["densities"]
                    .reshape(-1, np.prod(dims))
                    .T.tolist()
                )
            for ind, species_indexes in enumerate(
                self.transfo_dict[orbit]["species_in_clusters"].reshape(
                    np.prod(dims), -1
                )
            ):
                key = "-".join(elements[species_indexes]) + "_(%s)" % orbit
                density_dict[key] = densities[ind]
        return density_dict

    def Warren_Cowley_SRO(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the Warren-Cowley cluster short-range order parameter (SRO) of occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        density_dict: dict
            Dictionary containing the cluster SRO for each orbit.
        """
        is_density = bool(self.density)
        self.density = True
        elements = self.model.prim.elements
        density_dict = self.compute_densities(occupations)
        self.density = is_density

        # Compositions
        compositions = np.zeros(
            [len(elements), len(density_dict["Orbit_1_0"]["densities"])]
        )
        for orbit in density_dict:
            if "Orbit_1_" not in orbit:
                continue
            compositions[density_dict[orbit]["species"][0]] = density_dict[orbit][
                "densities"
            ].T

        # SRO
        sro_dict = {}
        for orbit in density_dict:
            if "Orbit_1_" in orbit:
                continue
            dims = [len(ls_species) for ls_species in density_dict[orbit]["species"]]
            mean_densities = (
                compositions[self.transfo_dict[orbit]["species_in_clusters"]]
                .prod(axis=-2)
                .reshape(np.prod(dims), -1)
            )
            densities = density_dict[orbit]["densities"].reshape(-1, np.prod(dims)).T
            sro = 1 - np.divide(
                densities,
                mean_densities,
                out=np.ones_like(mean_densities),
                where=mean_densities > 0,
            )

            if (
                self.reduce
                and (occupations is not None)
                and (len(occupations.shape) > 1)
            ):
                sro_list = (
                    np.stack(
                        [
                            sro.mean(axis=0),
                            sro.std(axis=0, ddof=1),
                        ]
                    )
                    .reshape(-1, np.prod(dims))
                    .T.tolist()
                )
            else:
                sro_list = sro.tolist()
            for ind, species_indexes in enumerate(
                self.transfo_dict[orbit]["species_in_clusters"].reshape(
                    np.prod(dims), -1
                )
            ):
                key = "-".join(elements[species_indexes]) + "_(%s)" % orbit
                sro_dict[key] = sro_list[ind]
        return sro_dict

    def compute_densities(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the cluster densities of occupations.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        density_dict: dict
            Dictionary containing dictionaries with the species and associated SRO for each orbit.
        """
        density_dict = {
            orbit: {
                "species": self.transfo_dict[orbit]["available_species"],
                "densities": [],
            }
            for orbit in self.transfo_dict
        }
        if occupations is None:
            occupations_tensor = self.config.occupation.reshape(1, -1)
        else:
            occupations_tensor = torch.tensor(occupations).int()
        if len(occupations_tensor.shape) == 1:
            occupations_tensor = occupations_tensor.reshape(1, -1)

        for occup in occupations_tensor:
            self.config.occupation = occup
            correlation_functions = self.model.get_averaged_correlations(
                self.config.get_neighborhood_occupations()
            ).numpy(force=True)
            for orbit, __ in self.transfo_dict.items():
                densities = (
                    self.transfo_dict[orbit]["permutation_factor"]
                    * correlation_functions[
                        self.transfo_dict[orbit]["correlation_functions_indexes"]
                    ]
                )
                if self.density:
                    densities /= densities.sum()
                density_dict[orbit]["densities"].append(densities)
        for orbit in density_dict:
            density_dict[orbit]["densities"] = np.stack(
                density_dict[orbit]["densities"], axis=0
            )
        return density_dict


def construct_occupation_model(
    prim: Prim, cutoffs: list[float] = [0.0, 0.0, 4.0]
) -> eCE:
    """
    Constructs a CE linear model to compute the occupation correlation functions of clusters of size smaller or equal to the cutoff radii.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    cutoffs: list[float], default: [0, 0, 4]
        List with the nth value corresponds to the cutoff radius for clusters of nth body-order.

    Returns
    -------
    eCE
        Linear eCE model to compute correlation functions.
    """

    # Construct a new Prim object with one dummy specie Zzz
    prim_dict = json.dumps(prim.as_dict())
    prim_dict = json.loads(prim_dict)
    prim_dict["occupancy"]["elements"] += ["Zzz"]
    for site, ls in enumerate(prim_dict["occupancy"]["elements_per_site"]):
        if len(ls) > 1:
            prim_dict["occupancy"]["elements_per_site"][site] = ["Zzz"] + prim_dict[
                "occupancy"
            ]["elements_per_site"][site]
    for site, ls in enumerate(
        prim_dict["occupancy"]["wyckoff_sites"]["allowed_elements"]
    ):
        if len(ls) > 1:
            prim_dict["occupancy"]["wyckoff_sites"]["allowed_elements"][site] = [
                "Zzz"
            ] + prim_dict["occupancy"]["wyckoff_sites"]["allowed_elements"][site]
    new_prim = Prim.from_dict(prim_dict)

    # Occupational linear CE
    settings = {
        "basis": "occupational",
        "orbit_tree_specs": {
            "orbit_tree_length_filter": {
                str(bo): {"min_length": 0, "max_length": cutoff}
                for bo, cutoff in enumerate(cutoffs)
            }
        },
        "embedding_dimensions": 0,
        "nn_layers": [],
        "normalization": False,
        # "globally_invariant": True,
    }
    return eCE.from_settings(settings, prim=new_prim, verbose=False)


def construct_transfo(model: eCE) -> dict:
    """
    Constructs the the tranformation matrix to obtain the number of clusters for each orbit.

    Parameters
    ----------
    model: eCE
        Occupation eCE model to compute occupation correlation functions.

    Returns
    -------
    dict_transformations: dict[dict]
        Dioctionary of dictionaries containing the indexes of the species involved in the cluster probabilities, the species indexes, and the permutation factors, and the correlation functions indexes for each cluster.
    """

    model.prod()
    basis = model.sitebasis.sitebasis_functions.numpy(force=True)
    basis[0] = 0
    orbit_tracker = model.features.orbit_tracker()
    sitebasis_indexes, species_indexes = np.nonzero(np.abs(basis - 1) < 1e-6)
    elements = model.prim.elements
    sitebasis_species_lookup = np.full(len(elements), -1, dtype=int)
    sitebasis_species_lookup[sitebasis_indexes] = species_indexes

    # Loop over geometrical orbits
    dict_transformations = {}
    sitebasis_selection_matrix = model.features.selection_matrix.numpy(force=True)[:, 1]
    for orbit in orbit_tracker:
        if "Orbit_0_" in orbit:
            continue
        orbit_indexes = np.array(orbit_tracker[orbit])
        body_order = int(orbit.split("_")[1])

        # Correlation functions
        list_function_sitebasis_indexes: list[np.ndarray] = []
        list_number_permutations: list[int] = []
        list_correlation_function_indexes: list[int] = []
        for index in orbit_indexes:
            start = model.features.symmetrization_segment_indexes[index]
            end = model.features.symmetrization_segment_indexes[index + 1]
            function_sitebasis_indexes = np.unique(
                sitebasis_selection_matrix[start:end], axis=0
            )[:, :body_order]
            list_function_sitebasis_indexes.append(function_sitebasis_indexes)
            list_number_permutations += [len(function_sitebasis_indexes)] * len(
                function_sitebasis_indexes
            )
            list_correlation_function_indexes += [index] * len(
                function_sitebasis_indexes
            )
        arr_function_sitebasis_indexes = np.vstack(
            list_function_sitebasis_indexes, dtype=int
        )
        arr_number_permutations = np.array(list_number_permutations, dtype=int)
        arr_correlation_function_indexes = np.array(
            list_correlation_function_indexes, dtype=int
        )
        cluster_species_indexes = sitebasis_species_lookup[
            arr_function_sitebasis_indexes
        ]

        # Density matrix
        list_available_species = [
            np.unique(cluster) for cluster in cluster_species_indexes.T
        ]
        dims = [len(ls_species) for ls_species in list_available_species]
        arg = np.lexsort(cluster_species_indexes[:, ::-1].T)

        cluster_species_indexes = cluster_species_indexes[arg].reshape(
            dims + [body_order]
        )
        list_factors = 1 / arr_number_permutations[arg].reshape(dims)
        arr_correlation_function_indexes = arr_correlation_function_indexes[
            arg
        ].reshape(dims)
        dict_transformations[orbit] = {
            "available_species": list_available_species,
            "species_in_clusters": cluster_species_indexes,
            "permutation_factor": list_factors,
            "correlation_functions_indexes": arr_correlation_function_indexes,
        }
    return dict_transformations
