import matplotlib.pyplot as plt
import numpy as np
from numpy.typing import NDArray
from scipy import spatial


class ConvexHull:
    """
    Object to compute the convexhull and perform analysis onto the data.
    The class mostly uses the functionality from `Scipy ConvexHull <https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.ConvexHull.html>`_.

    Parameters
    ----------
    points: np.ndarray
        Numpy array with the coordinates (composition + energy) of points to construct a convex hull from.

    Attributes
    ----------
    points: np.ndarray
        Numpy array with the coordinates of all points to construct a convex hull from (also include boundaries data corresponding to the ndims last data).
    ground_states: np.ndarray
        Integer numpy array with the indexes of the ground state points.
    facets: np.ndarray
        Integer numpy array with the indexes of the points to form the facets of the convex hull.
    equations: np.ndarray
        Numpy array with the hyperplane equation of the facets.
    distances_above_hull: np.ndarray
        Numpy array with the distance each point is above the convex hull.
    ndims: int
        Number of dimensions of the convex hull.
    """

    epsilon = 1e-6

    def __init__(
        self,
        points: NDArray,
    ) -> None:
        ndims = points.shape[-1]
        boundaries = np.eye(ndims)
        boundaries[:, -1] = 2 * np.max(np.abs(points[:, -1]))
        points = np.vstack([points, boundaries])
        hull = spatial.ConvexHull(points)
        indexes_lower_hull = np.nonzero(hull.equations[:, -2] <= 0)[0]
        ground_states = np.unique(hull.simplices[indexes_lower_hull])[:-ndims]

        self.points: NDArray = points
        self.ground_states: NDArray[np.int_] = ground_states[
            np.lexsort(points[ground_states, ::-1].T)
        ]
        self.facets: NDArray[np.int_] = hull.simplices[indexes_lower_hull]
        self.equations: NDArray = hull.equations[indexes_lower_hull]

        self.distances_above_hull: NDArray = self.get_distance_above_hull(self.points)
        self.ndims: int = ndims

        return

    def get_energy_equations(self) -> NDArray:
        """
        Returns the equation of the energy for each facet.

        Returns
        -------
        equations: np.ndarray
            Numpy array with the energy equation of the facets.
        """
        equations = -np.delete(self.equations, -2, 1)
        coeff = np.divide(
            1,
            self.equations[:, -2],
            where=(self.equations[:, -2] != 0),
            out=np.full_like(self.equations[:, -2], fill_value=-np.inf),
        )
        equations = np.multiply(
            equations,
            np.tile(coeff, reps=(equations.shape[-1], 1)).T,
            where=(equations != 0),
            out=equations,
        )
        return equations

    def get_data_points(self) -> NDArray:
        """
        Returns the input data points used to construct the :py:obj:`~.madclex.analysis.convexhull.ConvexHull`.

        Returns
        -------
        np.ndarray
            Numpy array with the coordinates (composition + energy) of points to construct the convex hull from.
        """
        return self.points[: -self.ndims]

    def evaluate_on_hull(
        self, compositions: NDArray
    ) -> tuple[NDArray, NDArray[np.int_]]:
        """
        Evaluates the value on the convex hull at given compositions and determines corresponding the facet.

        Parameters
        ----------
        compositions: np.ndarray
            Numpy array with the composition of points to evaluate on the convex hull.

        Returns
        -------
        values: np.ndarray
            Numpy array with the values of the compositions evaluated on the convex hull.
        faces: np.ndarray[int]
            Integer numpy array with the indexes of the faces containing the compositions.
        """
        if len(compositions.shape) == 1:
            compositions = compositions.reshape(-1, 1)
        points = np.hstack([compositions, np.ones([len(compositions), 1])])
        equations = self.get_energy_equations()
        non_vertical_facets = np.invert(np.isinf(equations).any(axis=1))

        y = np.full([len(non_vertical_facets), len(points)], fill_value=-np.inf)
        y[non_vertical_facets] = equations[non_vertical_facets] @ points.T

        values = np.max(y, axis=0)
        faces = np.argmax(y, axis=0)
        return values, faces

    def get_distance_above_hull(self, points: np.ndarray) -> np.ndarray:
        """
        Evaluates the distance of points from the convex hull at same compositions.

        Parameters
        ----------
        points: np.ndarray
            Numpy array with the coordinates (composition + energy) of points to construct a convex hull from.

        Returns
        -------
        distances: np.ndarray
            Numpy array with the distances of all points above the convex hull.
        """
        if len(points.shape) < 2:
            points = points.reshape(1, -1)
        y_hull, faces = self.evaluate_on_hull(points[:, :-1])
        distances = points[:, -1] - y_hull
        return distances

    def ground_state_degree_stability(self) -> np.ndarray:
        """
        Evaluates the degree of stability of all ground states.
        The degree of stability is defined as the distance of the ground state to a new convex hull calculated after removing the ground state from the set of points.

        Returns
        -------
        stability: np.ndarray
            Numpy array with the stability of all ground states.
        """
        stability = np.zeros(len(self.ground_states))
        for i, gs in enumerate(self.ground_states):
            points = np.delete(self.points[: -self.ndims, :], gs, axis=0)
            hull = ConvexHull(points)
            stability[i] = hull.get_distance_above_hull(self.points[gs])[0]
        stability[stability > 0] = np.nan
        return stability

    def ground_state_chemical_stability(self):
        """
        Evaluates the range of chemical stability of all ground states.

        Returns
        -------
        stability: np.ndarray
            Numpy array of shape (N_ground_states x N_dims x N_max_facets) with the stability of all ground states.
        """

        # Associate facets with ground states
        associate = np.zeros([len(self.facets), len(self.points)], dtype=bool)
        associate[
            np.arange(len(self.facets)).repeat(self.ndims).reshape(-1, self.ndims),
            self.facets,
        ] = True
        associate = associate[:, self.ground_states]
        gs, facets = np.nonzero(associate.T)
        counts = np.unique(gs, return_counts=True)[1]
        N_facets = max(associate.sum(axis=0))

        # Chemical potentials corresponding to each facet
        chemical_potentials = self.get_energy_equations()[:, :-1]

        # Chemical stability
        stability = np.full(
            [len(self.ground_states), self.ndims - 1, N_facets], fill_value=np.nan
        )
        counter = 0
        for gs_index, n in enumerate(counts):
            mu = chemical_potentials[facets[counter : counter + n]]
            stability[gs_index, :, :n] = mu[np.lexsort(mu[:, ::-1].T)].T
            counter += n
        return stability

    def get_segment_line(
        self, x0: np.ndarray, x1: np.ndarray, tol: float = 1e-6
    ) -> tuple[NDArray[np.int_], NDArray[np.floating]]:
        """
        Select and find the psuedo-composition of data located on the segment line formed between two points in the compositional space.

        Parameters
        ----------
        x0: np.ndarray
            Composition of the starting point of the segment line.
        x1: np.ndarray
            Composition of the ending point of the segment line.
        tol: float, default: 1e-6
            Tolerence in the norm of the composition for a point to be defined as lying on the line segment.

        Returns
        -------
        indexes: np.ndarray[int]
            Integer numpy array with the indexes of the points lying on the line segment ordered from the start to the end of the segment.
        x: np.ndarray
            Numpy array with the pseudo-composition of the points lying on the line segment.
        """

        # Segment
        segment_vecor = x1 - x0
        segment_norm = np.linalg.norm(segment_vecor)

        # Compositions
        comp = self.points[: -self.ndims, :-1]

        # Position along segment line (projection onto the segment)
        x = (comp - x0).dot(segment_vecor) / segment_norm**2

        # error
        delta = comp - (x0 + segment_vecor * np.tile(x, reps=(self.ndims - 1, 1)).T)
        error = np.linalg.norm(delta, axis=-1)

        # Compositions onto segment
        indexes = np.nonzero((x >= 0) * (x <= 1) * (error < tol))[0]

        # Sorting
        arg = np.argsort(x[indexes])
        indexes = indexes[arg]
        x = x[indexes]

        return indexes, x


def get_binary_convexhull(points: NDArray, x_i: NDArray, x_f: NDArray) -> ConvexHull:
    """
    Construct a :py:obj:`ConvexHull` object along a composition segment line to construct pseudo-binary convex hulls.

    Parameters
    ----------
    points: np.ndarray
        Numpy array with the coordinates (composition + energy) of all points within the system.
    x_i: np.ndarray
        Composition of the starting point of the segment line.
    x_f: np.ndarray
        Composition of the ending point of the segment line.

    Returns
    -------
    binary_hull: ConvexHull
    """
    hull = ConvexHull(points)
    i, x = hull.get_segment_line(x_i, x_f)
    binary_points = np.stack([x, points[i, -1]]).T
    binary_hull = ConvexHull(binary_points)
    return binary_hull


def plot_binary_hull(hull: ConvexHull, start_label: str, end_label: str) -> None:
    """
    Plots the convex hull of a binary system.

    Parameters
    ----------
    binary_hull: ConvexHull
        ConvexHull object of the binary system
    start_label: str
        Label of the left-side of the convex hull.
    end_label: str
        Label of the right-side of the convex hull.
    """

    _, ax = plt.subplots(2, 1, sharex=True)

    ###############
    # Convex hull #
    ###############
    plt.sca(ax[0])

    # All data
    points = hull.get_data_points()
    plt.plot(points[:, 0], points[:, 1], "o", label="Data points", clip_on=False)

    # Ground states
    ground_state_points = hull.points[hull.ground_states]
    plt.plot(
        ground_state_points[:, 0],
        ground_state_points[:, 1],
        "k-o",
        label="Ground-states",
        clip_on=False,
    )

    plt.axhline(0, color="grey", linestyle=":")
    plt.ylabel("Energy\n (eV/unitcell)")
    plt.legend(loc="lower right", bbox_to_anchor=(1, 1), ncols=2, frameon=False)

    ######################
    # Chemical stability #
    ######################
    plt.sca(ax[1])

    x = []
    mu = []
    for index, mu_range in enumerate(hull.ground_state_chemical_stability()):
        x += [ground_state_points[index, 0]] * 2
        mu.append(
            mu_range[0][0]
            if not np.isneginf(mu_range[0][0])
            else (mu_range[0][1] - 0.1)
        )
        mu.append(
            mu_range[0][1] if not np.isinf(mu_range[0][1]) else (mu_range[0][0] + 0.1)
        )
    plt.plot(x, mu, "ko")
    plt.plot(x, mu, "k-", clip_on=False)

    plt.axhline(0, color="grey", linestyle=":")
    plt.xticks([0, 0.25, 0.5, 0.75, 1], [start_label, "0.25", "0.5", "0.75", end_label])
    plt.xlabel("$x$%s + $(1-x)$%s" % (end_label, start_label))
    plt.ylabel("Chemical potential\n (eV/unitcell)")
    plt.axis([0, 1, min(mu), max(mu)])
    plt.tight_layout()
    plt.show()

    return
