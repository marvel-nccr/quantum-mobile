from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from pymatgen.core import Structure

from pyece.core.configurations import Config
from pyece.core.prim import Prim
from pyece.utils.mapping import check_pass, ideal_map


class Sublattice:
    """
    Object to investigate sublattice occupations of a supercell structure constructed from the :py:obj:`~.pyece.core.prim.Prim` object.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    reference_structure: Structure
        Pymatgen structure to compute the sublattice composition from. An ideal structure is expected.
    supercell_transformation: np.ndarray[int]
        Integer numpy array with the transformation matrix to build the supercell from the :py:obj:`~.pyece.core.prim.Prim` object.
    reduce: bool, default: True
        Set to True to compute the mean and standard deviation of each sublattice composition among all occupations

    Returns
    -------
    comp_dict: dict
        Dictionary containing the compositions for each sublattice and each element.
    """

    def __init__(
        self,
        prim: Prim,
        reference_structure: Structure,
        supercell_transformation: NDArray[np.int_],
        reduce: bool = True,
    ) -> None:
        self.set_supercell(prim, supercell_transformation)
        self.config = Config.from_structure(
            reference_structure,
            self.superprim,
            list_try_maps=[ideal_map],
            list_checks=[check_pass],
        )
        self.sublattices_indexes = self.config.neighborhood_per_primcell.numpy(
            force=True
        )
        self.reduce: bool = reduce
        return

    def __call__(self, occupations: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the sublattice occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~Sublattice.config`).
            If None, the occupation given in :py:attr:`~Sublattice.config` is used.

        Returns
        -------
        comp_dict: dict
            Dictionary containing the compositions for each sublattice and each element.
        """
        sublattice_compositions = self.get_sublattice_compositions(occupations)
        if self.reduce and (occupations is not None) and (len(occupations.shape) > 1):
            comp = np.transpose(
                np.stack(
                    [
                        sublattice_compositions.mean(axis=0),
                        sublattice_compositions.std(axis=0, ddof=1),
                    ]
                ),
                axes=[1, 2, 0],
            ).tolist()
        else:
            comp = np.transpose(sublattice_compositions, axes=[1, 2, 0]).tolist()

        comp_dict = {}
        for sublattice_index, (basis, allowed_elements) in enumerate(
            zip(self.superprim.basis, self.superprim.elements_per_site)
        ):
            if len(allowed_elements) <= 1:
                continue
            for elem_index, elem in enumerate(self.superprim.elements):
                if elem not in allowed_elements:
                    continue
                comp_dict[
                    "%s_(%.3f_%.3f_%.3f)" % (elem, basis[0], basis[1], basis[2])
                ] = comp[sublattice_index][elem_index]
        return comp_dict

    def set_supercell(
        self, prim: Prim, supercell_transformation: NDArray[np.int_]
    ) -> None:
        """
        Build the :py:obj:`~.pyece.core.prim.Prim` object corresponding to a supercell of the :py:obj:`~.pyece.core.prim.Prim` object.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        supercell_transformation: np.ndarray[int]
            Integer numpy array with the transformation matrix to build the supercell of the :py:obj:`~.pyece.core.prim.Prim` object.
        """
        superstructure = prim.structure.make_supercell(
            supercell_transformation, to_unit_cell=True, in_place=False
        )
        superprim = Prim(
            superstructure, superstructure.site_properties["permitted_species"]
        )
        superprim.get_neighborhood(0)

        self.supercell_transformation: NDArray[np.int_] = supercell_transformation
        self.superprim: Prim = superprim
        return

    def get_sublattice_occupations(
        self, occupations: NDArray[np.int_] | None = None
    ) -> NDArray[np.str_]:
        """
        Compute the sublattice occupations.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~Sublattice.config`).
            If None, the occupation given in :py:attr:`~Sublattice.config` is used.

        Returns
        -------
        np.ndarray[Any, str]
            String numpy array of the species sitting in each sublattice per occupations.
        """
        if occupations is None:
            occupations = self.config.occupation.reshape(1, -1).numpy(force=True)
        if len(occupations.shape) == 1:
            occupations = occupations.reshape(1, -1)
        return self.superprim.elements[occupations[..., self.sublattices_indexes]]

    def get_sublattice_compositions(
        self, occupations: NDArray[np.int_] | None = None
    ) -> np.ndarray:
        """
        Compute the sublattice compositions.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~Sublattice.config`).
            If None, the occupation given in :py:attr:`~Sublattice.config` is used.

        Returns
        -------
        np.ndarray
            Numpy array of the sublattice compositions (the lowest level corresponds to the species, the next level to the sublattice, and otheers to the occupations).
        """
        elements_per_sublattice = self.get_sublattice_occupations(occupations)
        return np.stack(
            [
                np.mean(elements_per_sublattice == elem, axis=-2)
                for elem in self.superprim.elements
            ],
            axis=2,
        )
