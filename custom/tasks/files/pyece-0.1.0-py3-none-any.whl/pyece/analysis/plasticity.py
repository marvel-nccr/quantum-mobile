from __future__ import annotations

from typing import Callable

import numpy as np
import torch
from numpy.typing import NDArray
from pymatgen.core import Structure
from torch import (
    Tensor,
    no_grad,
)

from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.utils.mapping import check_pass, ideal_map


class SRO_excess_surface_energy:
    """
    Object to evaluate the SRO excess surface energy during a dislocation slip, as described in <https://doi.org/10.1016/j.actamat.2023.119472>`_.
    The slip plane must be (001).

    Parameters
    ----------
    model: eCE
        eCE model to be used to compute the SRO excess surface energy.
    reference_structure: Structure
        Pymatgen structure to compute the SRO excess surface energy from. An ideal structure is expected.
    slip_vector: np.ndarray,
        Vector of the dislocation slip in fractional coordinate within the (001) plane.
    slip_block_size: float, default: 0.5
        Fractional z-coordinate such that all atoms with fractional z-ccordinate greater or equal to 0.5 belong to the slip block.
    reduce: bool, default: True
        Set to True to compute the mean and standard deviation of the SRO excess surface energies.
    device: str = 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\').
    """

    def __init__(
        self,
        model: eCE,
        reference_structure: Structure,
        slip_vector: NDArray[np.float64],
        slip_block_size: float = 0.5,
        reduce: bool = True,
        device: str = "cpu",
    ) -> None:
        self.model: eCE = model
        self.config: Config = Config.from_structure(
            reference_structure,
            model.prim,
            list_try_maps=[ideal_map],
            list_checks=[check_pass],
        )
        self.slip_vector: NDArray[np.float64] = slip_vector
        self.slip_block_size: float = slip_block_size
        self.indexes = self.get_slip_block()
        self.surface: float = np.linalg.norm(
            np.cross(
                reference_structure.lattice.matrix[0],
                reference_structure.lattice.matrix[1],
            )
        )
        self.reduce: bool = reduce
        self.device: str = device
        self.model.to(device)

        @no_grad()
        @torch.compile(fullgraph=True, mode="reduce-overhead")
        def get_energy(neighborhood_occupations: Tensor) -> Tensor:
            return model(neighborhood_occupations).sum()

        self.get_energy: Callable = lambda neighborhood_occupations: get_energy(
            neighborhood_occupations
        ).numpy(force=True)
        return

    def __call__(
        self, occupations: NDArray[np.int_] | None = None
    ) -> NDArray[np.float64]:
        """
        Computes the SRO excess surface energy during a dislocation slip of the occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~Sublattice.config`).
            If None, the occupation given in :py:attr:`~Sublattice.config` is used.

        Returns
        -------
        np.ndarray
            Numpy array containing the SRO excess surface energies.
        """
        if occupations is None:
            occupations = self.config.occupation.reshape(1, -1).numpy(force=True)
        if len(occupations.shape) == 1:
            occupations = occupations.reshape(1, -1)

        initial_occupations_tensor = torch.from_numpy(occupations).int().to(self.device)
        final_occupations_tensor = (
            torch.from_numpy(occupations[:, self.indexes]).int().to(self.device)
        )

        initial_neighborhood_occupations = initial_occupations_tensor[
            :, self.config.neighborhood_per_primcell
        ]
        final_neighborhood_occupations = final_occupations_tensor[
            :, self.config.neighborhood_per_primcell
        ]
        gamma = np.zeros(len(occupations))

        for occ_index in range(len(occupations)):
            gamma[occ_index] = self.get_energy(
                final_neighborhood_occupations[occ_index]
            ) - self.get_energy(initial_neighborhood_occupations[occ_index])
        gamma /= 2 * self.surface

        if self.reduce:
            return np.array([gamma.mean(), gamma.std(ddof=1)])
        else:
            return gamma

    def get_slip_block(self) -> NDArray[np.int_]:
        """
        Determines the rearrangement of the atomic sites due to the dislocation slip.

        Returns
        -------
        args: np.ndarray[int]
            Integer numpy array of site indexes.
        """
        if len(self.slip_vector) != 2:
            if (len(self.slip_vector) != 3) and (self.slip_vector[-1] != 0.0):
                raise ValueError(
                    "The slip vector is expected to be contained in the (001) plane, and must therefore correspond to either a vector of size 2 or have a third component equal to 0."
                )
        coords = self.config.fractional_coordinates
        new_coords = coords.copy()
        new_coords[coords[:, -1] >= self.slip_block_size, 0] += self.slip_vector[0]
        new_coords[coords[:, -1] >= self.slip_block_size, 1] += self.slip_vector[1]
        distances = self.config.get_structure().lattice.get_all_distances(
            coords, new_coords
        )
        ind, args = np.nonzero(distances < 1e-6)
        count = np.unique(ind, return_counts=True)[1]
        if not np.all(count == 1):
            raise ValueError(
                "An error occured during the determination of the indexes belonging to the slip block."
            )
        return args
