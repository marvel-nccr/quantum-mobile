from __future__ import annotations

import numpy as np
import torch
from numpy.typing import NDArray
from pymatgen.core import Structure

from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.core.prim import Prim
from pyece.utils.mapping import check_pass, ideal_map


class SRO:
    """
    Object to investigate the pair joint probabilities and short range order (SRO) parameters.

    Warning
    -------
    The object computes the sro for pair clusters only.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    structure: Structure
        Pymatgen structure to evaluate the SRO from. An ideal structure is expected.
    cutoff: float, default: 4.0
        Cutoff radius of the pair clusters.
    reduce: bool, default: True
        Set to True to compute the mean and standard deviation of each SRO among all occupations

    Returns
    -------
    sro_dict: dict
        Dictionary containing the SRO for each pairs of elements and each orbit.
    """

    def __init__(
        self,
        prim: Prim,
        structure: Structure,
        cutoff: float = 4.0,
        reduce: bool = True,
    ) -> None:
        self.model = construct_sro_model(prim, cutoff)
        self.model.prod()
        self.transfo_dict = correlations_to_densities(self.model)
        self.config = Config.from_structure(
            structure,
            self.model.prim,
            list_try_maps=[ideal_map],
            list_checks=[check_pass],
        )
        self.reduce: bool = reduce
        return

    def __call__(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the SRO of occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        sro_dict: dict
            Dictionary containing the SRO for each pairs of elements and each orbit.
        """
        sro_dict_unprocessed = self.compute_sro(occupations)
        sro_dict = {}
        for orbit in sro_dict_unprocessed:
            if (
                self.reduce
                and (occupations is not None)
                and (len(occupations.shape) > 1)
            ):
                sro = np.transpose(
                    np.stack(
                        [
                            sro_dict_unprocessed[orbit]["sro"].mean(axis=0),
                            sro_dict_unprocessed[orbit]["sro"].std(axis=0, ddof=1),
                        ]
                    ),
                    axes=[1, 2, 0],
                ).tolist()
            else:
                sro = np.transpose(
                    sro_dict_unprocessed[orbit]["sro"], axes=[1, 2, 0]
                ).tolist()
            for ind1, elem1 in enumerate(self.transfo_dict[orbit]["species"][0]):
                for ind2, elem2 in enumerate(self.transfo_dict[orbit]["species"][1]):
                    sro_dict[
                        "%s-%s_(%s)"
                        % (
                            self.model.prim.elements[elem1],
                            self.model.prim.elements[elem2],
                            orbit,
                        )
                    ] = sro[ind1][ind2]
        return sro_dict

    def get_prob(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the pair joint probabilities of occupations and return the result in a dictionary.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        prob_dict: dict
            Dictionary containing the pair joint probabilities for each pairs of elements and each orbit.
        """
        prob_dict_unprocessed = self.compute_probabilities(occupations)
        prob_dict = {}
        for orbit in prob_dict_unprocessed:
            if (
                self.reduce
                and (occupations is not None)
                and (len(occupations.shape) > 1)
            ):
                prob = np.transpose(
                    np.stack(
                        [
                            prob_dict_unprocessed[orbit]["probabilities"].mean(axis=0),
                            prob_dict_unprocessed[orbit]["probabilities"].std(
                                axis=0, ddof=1
                            ),
                        ]
                    ),
                    axes=[1, 2, 0],
                ).tolist()
            else:
                prob = np.transpose(
                    prob_dict_unprocessed[orbit]["probabilities"], axes=[1, 2, 0]
                ).tolist()
            for ind1, elem1 in enumerate(self.transfo_dict[orbit]["species"][0]):
                for ind2, elem2 in enumerate(self.transfo_dict[orbit]["species"][1]):
                    prob_dict[
                        "%s-%s_(%s)"
                        % (
                            self.model.prim.elements[elem1],
                            self.model.prim.elements[elem2],
                            orbit,
                        )
                    ] = prob[ind1][ind2]
        return prob_dict

    def compute_probabilities(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the pair joint probabilities of occupations.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~Sublattice.config`).
            If None, the occupation given in :py:attr:`~Sublattice.config` is used.

        Returns
        -------
        prob_dict: dict
            Dictionary containing dictionaries with the species and associated pair joint probabilities for each orbit.
        """
        prob_dict = {
            orbit: {"species": self.transfo_dict[orbit]["species"], "probabilities": []}
            for orbit, __ in self.transfo_dict.items()
        }
        if occupations is None:
            occupations_tensor = self.config.occupation.reshape(1, -1)
        else:
            occupations_tensor = torch.tensor(occupations).int()
        if len(occupations_tensor.shape) == 1:
            occupations_tensor = occupations_tensor.reshape(1, -1)

        for occup in occupations_tensor:
            self.config.occupation = occup
            phi = self.model.get_averaged_correlations(
                self.config.get_neighborhood_occupations()
            ).numpy(force=True)
            for orbit, __ in self.transfo_dict.items():
                probabilities = (
                    self.transfo_dict[orbit]["matrix"]
                    @ phi[self.transfo_dict[orbit]["correlations"]]
                )
                prob_dict[orbit]["probabilities"].append(probabilities)

        for orbit in prob_dict:
            prob_dict[orbit]["probabilities"] = np.stack(
                prob_dict[orbit]["probabilities"]
            )
        return prob_dict

    def compute_sro(
        self,
        occupations: NDArray[np.int_] | None = None,
    ) -> dict:
        """
        Computes the SRO of occupations.

        Parameters
        ----------
        occupations: np.ndarray[int] | None = None
            Integer numpy array of occupations (the occupation are expected to match the sites in :py:attr:`~SRO.config`).
            If None, the occupation given in :py:attr:`~SRO.config` is used.

        Returns
        -------
        sro_dict: dict
            Dictionary containing dictionaries with the species and associated SRO for each orbit.
        """
        sro_dict = {
            orbit: {"species": self.transfo_dict[orbit]["species"], "sro": []}
            for orbit, __ in self.transfo_dict.items()
        }
        if occupations is None:
            occupations_tensor = self.config.occupation.reshape(1, -1)
        else:
            occupations_tensor = torch.tensor(occupations).int()
        if len(occupations_tensor.shape) == 1:
            occupations_tensor = occupations_tensor.reshape(1, -1)

        for occup in occupations_tensor:
            self.config.occupation = occup
            phi = self.model.get_averaged_correlations(
                self.config.get_neighborhood_occupations()
            ).numpy(force=True)
            for orbit, __ in self.transfo_dict.items():
                probabilities = (
                    self.transfo_dict[orbit]["matrix"]
                    @ phi[self.transfo_dict[orbit]["correlations"]]
                )
                concentrations = np.outer(
                    np.sum(probabilities, axis=1), np.sum(probabilities, axis=0)
                )
                concentrations[concentrations < 1e-6] = np.nan
                sro = 1 - probabilities / concentrations
                sro_dict[orbit]["sro"].append(sro)

        for orbit in sro_dict:
            sro_dict[orbit]["sro"] = np.stack(sro_dict[orbit]["sro"])
        return sro_dict


def construct_sro_model(prim: Prim, cutoff: float = 4.0, bodyorder: int = 2) -> eCE:
    """
    Constructs a CE pair model to compute the correlation functions of clusters of size smaller or equal to the cutoff radius.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    cutoff: float, default: 4.0
        Cutoff radius of the pair clusters.

    Returns
    -------
    eCE
        Linear eCE model to compute correlation functions.
    """
    settings = {
        "basis": "chebyshev",
        "orbit_tree_specs": {
            "orbit_tree_length_filter": {
                str(bo): {"min_length": 0, "max_length": cutoff}
                for bo in range(bodyorder + 1)
            }
        },
        "embedding_dimensions": 0,
        "nn_layers": [],
        # "globally_invariant": False,
    }
    return eCE.from_settings(settings, prim=prim, verbose=False)


def correlations_to_densities(model: eCE) -> dict:
    """
    Constructs the probability vector, the tranformation matrix, and the correlation vector to go from joint probabilities to pair correlation functions.

    Warning
    -------
    The function computes the tranformation matrices for pair clusters only.

    Parameters
    ----------
    model: eCE
        Pair eCE model to compute pair correlation functions.

    Returns
    -------
    dict_transformations: dict[dict]
        Dioctionary of dictionaries containing the indexes of the species involved in the joint probabilities, the transformation matrix, and the indexes of the correlation functions for each pair cluster.
    """

    model.prod()
    basis = model.sitebasis.sitebasis_functions.numpy(force=True)
    orbit_tracker = model.features.orbit_tracker()
    empty_orbit_indexes: list = sum(
        [orbit_tracker[orbit] for orbit in orbit_tracker if "Orbit_0_" in orbit], []
    )
    point_orbit_indexes: list = sum(
        [orbit_tracker[orbit] for orbit in orbit_tracker if "Orbit_1_" in orbit], []
    )

    dict_transformations: dict = {}
    select = model.features.selection_matrix.numpy(force=True)
    for pair_orbit in orbit_tracker:
        if "Orbit_2_" not in pair_orbit:
            continue
        orbit_indexes = np.array(
            empty_orbit_indexes + point_orbit_indexes + orbit_tracker[pair_orbit]
        )

        # Correlation functions
        ls_indexes: list[int] = []
        ls_functions: list[list[int]] = []
        ls_multiplicity = []
        included_functions_1 = []
        included_functions_2 = []
        for index in orbit_indexes:
            start = model.features.symmetrization_segment_indexes[index]
            end = model.features.symmetrization_segment_indexes[index + 1]
            functions = np.unique(select[start:end, 1, :], axis=0).tolist()
            ls_multiplicity.append(len(functions))
            if index not in point_orbit_indexes:
                included_functions_1 += [fct[0] for fct in functions]
                included_functions_2 += [fct[1] for fct in functions]
            if functions[0][-1] == 0 and functions[0][0] != 0:
                functions.append([0, functions[0][0]])
            ls_indexes += [index] * len(functions)
            ls_functions += functions
        ls_indexes_arr = np.array(ls_indexes)

        # Transformation matrix
        dict_transformations[pair_orbit] = {}
        included_functions_1 = np.unique(included_functions_1)
        included_functions_2 = np.unique(included_functions_2)

        allowed_species_1 = np.nonzero(~np.isinf(basis[included_functions_1[-1]]))[0]
        allowed_species_2 = np.nonzero(~np.isinf(basis[included_functions_2[-1]]))[0]

        size = len(included_functions_1) * len(included_functions_2)
        matrix = np.zeros([size, size])
        correlations = np.zeros(size, dtype=int)
        counter = 0
        for fct_1 in included_functions_1:
            for fct_2 in included_functions_2:
                # Matrix
                matrix[counter] = np.outer(
                    basis[fct_1, allowed_species_1], basis[fct_2, allowed_species_2]
                ).flatten()
                # Correlations
                correlations[counter] = ls_indexes_arr[
                    ls_functions.index([fct_1, fct_2])
                ]
                counter += 1

        # Output dictionary
        dict_transformations[pair_orbit]["species"] = [
            allowed_species_1.tolist(),
            allowed_species_2.tolist(),
        ]
        factor = np.tile(
            1
            / np.sqrt(ls_multiplicity)[
                [np.nonzero(orbit_indexes == corr)[0][0] for corr in correlations]
            ],
            reps=(size, 1),
        )
        dict_transformations[pair_orbit]["matrix"] = (
            np.linalg.inv(matrix) * factor
        ).reshape(len(allowed_species_1), len(allowed_species_2), size)
        dict_transformations[pair_orbit]["correlations"] = correlations
    return dict_transformations


def compute_sro(
    prim: Prim,
    structure: Structure,
    cutoff: float = 4.0,
    occupations: NDArray[np.int_] | None = None,
    reduce: bool = True,
) -> dict:
    """
    Constructs the probability vector, the tranformation matrix, and the correlation vector to go from joint probabilities to pair correlation functions.

    Warning
    -------
    The function computes the sro for pair clusters only.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice.
    structure: Structure
        Pymatgen structure to evaluate the SRO from.
    cutoff: float, default: 4.0
        Cutoff radius of the pair clusters.
    occupations: np.ndarray[int] | None = None
        Integer numpy array of occupations (the occpation are expected to match the sites in the `config` argument)
    reduce: bool, default: True
        Set to True to compute the mean and standard deviation of each SRO among all occupations

    Returns
    -------
    sro_dict: dict
        Dictionary containing the SRO for each pairs of elements and each orbit.
    """
    model = construct_sro_model(prim, cutoff)
    model.prod()
    transfo_dict = correlations_to_densities(model)
    config = Config.from_structure(structure, model.prim)

    sro_dict = {
        orbit: {"species": transfo_dict[orbit]["species"], "sro": []}
        for orbit, __ in transfo_dict.items()
    }
    if occupations is None:
        occupations_tensor = config.occupation.reshape(1, -1)
    else:
        occupations_tensor = torch.tensor(occupations).int()

    list_sro: list[list[np.ndarray]] = [[] * len(transfo_dict)]

    for occup in occupations_tensor:
        config.occupation = occup
        phi = model.get_averaged_correlations(
            config.get_neighborhood_occupations()
        ).numpy(force=True)
        for orbit_index, orbit in enumerate(transfo_dict):
            probabilities = (
                transfo_dict[orbit]["matrix"] @ phi[transfo_dict[orbit]["correlations"]]
            )
            concentrations = np.outer(
                np.sum(probabilities, axis=1), np.sum(probabilities, axis=0)
            )
            concentrations[concentrations < 1e-6] = np.nan
            sro = 1 - probabilities / concentrations
            list_sro[orbit_index].append(sro)
            sro_dict[orbit]["sro"].append(sro)

    sro_dict = {}
    for orbit_index, orbit in enumerate(transfo_dict):
        sro_array = np.stack(list_sro[orbit_index])
        if reduce and len(occupations_tensor) > 1:
            sro = np.transpose(
                np.stack(
                    [
                        sro_array.mean(axis=0),
                        sro_array.std(axis=0, ddof=1),
                    ]
                ),
                axes=[1, 2, 0],
            ).tolist()
        else:
            sro = np.transpose(sro_array, axes=[1, 2, 0]).tolist()
        for elem1 in transfo_dict[orbit]["species"][0]:
            for elem2 in transfo_dict[orbit]["species"][1]:
                sro_dict[
                    "%s-%s_(%s)" % (prim.elements[elem1], prim.elements[elem2], orbit)
                ] = sro[elem1][elem2]
    return sro_dict
