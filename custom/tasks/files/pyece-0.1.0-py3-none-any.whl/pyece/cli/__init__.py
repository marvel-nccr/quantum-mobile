"""Command-line interface for PyeCE."""
