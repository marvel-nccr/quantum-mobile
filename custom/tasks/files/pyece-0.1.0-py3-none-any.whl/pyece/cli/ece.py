#!/usr/bin/env python

import argparse

from pyece import __version__
from pyece.cli.ece_build import build_model
from pyece.cli.ece_data import process_data
from pyece.cli.ece_fit import fit_model
from pyece.cli.ece_mcmc import run_mcmc
from pyece.cli.ece_print import pretty_print


def main():
    parser = argparse.ArgumentParser(
        prog="ece",
        description="pyeCE: build, parameterize, and deploy embedded cluster expansions (eCE) for multicomponent alloys. Run MCMC simulations to compute ensemble averages.",
        epilog="pyeCE version {0}".format(__version__),
    )
    subparsers = parser.add_subparsers(help="available subcommands")

    build_parser = subparsers.add_parser(
        "build",
        description="The 'build' command is meant to construct an eCE model. Settings can be given individually as argument in the command line interface or gathered in a YAML settings file (see pyece.core.prim.PRIM.from_file). Once the model is built, the model is saved under the path given by the 'name' argument.",
        help="command to construct an eCE model",
    )
    data_parser = subparsers.add_parser(
        "data",
        description="The 'data' command is meant to read structures, map them onto the PRIM lattice, and compute ConfigData objects. The data are gathered in a pickle :py:obj:`~.pyece.learn.data.DataBase`. Settings can be given individually as argument in the command line interface or gathered in a YAML settings file (see pyece.core.prim.PRIM.from_file). Once the structures are processed, the ConfigData objects are saved as dictionaries under the path given by the 'name' argument.",
        help="command to process data according to an eCE model",
    )
    fit_parser = subparsers.add_parser(
        "fit",
        description="The 'fit' command is meant to parameterize an eCE model. Settings can be given individually as argument in the command line interface or gathered in a YAML settings file (see ...). Once the model is parameterized, the model is saved under the path given by the 'name' argument.",
        help="command to parameterize an eCE model",
    )
    mcmc_parser = subparsers.add_parser(
        "mcmc",
        description="The 'mcmc' command is meant to evaluate averaged properties in some common thermodynamic ensembles. Settings can be given individually as argument in the command line interface (see ...) or gathered in a YAML settings file (see ...).",
        help="command to run MCMC simulations in thermodynamic ensembles",
    )
    print_parser = subparsers.add_parser(
        "print",
        description="The 'print' command is meant to pretty print the different pyeCE objects.",
        help="command to pretty print the different pyeCE objects",
    )

    ##############################################
    # OPTIONS FOR THE BUILD SUBPARSER/SUBCOMMAND #
    ##############################################

    # CE parameters
    build_parser.add_argument(
        "-p",
        "--prim",
        type=str,
        default="PRIM",
        help="path to the PRIM file containing the primitive crystal structure and allowed chemical species on each atomic site (see 'Prim.from_file' in the pyeCE documentation for the file format specification).",
    )
    build_parser.add_argument(
        "--accuracy",
        type=int,
        default=6,
        help="number of decimal places used as tolerance for floating-point equality comparisons.",
    )
    build_parser.add_argument(
        "--symprec",
        type=float,
        help="tolerance for symmetry finding used in Pymatgen SpaceGroupAnalyzer.",
    )
    build_parser.add_argument(
        "--angle_tolerance",
        type=float,
        help="angle tolerance (in degrees) for symmetry finding used in Pymatgen SpaceGroupAnalyzer.",
    )
    build_parser.add_argument(
        "-b",
        "--basis",
        type=str,
        choices=["chebyshev", "occupational"],
        nargs="*",
        default=["chebyshev"],
        help="site basis function type for each sublattice in the prim (if only one value is given, it is applied to all sublattices).",
    )
    build_parser.add_argument(
        "-o",
        "--orbit_tree_specs",
        type=str,
        default='{"orbit_tree_length_filter": {"0": {}, "1": {}, "2": {"max_length": 8}}}',
        help="JSON string specifying cluster constraints for building the orbit tree. Keys are cluster sizes (e.g., '0', '1', '2') mapped to filter dictionaries (e.g., {'max_length': 8}).",
    )
    build_parser.add_argument(
        "--globally_invariant",
        action="store_true",
        default=False,
        help="compute translationally invariant (global) orbits instead of locally invariant orbits.",
    )
    build_parser.add_argument(
        "--normalization",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="normalize correlation functions by orbit size and number of permutations.",
    )
    build_parser.add_argument(
        "--per_unitcell",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="normalize the computed property per unit cell.",
    )

    # ECI NN parameters
    build_parser.add_argument(
        "-e",
        "--embedding_dimensions",
        type=int,
        nargs="*",
        default=[],
        help="embedding dimension for each sublattice in the prim. If omitted, dimensions are determined automatically.",
    )
    build_parser.add_argument(
        "-l",
        "--nn_layers",
        type=int,
        nargs="*",
        default=[32, 32, 8],
        help="list of the number of nodes in each hidden layer of the neural network (a linear model is built in case of empty list)",
    )
    build_parser.add_argument(
        "-a",
        "--activation",
        type=str,
        default="ReLU",
        help="PyTorch activation function name (e.g., ReLU, SiLU, Tanh).",
    )

    # Global settings
    build_parser.add_argument(
        "-s",
        "--settings",
        type=str,
        help="path to a YAML settings file for building the eCE model. Settings file values override CLI arguments.",
    )
    build_parser.add_argument(
        "-n",
        "--name",
        type=str,
        default="model.pth",
        help="path to save the model",
    )
    build_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="print information about the model",
    )
    build_parser.set_defaults(func=build_model)

    #############################################
    # OPTIONS FOR THE DATA SUBPARSER/SUBCOMMAND #
    #############################################

    # CE parameters
    data_parser.add_argument(
        "-m",
        "--model",
        type=str,
        default="model.pth",
        help="path to the model.",
    )

    # Data parameters
    group_batch = data_parser.add_mutually_exclusive_group(required=True)
    group_batch.add_argument(
        "-b",
        "--batch",
        type=str,
        help="path to a text file where each line contains: a structure file path, a property value (e.g., energy), and an optional fitting weight (default: 1).",
    )
    group_batch.add_argument(
        "-d",
        "--data",
        type=str,
        nargs="+",
        action="append",
        help="inline data entry: a structure file path, a property value (e.g., energy), and an optional fitting weight (default: 1).",
    )
    data_parser.add_argument(
        "--max_def",
        type=float,
        default=0.2,
        help="maximum deformation allowed in the structure.",
    )
    data_parser.add_argument(
        "--max_disp",
        type=float,
        default=0.5,
        help="maximum atomic displacement allowed in the structure in Angstroms.",
    )
    data_parser.add_argument(
        "--max_mapping_cost",
        type=float,
        default=0.01,
        help="critical value of the total cost of the mapping to accept.",
    )
    data_parser.add_argument(
        "--lattice_weight",
        type=float,
        default=0.5,
        help="weighting factor ([0,1]) for the lattice mapping cost in the total cost calculation.",
    )
    data_parser.add_argument(
        "--max_vac",
        type=float,
        default=0.0,
        help="maximum vacancy concentration allowed in the structure.",
    )
    data_parser.add_argument(
        "--min_vac",
        type=float,
        default=0.0,
        help="minimum vacancy concentration allowed in the structure.",
    )
    # Global settings
    data_parser.add_argument(
        "-c",
        "--configdata",
        action="store_true",
        default=False,
        help="include the full ConfigData objects in the saved database.",
    )
    data_parser.add_argument(
        "-n",
        "--name",
        type=str,
        default="database.pkl",
        help="path to save the processed data in pickle dataframe format.",
    )
    data_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="print information about the processed data",
    )
    data_parser.set_defaults(func=process_data)

    ############################################
    # OPTIONS FOR THE FIT SUBPARSER/SUBCOMMAND #
    ############################################

    # Model parameters
    fit_parser.add_argument(
        "-m",
        "--model",
        type=str,
        default="model.pth",
        help="path to the model to fit",
    )
    group_device = fit_parser.add_mutually_exclusive_group(required=False)
    group_device.add_argument(
        "--device",
        type=str,
        default="cpu",
        help="device to be used for PyTorch operations.",
    )
    group_device.add_argument(
        "--cpu",
        action="store_true",
        default=False,
        help="use cpu device for PyTorch operations.",
    )
    group_device.add_argument(
        "--cuda",
        action="store_true",
        default=False,
        help="use cuda device for PyTorch operations.",
    )

    # Dataset parameters
    group_data = fit_parser.add_mutually_exclusive_group(required=False)
    group_data.add_argument(
        "-t",
        "--train_file",
        type=str,
        help="path to the training dataset in pickle dataframe format. Use '--valid_file' and '--test_files' to add validation and test sets.",
    )
    group_data.add_argument(
        "-d",
        "--data_file",
        type=str,
        help="path to the dataset in pickle dataframe format (if used, it assumes random splitting of the dataset into training, validation, and test sets through the '--train_prop', '--valid_prop', and '--test_prop' arguments).",
    )
    fit_parser.add_argument(
        "--valid_file",
        type=str,
        help="path to the validation dataset in pickle dataframe format.",
    )
    fit_parser.add_argument(
        "--test_files",
        type=str,
        nargs="*",
        help="paths to the test datasets in pickle dataframe format (possible to have several test datasets).",
    )
    fit_parser.add_argument(
        "--train_prop",
        type=float,
        default=1.0,
        help="proportion of data in the training dataset.",
    )
    fit_parser.add_argument(
        "--valid_prop",
        type=float,
        help="proportion of data in the validation dataset.",
    )
    fit_parser.add_argument(
        "--test_prop",
        type=float,
        action="append",
        help="proportion of data in the test dataset.",
    )
    fit_parser.add_argument(
        "--train_indexes",
        type=str,
        nargs="*",
        help="slice expressions (start:end:step) selecting which data indexes to include in the training dataset when using '--train_prop'.",
    )
    fit_parser.add_argument(
        "--valid_indexes",
        type=str,
        nargs="*",
        help="slice expressions (start:end:step) selecting which data indexes to include in the validation dataset when using '--train_prop'.",
    )
    fit_parser.add_argument(
        "--test_indexes",
        type=str,
        nargs="*",
        action="append",
        help="slice expressions (start:end:step) selecting which data indexes to include in the test dataset when using '--train_prop'.",
    )
    fit_parser.add_argument(
        "--batch_size",
        type=int,
        default=50,
        help="batch size for each stochastic training step.",
    )

    # Fitting parameters
    fit_parser.add_argument(
        "-l",
        "--ladder_steps",
        type=int,
        nargs="*",
        help="list with the number of orbits to include in each ladder training step.",
    )
    fit_parser.add_argument(
        "-e",
        "--epochs",
        type=int,
        nargs="+",
        default=[50],
        help="list of the number of epochs for each ladder step (if only one value is given, the same number of epochs is applied to all steps).",
    )
    fit_parser.add_argument(
        "-r",
        "--lr",
        type=float,
        nargs="*",
        help="list of the learning rates for each ladder step (if only one value is given, the same learning rate is applied to all steps).",
    )
    fit_parser.add_argument(
        "--lr_embedding",
        type=float,
        nargs="*",
        help="list of the learning rates for the embedding matrix for each ladder step (if only one value is given, the same learning rate is applied to all steps and if not specified, the same value as for the '--lr' is assumed).",
    )
    fit_parser.add_argument(
        "-w",
        "--weight_decay",
        type=float,
        nargs="*",
        help="list of the weight decays / L2 regularizations for each ladder step (if only one value is given, the same weight decay is applied to all steps).",
    )
    fit_parser.add_argument(
        "-o",
        "--optimizers",
        type=str,
        nargs="*",
        default=['{"Adam": {"amsgrad": true} }'],
        help='JSON string per ladder step specifying the optimizer, e.g., \'{"Adam": {"amsgrad": true}}\'. If only one value is given, it is applied to all steps.',
    )
    fit_parser.add_argument(
        "-c",
        "--schedulers",
        type=str,
        nargs="*",
        default=['{"ConstantLR": {"factor": 1, "total_iters": 0}}'],
        help='JSON string per ladder step specifying the scheduler, e.g., \'{"ConstantLR": {"factor": 1, "total_iters": 0}}\'. If only one value is given, it is applied to all steps.',
    )
    fit_parser.add_argument(
        "-p",
        "--earlystopping_patience",
        type=int,
        nargs="*",
        help="early stopping patience for each ladder step. If omitted, early stopping is disabled. If only one value is given, it is applied to all steps. Requires a validation dataset.",
    )
    fit_parser.add_argument(
        "-f",
        "--loss_fct",
        type=str,
        default="MSELoss",
        help="name of the loss function from the PyTorch loss functions.",
    )

    # Global settings
    fit_parser.add_argument(
        "-s",
        "--settings",
        type=str,
        help="path to the YAML file containing the settings to fit the eCE model.",
    )
    fit_parser.add_argument(
        "-n",
        "--name",
        type=str,
        default="model.pth",
        help="path to save the parameterized model.",
    )
    fit_parser.add_argument(
        "-g",
        "--log",
        action="store_true",
        default=False,
        help="save a 'log_fit.json' file (in the same directory as '--name') containing data split indexes and training errors for each ladder step.",
    )
    fit_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="print information about the model",
    )
    fit_parser.set_defaults(func=fit_model)

    #############################################
    # OPTIONS FOR THE MCMC SUBPARSER/SUBCOMMAND #
    #############################################

    # Model parameters
    mcmc_parser.add_argument(
        "-m",
        "--model",
        type=str,
        default="model.pth",
        help="path to the model to be used.",
    )
    group_device = mcmc_parser.add_mutually_exclusive_group(required=False)
    group_device.add_argument(
        "-d",
        "--device",
        type=str,
        default="cpu",
        help="device to be used for PyTorch operations.",
    )
    group_device.add_argument(
        "--cpu",
        action="store_true",
        default=False,
        help="use cpu device for PyTorch operations.",
    )
    group_device.add_argument(
        "--cuda",
        action="store_true",
        default=False,
        help="use cuda device for PyTorch operations.",
    )

    # Thermo parameters
    mcmc_parser.add_argument(
        "-e",
        "--ensemble",
        type=str,
        choices=["Canonical", "SemiGrandCanonical"],
        default="Canonical",
        help="name of the MCEnsemble object available in 'pyece.montecarlo.mcmc'.",
    )
    mcmc_parser.add_argument(
        "-i",
        "--increment",
        type=str,
        action="append",
        help="JSON string defining how fixed variables evolve across states. Keys: 'mode' ('linear' or 'logarithmic'), 'number' (number of states), 'initial' and 'final' (dictionaries of fixed variable values). Can be repeated for multiple increments.",
    )
    group_config = mcmc_parser.add_mutually_exclusive_group(required=False)
    group_config.add_argument(
        "-c",
        "--config",
        type=str,
        help="path to the file with the initial configuration (An ideal structure is expected).",
    )
    group_config.add_argument(
        "-C",
        "--supercell",
        type=str,
        help="string matrix of the supercell transformation of the primitive cell.",
    )
    mcmc_parser.add_argument(
        "-x",
        "--composition",
        type=str,
        help="target concentration for each species (in the order defined by the Prim). Sites are randomly assigned to satisfy the given concentrations.",
    )
    group_transformation = mcmc_parser.add_mutually_exclusive_group(required=False)
    group_transformation.add_argument(
        "-b",
        "--background_specie",
        type=str,
        help="name of the background specie for the chemical potentials (chemical potential not fixed).",
    )
    group_transformation.add_argument(
        "--chemical_transformation",
        type=str,
        help="string matrix that transforms the true chemical potentials to the modified chemical potentials.",
    )
    mcmc_parser.add_argument(
        "--frozen_wyckoff_sites",
        type=str,
        default="None",
        help="list of 0/1 values indicating whether each Wyckoff group is frozen (species cannot change). Use 'None' to leave all groups unfrozen.",
    )

    # MCMC parameters
    mcmc_parser.add_argument(
        "-q",
        "--properties",
        type=str,
        help="string dictionary with the names of the properties to compute (available in 'pyece.mcmc.properties') as the first level keys and settings specific to the chosen properties are written in inner dictionaries.",
    )
    mcmc_parser.add_argument(
        "-y",
        "--precision",
        type=str,
        help="JSON string specifying the target precision (confidence interval size) for fluctuating variables or properties defined in '--properties'.",
    )
    mcmc_parser.add_argument(
        "-a",
        "--confidence",
        type=float,
        default=0.95,
        help="level of confidence for the construction of the confidence interval.",
    )
    mcmc_parser.add_argument(
        "-n",
        "--n_uncorrelated",
        type=int,
        default=50,
        help="minimum number of uncorrelated samples to compute in each MC simulation.",
    )
    mcmc_parser.add_argument(
        "--min",
        type=int,
        default=100,
        help="minimum number of samples to compute before stopping the simulation.",
    )
    mcmc_parser.add_argument(
        "--max",
        type=int,
        default=5000,
        help="maximum number of samples to compute before stopping the simulation.",
    )
    mcmc_parser.add_argument(
        "-f",
        "--sampling_frequency",
        type=int,
        help="number of MCMC steps to wait before collecting the state as a sample. If not set, the frequency is set to the number of sites in the configuration.",
    )
    mcmc_parser.add_argument(
        "--n_changes",
        type=int,
        default=1,
        help="number of occupational changes to perform at each MCMC step.",
    )

    # Global settings
    mcmc_parser.add_argument(
        "-s",
        "--settings",
        type=str,
        help="path to the YAML file containing the settings to perform the MCMC simulation.",
    )
    mcmc_parser.add_argument(
        "-p",
        "--path",
        type=str,
        default="results.json",
        help="path to save the results of the MC run in the JSON format.",
    )
    mcmc_parser.add_argument(
        "--path_to_configs",
        type=str,
        help="path to save the final configurations for fixed state of the MC run in the JSON format.",
    )
    mcmc_parser.add_argument(
        "-r",
        "--raw",
        type=str,
        help="path to save the raw data of the MC run in gz tar-file format.",
    )
    mcmc_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="print information about the MCMC simulation",
    )
    mcmc_parser.set_defaults(func=run_mcmc)

    ##############################################
    # OPTIONS FOR THE PRINT SUBPARSER/SUBCOMMAND #
    ##############################################

    print_parser.add_argument(
        "-m",
        "--model",
        type=str,
        default="model.pth",
        help="path to the eCE model.",
    )
    print_parser.add_argument(
        "-p",
        "--prim",
        action="store_true",
        default=False,
        help="print the Prim object of the eCE model.",
    )
    print_parser.add_argument(
        "-s",
        "--sitebasis",
        action="store_true",
        default=False,
        help="print the SiteBasis object of the eCE model.",
    )
    print_parser.add_argument(
        "-f",
        "--features",
        action="store_true",
        default=False,
        help="print the Features object of the eCE model.",
    )
    print_parser.add_argument(
        "-e",
        "--eci",
        action="store_true",
        default=False,
        help="print the ECI object of the eCE model.",
    )
    print_parser.add_argument(
        "-o",
        "--orbit_tree",
        action="store_true",
        default=False,
        help="print the OrbitTree object of the eCE model.",
    )
    print_parser.add_argument(
        "-d",
        "--data",
        type=str,
        default="",
        help="path to the processed dataset (DataBase object) in pickle dataframe format.",
    )
    print_parser.add_argument(
        "-c",
        "--convexhull",
        type=str,
        nargs=3,
        default=["", "", ""],
        help="construct a binary convex hull. Takes 3 arguments: path to the dataset (pickle dataframe), starting composition (xi), and ending composition (xf).",
    )
    print_parser.set_defaults(func=pretty_print)

    # =====================================================================
    # Parse arguments and call the subparser functions
    args = parser.parse_args()

    try:
        _ = args.func
    except AttributeError as exc:
        parser.print_help()
        raise SystemExit("Please specify a command.") from exc
    return args.func(args)


if __name__ == "__main__":
    main()
