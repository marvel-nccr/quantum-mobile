from __future__ import annotations

import json
from argparse import Namespace

import yaml

from pyece.core.clex import eCE


def build_model(args: Namespace | dict) -> None:
    """Master function to build and save a :py:obj:`~.pyece.core.clex.eCE` model from a YAML settings file (see :py:meth:`~.pyece.core.clex.eCE.from_files`).

    Note
    ----
    The function takes the argument args being the Namespace object from argparse or a dictionary.

    Parameters
    ----------
    args.prim: str, default: PRIM
        Path to the PRIM file containing the prim structure and allowed chemical species on each atomic site (see :py:meth:`~.pyece.core.prim.Prim.from_file`).
    args.accuracy: int, default: 6
        Number of decimal places for floating point numbers (this parameter is used whenever an equality test is performed and serves as a tolerance parameter).
    args.symprec: float | None, default: None
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_ (if None, the tolerance is set to 10^-accuracy).
    args.angle_tolerance: float | None, default: None
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_ (if None, the tolerance is set to 10^-accuracy).
    args.basis: str, default: \'chebyshev\'
        List of the type of full rank basis for each basis in the prim (if only one value is given, the same type is applied to all basis).
    args.orbit_tree_specs: str, default: '{"orbit_tree_length_filter": {"0": {}, "1": {}, "2": {"max_length": 8}}}'
        String dictionary with the constraints on the clusters to build the orbit tree.
    args.globally_invariant: bool, default: False
        Set to True to compute translationally invariant orbits over the whole structure as opposed to locally invariant orbits.
    args.normalization: bool, default: True,
        Set it to normalize the correlation functions per size of the orbit and number of permutations.
    args.per_unitcell: bool, default: True,
        Set it to normalize the computed property per unitcell.
    args.embedding_dimensions: list[int], default: []
        List of the embedding dimension for each basis in the prim (the embedding dimensions are automatically determined in case of empty list).
    args.nn_layers: list, default: [32, 32, 8]
        List of the number of nodes in each hidden layer of the neural network (a linear model is built in case of empty list).
    args.activation: str, default: "ReLU"
        name of the activation function between layers of the neural network in Pytorch torch.nn submodule.
    args.settings: str
        String with the path to the YAML settings file containing the settings to build the :py:obj:`~.pyece.core.clex.eCE` model (priority is given to the arguments specified in the settings file, missing arguments in the file are completed by the arguments in the command line interface).
    args.name: str, default : \'model.pth\'
        String with the path to save the :py:obj:`~.pyece.core.clex.eCE` model.
    args.verbose: bool, default : False
        Set to True to print information about the model as it is being built.
    """

    # Build settings file
    if isinstance(args, Namespace):
        opt = vars(args)
    else:
        opt = args.copy()
    opt["orbit_tree_specs"] = json.loads(opt["orbit_tree_specs"])
    verbose = opt.pop("verbose")
    settings = opt.pop("settings")
    opt.pop("func", None)
    if settings is not None:
        with open(settings) as f:
            settings = yaml.load(f, Loader=yaml.SafeLoader)
        opt.update(settings)
    if isinstance(opt["basis"], list) and len(opt["basis"]) == 1:
        opt["basis"] = opt["basis"][0]
    name = opt.pop("name")

    # Build model
    model = eCE.from_settings(opt, verbose)
    model.save(name)
