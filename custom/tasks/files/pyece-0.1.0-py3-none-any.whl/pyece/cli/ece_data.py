import functools
import json
from argparse import Namespace
from collections.abc import Sequence
from os.path import dirname, join

import numpy as np
import pandas as pd
from pymatgen.core import Structure
from tqdm import tqdm

from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.learn.data import ConfigData, DataBase
from pyece.utils.mapping import (
    check_mapping,
    deformation_cost,
    displacement_cost,
    quick_map,
)


def compute_composition(config: Config) -> np.ndarray:
    """Compute normalized species composition from a Config.

    Parameters
    ----------
    config : Config
        Mapped configuration.

    Returns
    -------
    np.ndarray
        Normalized composition array (sums to 1).
    """
    comp = config.get_composition().numpy(force=True).astype(float)
    comp /= comp.sum()
    return comp


def get_columns(species: Sequence[str], configdata: bool = False) -> list[str]:
    """Return column names for the mapped structures DataFrame.

    Parameters
    ----------
    species : Sequence[str]
        Ordered species from ``model.prim.elements``.
    configdata : bool
        Include a ``ConfigData`` column.

    Returns
    -------
    list[str]
    """
    return (
        [f"x_{specie}" for specie in species]
        + [
            "scel_size",
            "n_atoms",
            "property",
            "weight",
            "lattice_cost",
            "atomic_cost",
            "mapping_cost",
            "structure",
            "input_structure",
        ]
        + (["ConfigData"] if configdata else [])
        + ["origin"]
    )


def build_row(
    config: Config,
    structure: Structure,
    ideal_structure: Structure,
    comp: np.ndarray,
    prop: float,
    weight: float,
    lattice_cost: float,
    basis_cost: float,
    total_cost: float,
    path: str,
    configdata: bool = False,
) -> list:
    """Assemble one row of mapped-structure data, ordered to match :py:func:`get_columns`.

    Parameters
    ----------
    config : Config
        Mapped configuration.
    structure : Structure
        Original input structure.
    ideal_structure : Structure
        Ideal mapped structure from ``config.get_structure()``.
    comp : np.ndarray
        Normalized composition from :py:func:`compute_composition`.
    prop : float
        Scalar property (e.g. energy).
    weight : float
        Fitting weight.
    lattice_cost : float
        Symmetrized lattice deformation cost.
    basis_cost : float
        Atomic displacement cost.
    total_cost : float
        Weighted total mapping cost.
    path : str
        Origin file path or identifier.
    configdata : bool
        Include the serialized :py:obj:`~.pyece.learn.data.ConfigData` dict.

    Returns
    -------
    list
    """
    return (
        comp.tolist()
        + [
            len(config),
            len(structure),
            prop,
            weight,
            lattice_cost,
            basis_cost,
            total_cost,
            ideal_structure.to_file(fmt="poscar"),
            structure.to_file(fmt="poscar"),
        ]
        + (
            [
                ConfigData(
                    config,
                    prop,
                    weight,
                    {
                        "composition": comp.tolist(),
                        "supercell_size": len(config),
                        "origin": path,
                    },
                ).as_dict()
            ]
            if configdata
            else []
        )
        + [path]
    )


def map_structures(
    data: pd.DataFrame | list,
    model: eCE,
    *,
    max_def: float = 0.2,
    max_disp: float = 0.5,
    max_mapping_cost: float = 0.01,
    lattice_weight: float = 0.5,
    max_vac: float = 0.0,
    min_vac: float = 0.0,
    configdata: bool = False,
    verbose: bool = False,
    progress: bool = False,
) -> tuple[pd.DataFrame, list[dict]]:
    """Map structures to the model primitive and compute all metadata.

    Parameters
    ----------
    data : pd.DataFrame | list
        DataFrame (or list of dicts) with columns:

        - ``structure``: pymatgen :py:obj:`~pymatgen.core.Structure` objects
        - ``property``: scalar property values (e.g. energy)
        - ``weight`` *(optional)*: fitting weights, default 1.0
        - ``origin`` *(optional)*: file path or identifier string

    model : eCE
        Loaded eCE model.
    max_def : float
        Maximum deformation allowed in the structure.
    max_disp : float
        Maximum atomic displacement allowed in Angstroms.
    max_mapping_cost : float
        Critical value of the total mapping cost to accept.
    lattice_weight : float
        Weighting factor ([0, 1]) for the lattice cost in the total cost.
    max_vac : float
        Maximum vacancy concentration allowed.
    min_vac : float
        Minimum vacancy concentration allowed.
    configdata : bool
        Include a ``ConfigData`` column in the output.
    verbose : bool
        Print per-structure progress.
    progress : bool
        Show a tqdm progress bar with live mapped/failed counts.

    Returns
    -------
    tuple[pd.DataFrame, list[dict]]
        Labeled DataFrame of successfully mapped structures and a list of
        error dicts for failed mappings.
    """
    if not isinstance(data, pd.DataFrame):
        data = pd.DataFrame(data)

    missing = {"structure", "property"} - set(data.columns)
    if missing:
        raise ValueError(f"data is missing required columns: {missing}")

    has_weight = "weight" in data.columns
    has_origin = "origin" in data.columns

    map_checker = functools.partial(
        check_mapping,
        max_deformation=max_def,
        max_displacement=max_disp,
        lattice_weight=lattice_weight,
        max_mapping_cost=max_mapping_cost,
        vac_concentration_max=max_vac,
        vac_concentration_min=min_vac,
    )

    rows = []
    errors = []
    mapped = 0
    failed = 0

    iterator = data.iterrows()
    pbar = (
        tqdm(iterator, total=len(data), desc="Mapping structures")
        if progress
        else iterator
    )
    log = pbar.write if progress else print

    for _, entry in pbar:
        structure = entry["structure"]
        prop = float(entry["property"])
        weight = float(entry["weight"]) if has_weight else 1.0
        path = str(entry["origin"]) if has_origin and pd.notna(entry["origin"]) else ""

        if verbose:
            log(f"\n{path}")

        try:
            config, (deformation, displacements) = Config.from_structure(
                structure,
                model.prim,
                list_try_maps=[quick_map],
                list_checks=[map_checker],
                return_map=True,
            )
        except Exception as err:
            failed += 1
            # TODO: str(err).split("\n")[-2][3:] assumes a specific multi-line format from
            # Config.from_structure; make this more robust to handle arbitrary exception messages.
            errors.append({"origin": path, "error": str(err).split("\n")[-2][3:]})
            if verbose:
                log(str(err)[:-1])
            if progress:
                pbar.set_postfix(mapped=mapped, failed=failed)
            continue

        mapped += 1
        comp = compute_composition(config)
        ideal_structure = config.get_structure()
        lattice_cost = (
            deformation_cost(deformation) + deformation_cost(np.linalg.inv(deformation))
        ) / 2
        basis_cost = displacement_cost(displacements, ideal_structure)
        total_cost = lattice_weight * lattice_cost + (1 - lattice_weight) * basis_cost

        if verbose:
            log("Successfully mapped !")
        if progress:
            pbar.set_postfix(mapped=mapped, failed=failed)

        rows.append(
            build_row(
                config=config,
                structure=structure,
                ideal_structure=ideal_structure,
                comp=comp,
                prop=prop,
                weight=weight,
                lattice_cost=lattice_cost,
                basis_cost=basis_cost,
                total_cost=total_cost,
                path=path,
                configdata=configdata,
            )
        )

    columns = get_columns(model.prim.elements, configdata)
    return pd.DataFrame(rows, columns=columns), errors


def dataframe_to_database(
    df: pd.DataFrame,
    name: str,
    errors: list[dict] | None = None,
) -> DataBase:
    """Wrap a DataFrame in a :py:obj:`~.pyece.learn.data.DataBase`, save it, and write any error report.

    Parameters
    ----------
    df : pd.DataFrame
        Mapped structures DataFrame, typically from :py:func:`map_structures`.
    name : str
        Output path for the pickled DataBase.
    errors : list[dict] | None
        Error dicts from failed mappings; written to ``data_errors_report.json``
        alongside *name* when non-empty.

    Returns
    -------
    DataBase
    """
    database = DataBase(df)
    database.to_pickle(name)
    if errors:
        with open(
            join(dirname(name), "data_errors_report.json"), "w", encoding="utf8"
        ) as f:
            json.dump(errors, f, indent=3)
    return database


def process_data(args: Namespace | dict) -> None:
    """Build and save a :py:obj:`~.pyece.learn.data.DataBase` from a batch of structure files and their associated properties.

    Parameters
    ----------
    args.model: str, default: "model.pth"
        Path to the model.
    args.batch: str
        Path to a text file containing the paths to the file containing the structure (e.g., a POSCAR file), their associated properties (e.g., energy), and their weights during fitting (optional, default: 1) in every line.
    args.data: list[str]
        List with the data containing the path to the file containing the structure (e.g., a POSCAR file), its associated property (e.g., energy), and its weight during fitting (optional, default: 1).
    args.max_def: float, default: 0.2
        Maximum deformation allowed in the structure.
    args.max_disp: float, default: 0.5
        Maximum atomic displacement allowed in the structure in Angstroms.
    args.max_mapping_cost: float, default: 0.01
        Critical value of the total cost of the mapping to accept, computed as in `Comparing crystal structures with symmetry and geometry <https://www.nature.com/articles/s41524-021-00627-0>`_.
    args.lattice_weight: float, default: 0.5
        Weighting factor ([0,1]) for the lattice mapping cost in the total cost calculation.
    args.max_vac: float, default: 0.0
        Maximum vacancy concentration allowed in the structure.
    args.min_vac: float, default: 0.0
        Minimum vacancy concentration allowed in the structure.
    args.configdata: bool, default: False
        Save the dictionary of the :py:obj:`~.pyece.learn.data.ConfigData` in the database (adds a column named "ConfigData").
    args.name: str, default: "database.pkl"
        Path to save the processed data in the pickled dataframe format.
    args.verbose: bool, default: False
        Print information about the processed data.
    """
    if isinstance(args, Namespace):
        opt = vars(args)
    else:
        opt = args.copy()

    model = eCE.load(opt["model"])

    if opt["batch"] is not None:
        raw = pd.read_csv(
            opt["batch"],
            sep=None,
            header=None,
            skip_blank_lines=True,
            skipinitialspace=True,
            engine="python",
        )
    else:
        raw = pd.DataFrame(opt["data"])

    if raw.shape[1] > 2:
        weights = raw.iloc[:, 2].where(~raw.iloc[:, 2].isna(), 1.0).astype(float)
    else:
        weights = pd.Series([1.0] * len(raw), dtype=float)

    data = pd.DataFrame(
        {
            "origin": raw.iloc[:, 0],
            "structure": raw.iloc[:, 0].map(Structure.from_file),
            "property": raw.iloc[:, 1].astype(float),
            "weight": weights,
        }
    )

    df, errors = map_structures(
        data,
        model,
        max_def=opt["max_def"],
        max_disp=opt["max_disp"],
        max_mapping_cost=opt["max_mapping_cost"],
        lattice_weight=opt["lattice_weight"],
        max_vac=opt["max_vac"],
        min_vac=opt["min_vac"],
        configdata=opt["configdata"],
        verbose=opt["verbose"],
    )
    dataframe_to_database(df, opt["name"], errors)
