from __future__ import annotations

import datetime
import json
from argparse import Namespace
from os.path import dirname, join
from typing import Any

import numpy as np
import yaml
from torch import nn, optim, utils
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LRScheduler

from pyece.core.clex import eCE
from pyece.learn.data import ClexDataset, DataBase, random_split_data
from pyece.learn.train import EarlyStopping, ladder_optimize


def load_dataset(path: str, model: eCE | None = None) -> ClexDataset:
    """Loads a pickle dataframe file into a :py:obj:`~.pyece.learn.data.ClexDataset` object.
    If the database does not contain a column named \'ConfigData\' that contains the dictionaries of :py:obj:`~.pyece.learn.data.ConfigData` objects, then these objects need to be constructed and the model needs to be provided.

    Parameters
    ----------
    path: str
        Path to the pickle dataframe containing the data in the form of :py:obj:`~.pyece.learn.data.DataBase` objects.

        Tip
        ---
        This pickle dataframe is typically contructed using the :py:func:`~.pyece.cli.ece_data.process_data` function.

    model: eCE | None, default: None
        eCE object of the embedded cluster expansion model

    Returns
    -------
    ClexDataset
    """

    database = DataBase.from_file(path)

    return database.to_ClexDataset(model)


def make_datasets(
    N_data: int,
    train_prop: float,
    valid_prop: float,
    test_prop: list[float],
    train_indexes: list[int],
    valid_indexes: list[int],
    test_indexes: list[list[int]],
) -> dict:
    """Returns the training, validation, and test datasets by randomly splitting the total dataset and satisfying some proportions and required data in each set.

    Parameters
    ----------
    N_data: int
        Number of total data available
    train_prop: float
        Proportion of training data
    valid_prop: float
        Proportion of validation data
    test_prop: list[float]
        List of proportions of data in each test dataset
    train_indexes: list[int]
        List of data indexes to be included in the training dataset
    valid_indexes: list[int]
        List of data indexes to be included in the validation dataset
    test_indexes: list[list[int]]
        List of lists of data indexes to be included in the each test dataset

    Returns
    -------
    dct: dct[list | None]
        Dictionary with the indexes of the training, validation, and test datasets.
    """
    indexes_in = [
        np.array(train_indexes, dtype=int),
        np.array(valid_indexes, dtype=int),
    ] + [np.array(ind, dtype=int) for ind in test_indexes]

    proportions = np.array(
        [train_prop, valid_prop] + [prop for prop in test_prop], dtype=float
    )
    list_datasets = random_split_data(proportions, N_data, indexes_in)
    dct = {
        "train": np.sort(list_datasets[0]).tolist(),
        "validation": (
            np.sort(list_datasets[1]).tolist() if len(list_datasets[1]) > 0 else None
        ),
    }
    dct["test"] = (
        [np.sort(dataset).tolist() for dataset in list_datasets[2:]]
        if len(list_datasets[2]) > 0
        else None
    )
    return dct


def make_optimizers(
    model: eCE,
    list_lr: list[float | None],
    list_lr_embedding: list[float | None],
    list_wd: list[float | None],
    list_optim: list[dict | str],
    list_schedule: list[dict | str],
) -> tuple[list[Optimizer], list[LRScheduler]]:
    """Creates the PyTorch optimizer and scheduler objects to be used in the ladder training.

    Parameters
    ----------
    model: eCE
        eCE object of the embedded cluster expansion model
    list_lr: list[float | None]
        List of the global learning rates per ladder step
    list_lr_embedding: list[float | None]
        List of the learning rates for the embedding matrix per ladder step
    list_wd: list[float | None]
        List of the weight decays (L2-regularizations) per ladder step
    list_optim: list[dict | str]
        List of PyTorch optimizers per ladder step. It has the format of a dictionary with the name of the PyTorch optim object as a key to a dictionary of parameters. The dictionary can be either a dictionary object or a string dictionary.
    list_schedule: list[dict | str]
        List of PyTorch schedulers per ladder step. It has the format of a dictionary with the name of the PyTorch optim.lr_scheduler object as a key to a dictionary of parameters. The dictionary can be either a dictionary object or a string dictionary.

    Returns
    -------
    tuple[list]
        Tuple with the list of optimizers and schedulers per ladder step.
    """
    ls_optim: list[Optimizer] = []
    ls_schedule: list[LRScheduler] = []
    for lr, lr_embedding, wd, optim_dct, schedule_dct in zip(
        list_lr, list_lr_embedding, list_wd, list_optim, list_schedule
    ):
        # Optimizers
        if isinstance(optim_dct, str):
            optim_dct = json.loads(optim_dct)
        fct = list(optim_dct.keys())[0]
        kwargs: dict[str, Any] = {
            "params": [
                {"params": model.sitebasis.parameters()},
                {"params": model.eci.parameters()},
            ]
        }
        if lr is not None:
            kwargs["lr"] = float(lr)
        if lr_embedding is not None:
            kwargs["params"][0]["lr"] = float(lr_embedding)
        if wd is not None:
            kwargs["weight_decay"] = float(wd)
        kwargs.update(optim_dct[fct])
        ls_optim.append(getattr(optim, fct)(**kwargs))

        # Schedulers
        if isinstance(schedule_dct, str):
            schedule_dct = json.loads(schedule_dct)
        fct = list(schedule_dct.keys())[0]
        kwargs = {"optimizer": ls_optim[-1]}
        kwargs.update(schedule_dct[fct])
        ls_schedule.append(getattr(optim.lr_scheduler, fct)(**kwargs))

    return ls_optim, ls_schedule


def fit_model(args: Namespace | dict) -> None:
    """Master function to build and save a :py:obj:`~.pyece.core.clex.eCE` model from a YAML settings file (see :py:meth:`~.pyece.core.clex.eCE.from_files`).

    Note
    ----
    The function takes the argument args being the Namespace object from argparse or a dictionary.

    Parameters
    ----------
    args.model: str, default : \'model.pth\'
        String with the path to the :py:obj:`~.pyece.core.clex.eCE` model.
    args.train_file: str
        Path to the training dataset in pickle dataframe format (if used, valdidation and test sets can be added through the '--valid_file' and '--test_files' arguments).
    args.data_file: str
        Path to the dataset in pickle dataframe format (if used, it assumes random splitting of the dataset into training, validation, and test sets through the '--train_prop', '--valid_prop', and '--test_prop' arguments).
    args.valid_file: str | None, default: None
        Path to the validation dataset inpickle dataframe format.
    args.test_files: list[str] | None, default: None
        List of paths to the test datasets in pickle dataframe format (possible to have several test datasets).
    args.train_prop: float, default=1.0
        Proportion of data in the training dataset.
    args.valid_prop: float | None, default: None
        Proportion of data in the validation dataset.
    args.test_prop: list[float] | default: None
        Proportion of data in the test dataset.
    args.train_indexes: list[str] | None, default: None
        List of string slices 'start:end:step' (with colon-separations) of indexes of data to include in training dataset if using '--train_prop' (default: start=0, end=len(dataset), step=1).
    args.valid_indexes: list[str] | None, default: None
        List of string slices 'start:end:step' (with colon-separations) of indexes of data to include in validation dataset if using '--train_prop' (default: start=0, end=len(dataset), step=1).
    args.test_indexes: list[str] | None, default: None
        List of string slices 'start:end:step' (with colon-separations) of indexes of data to include in test dataset if using '--train_prop' (default: start=0, end=len(dataset), step=1).
    args.batch_size: int, default: 50
        Batch size for each stochastic training step.
    args.ladder_steps: list[int] | None, default: None
        List with the number of orbits to include in each ladder training step.
    args.epochs: list[int], default: [50]
        List of the number of epochs for each ladder step (if only one value is given, the same number of epochs is applied to all steps).
    args.lr: list[float] | None, default: None
        List of the learning rates for each ladder step (if only one value is given, the same learning rate is applied to all steps).
    args.lr_embedding: list[float] | None, default: None
        List of the learning rates for the embedding matrix for each ladder step (if only one value is given, the same learning rate is applied to all steps and if not specified, the same value as for the '--lr' is assumed).
    args.weight_decay: list[float] | None, default: None
        List of the weight decays / L2 regularizations for each ladder step (if only one value is given, the same weight decay is applied to all steps).
    args.optimizers: str, default: ['{"Adam": {"amsgrad": true}}']
        List of the optimizers for each ladder step where each optimizer is written in string dictionary with the name of the PyTorch optimizer as the only key and settings specific to the chosen optimizer are written in an inner dictionary (if only one value is given, the same optimizer is applied to all steps).
    args.schedulers: str, default: ['{"ConstantLR": {"factor"=1, "total_iters"=0} }']
        List of the schedulers for each ladder step where each scheduler is written in string dictionary with the name of the PyTorch scheduler as the only key and settings specific to the chosen scheduler are written in an inner dictionary (if only one value is given, the same optimizer is applied to all steps).
    args.earlystopping_patience: list[int] | None, default: None
        List of the earlystopping_patience for each ladder step (no value does not apply early stopping and only one value reults in the same early stopping applied to all steps, requires a validation dataset to be employed).
    args.loss_fct: str, default: "MSELoss"
        Name of the loss function from the PyTorch loss functions.
    args.settings: str
        String with the path to the YAML settings file containing the settings to fit the :py:obj:`~.pyece.core.clex.eCE` model (priority is given to the arguments specified in the settings file, missing arguments in the file are completed by the arguments in the command line interface).
    args.name: str, default : \'fitted_model.pth\'
        String with the path to save the fitted :py:obj:`~.pyece.core.clex.eCE` model.
    args.device: str, default: 'cpu'
        Device to be used for PyTorch operations.
    args.cpu: bool, default: False
        Set to True to use cpu device for PyTorch operations.
    args.cuda: bool, default: False
        Set to True to use cuda device for PyTorch operations.
    args.verbose: bool, default : True
        Set to True to print information about the model as it is being built.
    """

    def read_indexes(list_indexes: list, N: int):
        indexes = []
        for values in list_indexes:
            start_end_step = np.array([0, N, 1])
            list_split = str(values).split(":")
            if len(list_split) == 1:
                ind = int(list_split[0])
                indexes += [ind if ind >= 0 else N + ind]
            else:
                for split_index, split in enumerate(list_split):
                    start_end_step[split_index] = (
                        int(split) if len(split) != 0 else start_end_step[split_index]
                    )
                start_end_step[start_end_step < 0] += N
                indexes += list(range(*start_end_step))
        return list(np.unique(indexes))

    if isinstance(args, Namespace):
        opt = vars(args)
    else:
        opt = args.copy()
    if opt["settings"] is not None:
        with open(opt["settings"]) as f:
            settings = yaml.load(f, Loader=yaml.SafeLoader)
            f.close()
        opt.update(settings)
    verbose = opt["verbose"]
    opt.pop("func")

    # MODEL
    # -----

    model = eCE.load(opt["model"])
    if verbose:
        print(model)

    device = opt["device"]
    if opt["cpu"]:
        device = "cpu"
    if opt["cuda"]:
        device = "cuda"

    # Data
    # ----

    dct_indexes = None
    if opt["train_file"] is not None:
        # From files
        dataloader_train = utils.data.DataLoader(
            load_dataset(opt["train_file"], model=model),
            batch_size=opt["batch_size"],
            shuffle=True,
        )
        dataloader_valid = (
            utils.data.DataLoader(
                load_dataset(opt["valid_file"], model=model),
                batch_size=opt["batch_size"],
                shuffle=False,
            )
            if opt["valid_file"]
            else None
        )
        if opt["test_files"] is not None:
            dataloader_test = [
                utils.data.DataLoader(
                    load_dataset(path, model=model),
                    batch_size=opt["batch_size"],
                    shuffle=False,
                )
                for path in list(opt["test_files"])
            ]
        else:
            dataloader_test = None
    else:
        # Random splits
        dataset = load_dataset(opt["data_file"], model=model)
        data_size = len(dataset)
        dct_indexes = make_datasets(
            N_data=len(dataset),
            train_prop=opt["train_prop"],
            valid_prop=0 if opt["valid_prop"] is None else opt["valid_prop"],
            test_prop=[0] if opt["test_prop"] is None else list(opt["test_prop"]),
            train_indexes=(
                []
                if opt["train_indexes"] is None
                else read_indexes(opt["train_indexes"], data_size)
            ),
            valid_indexes=(
                []
                if opt["valid_indexes"] is None
                else read_indexes(opt["valid_indexes"], data_size)
            ),
            test_indexes=(
                [[]]
                if opt["test_indexes"] is None
                else [
                    read_indexes(test_ind, data_size)
                    for test_ind in list(opt["test_indexes"])
                ]
            ),
        )
        X, y, w = dataset[dct_indexes["train"]]
        dataloader_train = utils.data.DataLoader(
            ClexDataset(X, y, w), batch_size=opt["batch_size"], shuffle=True
        )
        if dct_indexes["validation"] is not None:
            X, y, w = dataset[dct_indexes["validation"]]
            dataloader_valid = utils.data.DataLoader(
                ClexDataset(X, y, w), batch_size=opt["batch_size"], shuffle=False
            )
        else:
            dataloader_valid = None
        if dct_indexes["test"] is not None:
            dataloader_test = []
            for ind in dct_indexes["test"]:
                X, y, w = dataset[ind]
                dataloader_test.append(
                    utils.data.DataLoader(
                        ClexDataset(X, y, w),
                        batch_size=opt["batch_size"],
                        shuffle=False,
                    )
                )
        else:
            dataloader_valid = None

        if verbose:
            print("\nRandom Data Splitting:")
            print("The training dataset contains %d data" % len(dct_indexes["train"]))
            print(
                "The validation dataset contains %d data"
                % len(dct_indexes["validation"])
            )
            for set_index, list_ind in enumerate(dct_indexes["test"]):
                print(
                    "The test dataset %d contains %d data" % (set_index, len(list_ind))
                )
            print()

    # FITTING PARAMETES
    # -----------------

    if (opt["ladder_steps"] is None) or (len(opt["ladder_steps"]) == 0):
        opt["ladder_steps"] = [len(model.features.orbit_tracker())]
    n_steps = len(opt["ladder_steps"])
    for key in [
        "epochs",
        "lr",
        "lr_embedding",
        "weight_decay",
        "optimizers",
        "schedulers",
        "earlystopping_patience",
    ]:
        if not isinstance(opt[key], list):
            opt[key] = [opt[key]]
        if len(opt[key]) == 1:
            opt[key] *= n_steps
    list_optimizers, list_schedulers = make_optimizers(
        model,
        opt["lr"],
        opt["lr_embedding"],
        opt["weight_decay"],
        opt["optimizers"],
        opt["schedulers"],
    )
    if opt["earlystopping_patience"][0] is not None:
        ls_earlystoppings = [
            EarlyStopping(patience=patience, verbose=verbose)
            for patience in opt["earlystopping_patience"]
        ]
    loss_fct = getattr(nn, opt["loss_fct"])

    # PARAMETERIZATION
    # ----------------

    losses = ladder_optimize(
        dataloader_train,
        model,
        loss_fct(),
        list_optimizers,
        list_schedulers,
        list_n_epochs=opt["epochs"],
        ladder_step_orbit_assignment=opt["ladder_steps"],
        test_dataloader=dataloader_test,
        valid_dataloader=dataloader_valid,
        list_early_stopping=ls_earlystoppings,
        device=device,
        verbose=verbose,
    )

    # SAVE
    # ----

    if verbose:
        print("\nTraining Summary:")
        print("Training loss: \t\t %.3e" % (losses[-1]["train"]))
        if losses[-1]["validation"] is not None:
            print("Validation loss: \t %.3e" % (losses[-1]["validation"]))
        if hasattr(losses[-1]["test"], "__iter__"):
            for loss_index, loss in enumerate(losses[-1]["test"]):
                if loss is not None:
                    print("Test loss (%d): \t\t %.3e" % (loss_index, loss))
        else:
            if losses[-1]["test"] is not None:
                print("Test loss: \t\t %.3e" % losses[-1]["test"])
    if opt["log"]:
        path = join(dirname(opt["name"]), "log_fit.json")
        log_file = {
            "ladder": opt["ladder_steps"],
            "losses": losses,
            "datasets": dct_indexes,
        }
        with open(path, "w") as f:
            json.dump(log_file, f)

    # Metadata
    now = datetime.datetime.now()
    N_trainings = len([key for key in model.metadata.keys() if "training_" in key]) + 1
    result_dict = {"loss_%s" % key: losses[-1][key] for key in losses[-1]} | {
        "trained_on": str(now)
    }
    model.metadata |= {"training_%d" % N_trainings: opt | result_dict}

    model.save(opt["name"])
    return
