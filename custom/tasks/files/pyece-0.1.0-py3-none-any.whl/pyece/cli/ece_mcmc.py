from __future__ import annotations

import json
import tarfile
from argparse import Namespace
from inspect import getfullargspec
from os import path, remove

import numpy as np
import torch
import yaml
from pymatgen.core import Structure
from scipy.optimize import nnls

from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.core.prim import Prim
from pyece.montecarlo import mcmc, properties, run
from pyece.utils.mapping import check_pass, ideal_map
from pyece.utils.toolbox import merge_dict


def fill_occupancy(config: Config, composition: np.ndarray, prim: Prim) -> None:
    """
    Modifies a :py:obj:`pyece.core.configurations.Config` object with a random occupancy satisfying the given composition and internal occupancy constraints.

    Parameters
    ----------
    config: Config
        Configuration object.
    composition: np.ndarray
        Numpy array with the overall composition with the elements sorted as in the ``config``.
    prim: Prim
        Prim object describing the lattice
    """

    # Determine number of species on each site
    x = composition / composition.sum() * len(config.occupation)
    N_elems = len(config.list_elements)
    constraints = np.zeros(
        [len(prim.basis) + N_elems, len(prim.basis) * N_elems], dtype=int
    )
    for site_index, site_occ in enumerate(prim.site_occupancy_matrix):
        for elem_index in range(N_elems):
            constraints[elem_index, N_elems * site_index + elem_index] = site_occ[
                elem_index
            ]
        constraints[
            site_index + N_elems, site_index * N_elems : (site_index + 1) * N_elems
        ] = site_occ
    composition_matrix = nnls(
        constraints, np.array(x.tolist() + [len(config)] * len(prim.basis))
    )[0]
    composition_matrix = np.rint(composition_matrix).astype(int).reshape(-1, N_elems)
    for site_index, site_composition in enumerate(composition_matrix):
        delta_N = site_composition.sum() - len(config)
        nonzero_species = np.nonzero(site_composition)[0]
        composition_matrix[site_index, nonzero_species[-abs(delta_N) :]] -= np.sign(
            delta_N
        )

    # Fill occupation
    rng = np.random.default_rng()
    occupation = config.occupation.numpy(force=True)
    sites = config.variable_sites.reshape(len(config), -1).T.numpy(force=True)
    for site_indexes, site_composition in zip(sites, composition_matrix):
        mask = np.ones(len(site_indexes), dtype=int)
        for specie_index, N in enumerate(site_composition):
            select = rng.choice(np.nonzero(mask)[0], N, replace=False)
            occupation[site_indexes[select]] = specie_index
            mask[select] = False
    config.occupation = torch.tensor(occupation).int()

    return


def run_mcmc(args: Namespace | dict) -> dict:
    """Master function to run MCMC simulations.

    Note
    ----
    The function takes the argument args being the Namespace object from argparse or a dictionary.

    Parameters
    ----------
    args.model: str, default: "model.pth"
        Path to the model to be used.
    args.device: str, default: "cpu"
        Device to be used for PyTorch operations.
    args.cpu: bool, default: False
        Set to True to use cpu device for PyTorch operations.
    args.cuda: bool, default: False
        Set to True to use cuda device for PyTorch operations.
    args.ensemble: str, default: "Canonical",
        Name of the MCEnsemble object available in :py:mod:`~.pyece.montecarlo.mcmc`.
    args.increment: dict | str
        (String) dictionary that specifies the evolution of the fixed variables, it contains 4 keys: 'mode' (choose the incremental mode between 'linear' and 'logarithmic'), 'number' (number of states), 'initial' (dictionary with the initial fixed variables available in :py:attr:`~.pyece.montecarlo.mcmc.MCEnsemble.fixed_variables`), and 'final' (dictionary with the final fixed variables).
    args.config: str | None
        Path to the file with the initial configuration (An ideal structure is expected).
    args.supercell: str | None, default: None
        Matrix of the supercell transformation of the primitive cell.
    args.composition: list[float] | str | None, default: None
        List with the concentration for each species as sorted in the 'Prim' object. Sites are randomly assigned a specie satisfying the concentration.
    args.background_specie: str | None, default: None
        Name of the background specie for the chemical potentials (chemical potential not fixed).
    args.chemical_transformation: list | str | None, deafult: None
        Matrix that transforms the true chemical potentials to the modified chemical potentials.
    args.frozen_wyckoff_sites: list | str | None, deafult: None
        List with boolean variables (0 = False/non-frozen; 1 = True/frozen) where the ith variable indicates whether all sites in the ith Wyckoff group of equivalent sites are to be considered as frozen, i.e., the chemical species cannot be changed (None sets all boolean variables to False).
    args.properties: dict | str | None, default: None
        (String) dictionary with the names of the properties to compute (available in :py:mod:`~.pyece.montecarlo.properties`) as the first level keys and settings specific to the chosen properties are written in an inner dictionary.
    args.precision: dict | str | None, default: None
        (String) dictionary that specifies the precision (size of the confidence interval) that one wants to achieve (the keys must correspond to either fluctiating variables or properties in ``--properties``).
    args.confidence: float, default: 0.95,
        Level of confidence for the construction of the confidence interval.
    args.n_uncorrelated: int, default: 50
        Minimum number of uncorrelated samples to compute in each MC simulation.
    args.min: int default: 100,
        Minimum number of samples to compute before stopping the simulation
    args.max: int default: 5000,
        Maximum number of samples to compute before stopping the simulation
    args.sampling_frequency: int | None, default: None
        Number of MCMC steps to wait before collecting the state as a sample. If None, the frequency is set to the number of sites in the configuration.",
    args.n_changes: int, default: 1
        Number of occupational changes to perform at each MCMC step.
    args.settings: str | None, default: None
        Path to the YAML file containing the settings to perform the MCMC simulation.
    args.path: str, default: "results.json"
        Path to save the results of the MC cooling run in the JSON format.
    args.path_to_configs: str | None, default: None
        Path to save the final configurations for fixed state of the MC run in the JSON format.
    args.raw: str | None, default: None
        Path to save the raw data of the MC run in gz tar-file format
    args.verbose: bool, default : True
        Set to True to print information about the MCMC simulation.

    Returns
    -------
    data: dict
        Dictionaries with the processed data at each state.
    """

    def read_matrix(input_matrix) -> np.ndarray:
        if isinstance(input_matrix, str):
            return np.array(
                [
                    np.fromstring(ls.replace("]", "").replace(",", " "), sep=" ")
                    for ls in input_matrix.split("[")
                    if len(ls)
                ]
            )
        else:
            return np.array(input_matrix)

    def save_dict(
        data_dict: dict,
        filename: str,
        tar_obj: tarfile.TarFile | None = None,
        indent: int | None = None,
    ):
        with open(filename, "w") as f:
            json.dump(data_dict, f, indent=indent)
            f.close()
        if tar_obj is not None:
            tar_obj.add(filename, arcname=path.basename(filename))
            remove(filename)
        return

    # Build settings file
    if isinstance(args, Namespace):
        opt = vars(args)
    else:
        opt = args.copy()
    settings = opt.pop("settings")
    opt.pop("func")
    if settings is not None:
        with open(settings) as f:
            settings = yaml.load(f, Loader=yaml.SafeLoader)
            f.close()
        opt.update(settings)
    verbose = opt["verbose"]

    ##############
    # MCEnsemble #
    ##############
    dct = {}

    # Load model
    model = eCE.load(opt["model"])
    dct["model"] = model

    # Device
    device = opt["device"]
    if opt["cpu"]:
        device = "cpu"
    if opt["cuda"]:
        device = "cuda"
    dct["device"] = device

    # Configuration
    if opt["config"] is not None:
        structure = Structure.from_file(opt["config"])
    if opt["supercell"] is not None:
        structure = Structure.from_dict(
            model.prim.structure.as_dict()["structure"]
        ).make_supercell(
            read_matrix(opt["supercell"]).astype(int), to_unit_cell=True, in_place=False
        )
        for site_index, site in enumerate(structure):
            if (
                site.properties["permitted_species"][0] == "Va"
                and len(site.properties["permitted_species"]) > 1
            ):
                target_species_idx = 1
            else:
                target_species_idx = 0
            structure.replace(
                site_index, site.properties["permitted_species"][target_species_idx]
            )
    config = Config.from_structure(
        structure,
        model.prim,
        list_try_maps=[ideal_map],
        list_checks=[check_pass],
    )
    if opt["composition"] is not None:
        fill_occupancy(
            config, read_matrix(opt["composition"]).flatten().astype(float), model.prim
        )
    dct["config"] = config

    # Chemical transformation
    chemical_transformation = None
    if opt["chemical_transformation"] is not None:
        chemical_transformation = read_matrix(opt["chemical_transformation"])
    elif opt["background_specie"] is not None:
        N = len(model.prim.elements)
        background_index = np.nonzero(model.prim.elements == opt["background_specie"])[
            0
        ][0]
        chemical_transformation = np.eye(N, N)[
            np.arange(N)
            != (background_index if (background_index >= 0) else (N + background_index))
        ]
    dct["chemical_transformation"] = chemical_transformation

    # Frozen Wyckoff Sites
    frozen_wyckoff_sites = None
    if opt["frozen_wyckoff_sites"] is None:
        frozen_wyckoff_sites = None
    elif opt["frozen_wyckoff_sites"] == "None":
        frozen_wyckoff_sites = None
    else:
        frozen_wyckoff_sites = read_matrix(opt["frozen_wyckoff_sites"]).astype(bool)
    dct["frozen_wyckoff_sites"] = frozen_wyckoff_sites

    # Fixed variables
    if opt["increment"] is None:
        raise RuntimeError("The mandatory increment argument is not set.")
    list_state_dict = []
    list_sizes = []
    for increment_dict in (
        opt["increment"] if isinstance(opt["increment"], list) else [opt["increment"]]
    ):
        if isinstance(increment_dict, str):
            increment_dict = json.loads(increment_dict)
        mode = increment_dict["mode"] == "linear"
        num = increment_dict["number"]
        state_dict = {}
        for variable in list(increment_dict["initial"].keys()):
            start = increment_dict["initial"][variable]
            end = increment_dict["final"][variable]
            if variable == "composition":
                start = np.array(start) / sum(start)
                end = np.array(end) / sum(end)
            if np.allclose(start, end, atol=1e-10):
                state_dict[variable] = np.linspace(start, end, num).tolist()
            elif mode:
                state_dict[variable] = np.linspace(start, end, num).tolist()
            else:
                state_dict[variable] = np.logspace(
                    np.log10(start), np.log10(end), num
                ).tolist()
            if variable not in list(dct.keys()):
                dct[variable] = state_dict[variable][0]
        list_state_dict.append(state_dict)
        list_sizes.append(num)

    # MCEnsemble object
    mc_obj = getattr(mcmc, opt["ensemble"])
    ls_args = getfullargspec(mc_obj).args
    ls_args.pop(0)
    mc_args = {arg: dct[arg] for arg in ls_args}
    mc = mc_obj(**mc_args)
    if verbose:
        print(mc)

    ##############
    # Properties #
    ##############

    ls_prop = []
    prop_dict = opt["properties"]
    if isinstance(prop_dict, str):
        prop_dict = json.loads(prop_dict)
    if prop_dict is None:
        prop_dict = {}
    for prop_name in list(prop_dict.keys()):
        kwargs = prop_dict[prop_name]
        prop_calculator = getattr(properties, prop_name)(**kwargs)
        prop_calculator.set_calculator(
            prim=model.prim, reference_structure=config.get_structure()
        )
        ls_prop.append(prop_calculator)

    #############
    # Precision #
    #############

    if opt["precision"] is None:
        precision = {}
    elif isinstance(opt["precision"], str):
        precision = json.loads(opt["precision"])
    else:
        precision = {key: float(opt["precision"][key]) for key in opt["precision"]}

    #################
    # MC Simulation #
    #################

    data: dict = {}
    path_to_results_data = opt["path"]
    path_to_raw_data = opt["raw"]
    path_to_last_config = opt["path_to_configs"]
    if path_to_raw_data is not None:
        tar = tarfile.open(path_to_raw_data, "w:gz")
    if path_to_last_config is not None:
        last_occupations = {}

    counter = 0
    for state_dict, size in zip(list_state_dict, list_sizes):
        state_variables = list(state_dict.keys())
        for state_index in range(size):
            for variable in state_variables:
                if variable == "composition":
                    current_x = mc.composition
                    x = np.array(state_dict[variable][state_index], dtype=float)
                    x *= len(config.occupation) / x.sum()
                    if not np.allclose(current_x, x, atol=1e-10):
                        fill_occupancy(config, x, model.prim)
                        mc_args["config"]
                        mc = mc_obj(**mc_args)
                else:
                    mc_args[variable] = state_dict[variable][state_index]
                    getattr(mc, "set_%s" % variable)(state_dict[variable][state_index])
            mc.initialize_data()

            if verbose:
                print(
                    "\n%s simulation at:\n - " % opt["ensemble"]
                    + "\n - ".join(
                        [
                            "%s : %s" % (variable, str(getattr(mc, variable)))
                            for variable in mc.fixed_variables
                        ]
                    )
                )

            processed_data, timeseries_data = run.fixed_state(
                mc=mc,
                precision=precision,
                list_properties=ls_prop,
                N_uncorrelated_samples=opt["n_uncorrelated"],
                sampling_frequency=opt["sampling_frequency"],
                N_changes=opt["n_changes"],
                min_samples=opt["min"],
                max_samples=opt["max"],
                confidence=opt["confidence"],
                verbose=verbose,
            )

            merge_dict(data, processed_data)
            if path_to_results_data is not None:
                save_dict(data_dict=data, filename=path_to_results_data, indent=3)
            if path_to_raw_data is not None:
                save_dict(
                    data_dict=timeseries_data | {"config": config.as_dict()},
                    filename=path.join(
                        path.dirname(path_to_raw_data),
                        "mcmc_raw_data_%d.json" % counter,
                    ),
                    tar_obj=tar,
                )
            if path_to_last_config is not None:
                last_occupations["config"] = config.as_dict()
                last_occupations["%d" % counter] = timeseries_data["occupation"][-1]
                save_dict(data_dict=last_occupations, filename=path_to_last_config)
            counter += 1

        if verbose:
            print(mc)

    if path_to_raw_data is not None:
        tar.close()
    return data
