from argparse import Namespace

import numpy as np
import pandas as pd

from pyece.analysis.convexhull import (
    ConvexHull,
    get_binary_convexhull,
    plot_binary_hull,
)
from pyece.core.clex import eCE
from pyece.learn.data import DataBase


def pretty_print(args: Namespace | dict) -> None:
    """Master function to pretty print pyeCE objects.

    Note
    ----
    The function takes the argument args being the Namespace object from argparse or a dictionary.

    Parameters
    ----------
    args.model: str, default: model.pth
        Path to the :py:obj:`~.pyece.core.clex.eCE` model.
    args.prim: bool, default: True
        Set to True to print information about the :py:obj:`~.pyece.core.prim.Prim` object of the eCE model.
    args.sitebasis: bool, default: True
        Set to True to print information about the :py:obj:`~.pyece.core.sitebasis.SiteBasis` object of the eCE model.
    args.features: bool, default: True
        Set to True to print information about the :py:obj:`~.pyece.core.features.Features` object of the eCE model.
    args.eci: bool, default: True
        Set to True to print information about the ECI network of the eCE model.
    args.orbit_tree: bool, default: True
        Set to True to print information about the :py:obj:`~.pyece.core.cluster.OrbitTree` object of the eCE model.
    args.data: str, default: ''
        Path to the processed dataset (DataBase object) in pickle dataframe format.
    args.convexhull: tuple(str), default: ['', '', '']
        Tuple of 3 strings with the path to processed dataset (DataBase object) in pickle dataframe format, the starting (xi) and ending (xf) compositions in string list fomat to construct the binary convex hull from the dataset.
    """

    def read_vector(input_vector) -> np.ndarray:
        if isinstance(input_vector, str):
            return np.fromstring(
                input_vector.replace("[", "").replace(",", " ").replace("]", ""),
                sep=" ",
            )
        else:
            return np.array(input_vector)

    # Build settings file
    if isinstance(args, Namespace):
        opt = vars(args)
    else:
        opt = args.copy()
    opt.pop("func")
    object_dict = {}

    # Load model
    model = eCE.load(opt["model"])
    object_dict["model"] = model

    if opt["prim"]:
        print(model.prim)
        object_dict["prim"] = model.prim
    if opt["sitebasis"]:
        print(model.sitebasis)
        object_dict["sitebasis"] = model.sitebasis
    if opt["features"]:
        print(model.features)
        object_dict["features"] = model.features
    if opt["eci"]:
        print("ECI")
        print(model.eci)
        object_dict["eci"] = model.eci
    if opt["orbit_tree"]:
        tree = model.get_orbit_tree()
        tree.print_all_orbits()
        object_dict["orbit_tree"] = tree
    if len(opt["data"]) > 0:
        data = DataBase.from_file(opt["data"])
        object_dict["data"] = data
        summary_data = data.summary()
        with pd.option_context(
            "display.max_rows", None, "display.max_columns", None, "display.width", 200
        ):
            print(summary_data)
    if opt["convexhull"] != ["", "", ""]:
        path = opt["convexhull"][0]
        xi = read_vector(opt["convexhull"][1])
        xf = read_vector(opt["convexhull"][2])
        data = DataBase.from_file(path)
        if xi.sum() != 1:
            raise ValueError(
                "The starting composition xi = %s is expected to sum to 1."
                % np.array2string(xi)
            )
        if xf.sum() != 1:
            raise ValueError(
                "The ending composition xf = %s is expected to sum to 1."
                % np.array2string(xf)
            )
        elements = [label[2:] for label in data.columns if "x_" in label]
        labels = [label for label in data.columns if "x_" in label][1:] + [
            "property",
        ]
        points = data[labels].to_numpy()
        binary_hull: ConvexHull = get_binary_convexhull(points, xi[1:], xf[1:])
        plot_binary_hull(
            binary_hull,
            "".join(
                [r"%s$_{%.2f}$" % (elem, x) for elem, x in zip(elements, xi) if x > 0]
            ),
            "".join(
                [r"%s$_{%.2f}$" % (elem, x) for elem, x in zip(elements, xf) if x > 0]
            ),
        )
        object_dict["binary_hull"] = binary_hull

    return object_dict
