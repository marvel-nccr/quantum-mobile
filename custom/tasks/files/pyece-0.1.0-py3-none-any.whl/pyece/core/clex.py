from __future__ import annotations

import datetime
import json
import os
import tarfile
import zipfile
from typing import cast

import numpy as np
import torch
import yaml
from numpy import ndarray
from torch import Tensor, load, nn, save

from pyece.core.cluster import OrbitTree, orbit_tree_length_filter
from pyece.core.features import Features
from pyece.core.prim import Prim
from pyece.core.sitebasis import SiteBasis
from pyece.utils.toolbox import segment


class eCE(nn.Module):
    """
    Embedded cluster expansion model with site basis projection and neural network ECI.

    :py:obj:`eCE` models are on-lattice models composed of 3 submodules that are (See :doc:`description`):
        - The **site-basis functions** that are treated by the :py:obj:`~.pyece.core.sitebasis.SiteBasis` object. These functions take a chemical specie as input and returns a scalar.
        - The **correlation functions** (also called symmetrized cluster functions) that are treated by the :py:obj:`~.pyece.core.features.Features` object. These functions are descriptors of the local environment around a primitive unitcell. They take the site-basis functions evaluated on each site on the lattice as input and return a scalar.
        - The \'Effective Cluster Interactions\' (ECI) that are treated by a pytorch neural network :obj:`Module`. The module takes the descriptors as input and returns the evaluated property.
    The lattice together with the degrees of freedom in each sublattice is determined by the :py:obj:`~.pyece.core.prim.Prim` object.

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice
    sitebasis: SiteBasis
        SiteBasis object
    features: Features
        Features object
    eci: nn.Module,
        Pytorch module object used to evaluate the property of interest from cluster functions
    metadata: dict, default: {}
        Dictionary with metadata to related to the construction of the model. It typically consists of the setting files.
    per_unitcell: bool, default: True
        Set to True to normalize the property by the number of unitcell in the configuration (value per unitcell), if set to false the property extensive.

    Tip
    ---
    :py:obj:`~eCE` objects can conveniently be constructed using the function :py:meth:`~from_settings` from a POSCAR file and a JSOn file or using the function :py:meth:`~tar_load` to load an already-existing model from a gzip compressed tarfile.

    Attributes
    ----------
    prim: Prim
        Prim object containing all references to the lattice
    sitebasis: SiteBasis
        SiteBasis object
    features: Features
        Features object
    eci: nn.Module,
        Pytorch module object used to evaluate the property of interest from cluster functions
    metadata: dict
        Dictionary with metadata to related to the construction of the model. It typically consists of the setting files.
    reduce: bool
        Defines the reduction mode during the computation of the property. If set to \'mean\', the property is normalized by the number of unitcell in the configuration (value per unitcell). Otherwise, if set to \'sum\', the computed property is extensive.
    production: bool
        Defines the production mode. When False, the :py:obj:`~.pyece.core.sitebasis.SiteBasis` can be trained. While True, fixes the site-basis functions in :py:obj:`~.pyece.core.sitebasis.SiteBasis`.

        Tip:
        ---
        Set it to False during training and True during MCMC simulations in order to speed up the evaluation time. Use the method :py:meth:`~prod` to modify this attribute.

    """

    def __init__(
        self,
        prim: Prim,
        sitebasis: SiteBasis,
        features: Features,
        eci: nn.Module,
        metadata: dict = {},
        per_unitcell: bool = True,
    ) -> None:
        super().__init__()

        self.prim: Prim = prim
        self.sitebasis: SiteBasis = sitebasis
        self.features: Features = features
        self.eci: nn.Module = eci
        self.metadata: dict = metadata

        self.register_buffer("per_unitcell", torch.tensor(per_unitcell, dtype=bool))
        self.reduce: str = "mean" if per_unitcell else "sum"
        self.production: bool = False

        return

    def forward(
        self, neighborhood_occupations: Tensor, segment_indexes: Tensor | None = None
    ) -> Tensor:
        """
        Pytorch forward functions that evaluates the output of the model

        Parameters
        ----------
        neighborhood_occupations: Tensor
            Integer pytorch tensors with the chemical indexes in each neighborhoods that one wished to evaluate.
            The tensor must be a NxM tensor where N is the number of unitcell neighborhoods and M is the number of sites in the neighborhood.

            Warning
            -------
            The number of sites (M) per neighborhood must match the size of the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object used to construct the :py:obj:`~.pyece.core.clex.eCE` model.

        segment_indexes: Tensor | None, default: None
            Variable used to average together the evaluated local properties belonging to the same configurations.
            The varaiable must be a pytorch tensor with the indexes of the neighborhood occupations belonging together written in compressed format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_)
            None returns each evaluated local property independently.

        Returns
        -------
        Tensor
            Pytorch tensor with the evaluated properties
        """

        sitebasis_functions = (
            self.sitebasis.sitebasis_functions if self.production else self.sitebasis()
        )
        cluster_fcts = self.features(sitebasis_functions, neighborhood_occupations)
        unitcell_property = self.eci(cluster_fcts).flatten()
        if segment_indexes is not None:
            unitcell_property = segment(
                unitcell_property, segment_indexes, reduce=self.reduce
            )

        return unitcell_property

    def get_averaged_correlations(
        self, neighborhood_occupations: Tensor, segment_indexes: Tensor | None = None
    ) -> Tensor:
        """
        Evaluates the averaged correlation functions

        Parameters
        ----------
        neighborhood_occupations: Tensor
            Integer pytorch tensors with the chemical indexes in each neighborhoods that one wished to evaluate.
            The tensor must be a NxM tensor where N is the number of unitcell neighborhoods and M is the number of sites in the neighborhood.

            Warning
            -------
            The number of sites (M) per neighborhood must match the size of the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object used to construct the :py:obj:`~.pyece.core.clex.eCE` model.

        segment_indexes: Tensor | None, default: None
            Variable used to average together the evaluated local properties belonging to the same configurations.
            The varaiable must be a pytorch tensor with the indexes of the neighborhood occupations belonging together written in compressed format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_)
            None returns each evaluated local property independently.

        Returns
        -------
        Tensor
            Pytorch tensor with the evaluated average correlation functions for each configuration.
        """
        sitebasis_functions = self.sitebasis()
        cluster_fcts = self.features(sitebasis_functions, neighborhood_occupations)
        if segment_indexes is None:
            return (
                cluster_fcts.T.mean(dim=-1)
                # if self.per_unitcell
                # else cluster_fcts.T.sum(dim=-1)
            )
        else:
            return segment(cluster_fcts.T, segment_indexes, reduce=self.reduce).T

    def set_per_unitcell(self, mode: bool = True) -> None:
        """
        Set the model so that the property is normalized per unitcell.

        Parameters
        ----------
        mode: bool, default: True
            Whether to normalize the computed property per unitcell (True) or not (False).
        """
        if not isinstance(mode, bool):
            raise ValueError("Mode is expected to be boolean")
        self.per_unitcell = torch.tensor(mode, dtype=bool)
        self.reduce = "mean" if mode else "sum"
        return

    def prod(self, mode: bool = True) -> None:
        """
        Set the model in producing mode.

        Parameters
        ----------
        mode: bool, default: True
            Whether to set production mode (True) or not (False).
        """
        if not isinstance(mode, bool):
            raise ValueError("Producing mode is expected to be boolean")
        if mode:
            self.eval()
            self.production = mode
            self.sitebasis.prod(mode)
        return

    def normalize(self) -> None:
        """
        Normalize the the rows of the SiteBasis object
        """
        self.sitebasis.normalize()
        return

    def set_eci_layer(self, initial_matrix: ndarray, layer_index: int) -> None:
        """
        Function used to initialize a given layer of the ECI neural network with a self-determined matrix.

        Parameters
        ----------
        initial_matrix: ndarray
            Numpy array with the initial self-determined layer matrix.
        layer_index: int
            Index of the layer in :py:attr:`eci` to intialize.
        """
        device = self.eci[0].weight.data.device
        self.eci[layer_index].weight.data = torch.tensor(
            initial_matrix,
            device=device,
        ).float()
        return

    def get_orbit_tree(self) -> OrbitTree:
        """
        Recomputes the :py:obj:`~.pyece.core.cluster.OrbitTree` object from the :py:attr:`metadata` dictionary.

        Returns
        -------
        tree: OrbitTree
        """
        if "build" not in self.metadata.keys():
            raise ValueError("The metadata do not contain the build settings.")
        dict_settings = self.metadata["build"]

        # Cluster constraints
        list_cluster_size = list(
            dict_settings["orbit_tree_specs"]["orbit_tree_length_filter"].keys()
        )
        max_body_order = np.max(np.array(list_cluster_size).astype(int))

        # Build orbit tree
        def filter_condition(cluster):
            return orbit_tree_length_filter(
                cluster=cluster,
                orbit_specs=dict_settings["orbit_tree_specs"][
                    "orbit_tree_length_filter"
                ],
            )

        # Construct orbit tree
        tree = OrbitTree.generate(
            prim=self.prim,
            max_body_order=max_body_order,
            condition=filter_condition,
        )
        return tree

    def save(self, path_to_save: str, save_eci_model: bool = False):
        """
        Save the model in current state as the pytorch way (zip file)

        Parameters
        ----------
        path_to_save: str
            Path of the location to save the file
        """

        # Check if necessitates self.tar_save
        if path_to_save[-6:] == "tar.gz":
            # The extension corresponds to a tar_save method
            self.tar_save(path_to_save)
            return
        if not self.metadata["generated_from_settings"]:
            # The eci model is not generated by build_FNN and necessitates the tar_save method
            self.tar_save(path_to_save)
            return
        if save_eci_model:
            # In order to save the eci model, one necessitates the tar_save method
            self.tar_save(path_to_save)
            return

        # Files to save
        prim = json.dumps(self.prim.as_dict(), indent=3)
        metadata = json.dumps(self.metadata, indent=3)

        # Save the state
        torch.save(self.state_dict(), path_to_save)

        # Save the files
        model_name = os.path.basename(os.path.splitext(path_to_save)[0])
        with zipfile.ZipFile(path_to_save, "a") as zip_file:
            zip_file.writestr(os.path.join(model_name, "prim.json"), prim)
            zip_file.writestr(os.path.join(model_name, "metadata.json"), metadata)

        return

    @classmethod
    def load(cls, path_to_load: str):
        """
        Load the model from a gzip compressed tarfile

        Parameters
        ----------
        path_to_load: str
            Path of the location to load the file from.
        """

        def tar_load(path_to_load):
            with tarfile.open(path_to_load, "r:gz") as tar:
                state = load(tar.extractfile("eCE_state.pth"))

                # Load prim
                prim_dct = json.load(tar.extractfile("prim.json"))
                prim = Prim.from_dict(prim_dct)

                # Load sitebasis
                list_species_in = [
                    (state[key])
                    for key in state.keys()
                    if "sitebasis.species_in" in key
                ]
                list_dim_out = state["sitebasis.list_dim_out"]
                neighbor_basis_index = state["sitebasis.neighbor_basis_index"]
                list_basis = [
                    (state[key]) for key in state.keys() if "sitebasis.basis" in key
                ]
                sitebasis = SiteBasis(
                    list_species_in, list_dim_out, neighbor_basis_index, list_basis
                )

                # Load features
                selection_matrix = state["features.selection_matrix"]
                symmetrization_segment_indexes = state[
                    "features.symmetrization_segment_indexes"
                ].reshape(-1)
                symmetrization_factors = state["features.symmetrization_factors"]
                orbit_tracker = {}
                for key in state.keys():
                    if "features.Orbit" in key:
                        orbit_tracker[key.split(".")[-1]] = state[key].tolist()
                features = Features(
                    selection_matrix,
                    symmetrization_segment_indexes,
                    symmetrization_factors,
                    orbit_tracker,
                )

                # per_unitcell
                if "per_unitcell" in state.keys():
                    per_unitcell = bool(state["per_unitcell"])
                else:
                    per_unitcell = True
                    state["per_unitcell"] = torch.tensor(per_unitcell, dtype=bool)

                # Load ECI model
                tar.extract("eci.pth")
                eci = load("eci.pth", weights_only=False)
                os.remove("eci.pth")

                # Load metadata
                metadata = {}
                if "metadata.json" in tar.getnames():
                    metadata = json.load(tar.extractfile("metadata.json"))

                tar.close()

            # Load eCE
            model = cls(prim, sitebasis, features, eci, metadata, per_unitcell)
            model.load_state_dict(state)
            return model

        # Check if necessitates the tar_load method
        if path_to_load[-6:] == "tar.gz":
            # The extension corresponds to a tar_load method
            return tar_load(path_to_load)

        # Load files
        model_name = os.path.basename(os.path.splitext(path_to_load)[0])
        state = load(path_to_load)
        with zipfile.ZipFile(path_to_load) as zf:
            with zf.open(os.path.join(model_name, "prim.json"), "r") as f:
                prim_dict = json.load(f)
                f.close
            with zf.open(os.path.join(model_name, "metadata.json"), "r") as f:
                metadata = json.load(f)
                f.close
        dict_settings = metadata["build"]

        # Load prim
        prim = Prim.from_dict(prim_dict)

        # Load sitebasis
        list_species_in = [
            (state[key]) for key in state.keys() if "sitebasis.species_in" in key
        ]
        list_dim_out = state["sitebasis.list_dim_out"]
        neighbor_basis_index = state["sitebasis.neighbor_basis_index"]
        list_basis = [(state[key]) for key in state.keys() if "sitebasis.basis" in key]
        sitebasis = SiteBasis(
            list_species_in, list_dim_out, neighbor_basis_index, list_basis
        )

        # Load features
        selection_matrix = state["features.selection_matrix"]
        symmetrization_segment_indexes = state[
            "features.symmetrization_segment_indexes"
        ].reshape(-1)
        symmetrization_factors = state["features.symmetrization_factors"]
        orbit_tracker = {}
        for key in state.keys():
            if "features.Orbit" in key:
                orbit_tracker[key.split(".")[-1]] = state[key].tolist()
        orbit_lengths = {}
        for key in state.keys():
            if "features.Lengths_Orbit" in key:
                orbit_lengths[key.split(".")[-1][8:]] = state[key].tolist()
        features = Features(
            selection_matrix,
            symmetrization_segment_indexes,
            symmetrization_factors,
            orbit_tracker,
            orbit_lengths,
        )

        # per_unitcell
        if "per_unitcell" in state.keys():
            per_unitcell = bool(state["per_unitcell"])
        else:
            per_unitcell = True
            state["per_unitcell"] = torch.tensor(per_unitcell, dtype=bool)

        # Load ECI model
        nn_layers = cast(list[int], dict_settings["nn_layers"])
        activation_name = cast(str, dict_settings["activation"])
        eci = build_FNN(
            nodes_per_layers=[features.N_features] + nn_layers + [1],
            activation=getattr(nn, activation_name),
        )

        # Load eCE
        model = cls(prim, sitebasis, features, eci, metadata, per_unitcell)
        model.load_state_dict(state)
        return model

    def tar_save(self, path_to_save: str):
        """
        Save the model in current state as a gzip compressed tarfile

        Parameters
        ----------
        path_to_save: str
            Path of the location to save the file
        """

        with tarfile.open(path_to_save, "w:gz") as tar:

            def save_dict(dct: dict, filename: str, indent: bool = False):
                with open(filename, "w", encoding="utf8") as f:
                    json.dump(dct, f, indent=3 if indent else None)
                    f.close()
                tar.add(filename, arcname=os.path.basename(filename))
                os.remove(filename)

            # Save prim
            filename = os.path.join(os.path.dirname(path_to_save), "prim.json")
            save_dict(self.prim.as_dict(), filename)

            # Save eCE model state
            filename = os.path.join(os.path.dirname(path_to_save), "eCE_state.pth")
            save(self.state_dict(), filename)
            tar.add(filename, arcname="eCE_state.pth")
            os.remove(filename)

            # Save eci model
            filename = os.path.join(os.path.dirname(path_to_save), "eci.pth")
            save(self.eci, filename)
            tar.add(filename, arcname="eci.pth")
            os.remove(filename)

            # Save metadata
            filename = os.path.join(os.path.dirname(path_to_save), "metadata.json")
            if self.metadata:
                save_dict(self.metadata, filename, indent=True)

            tar.close()

        return

    @classmethod
    def tar_load(cls, path_to_load: str):
        """
        Load the model from a gzip compressed tarfile

        Parameters
        ----------
        path_to_load: str
            Path of the location to load the file from.
        """

        with tarfile.open(path_to_load, "r:gz") as tar:
            state = load(tar.extractfile("eCE_state.pth"))

            # Load prim
            prim_dct = json.load(tar.extractfile("prim.json"))
            prim = Prim.from_dict(prim_dct)

            # Load sitebasis
            list_species_in = [
                (state[key]) for key in state.keys() if "sitebasis.species_in" in key
            ]
            list_dim_out = state["sitebasis.list_dim_out"]
            neighbor_basis_index = state["sitebasis.neighbor_basis_index"]
            list_basis = [
                (state[key]) for key in state.keys() if "sitebasis.basis" in key
            ]
            sitebasis = SiteBasis(
                list_species_in, list_dim_out, neighbor_basis_index, list_basis
            )

            # Load features
            selection_matrix = state["features.selection_matrix"]
            symmetrization_segment_indexes = state[
                "features.symmetrization_segment_indexes"
            ].reshape(-1)
            symmetrization_factors = state["features.symmetrization_factors"]
            orbit_tracker = {}
            for key in state.keys():
                if "features.Orbit" in key:
                    orbit_tracker[key.split(".")[-1]] = state[key].tolist()
            orbit_lengths = {}
            for key in state.keys():
                if "features.Lengths_Orbit" in key:
                    orbit_lengths[key.split(".")[-1][8:]] = state[key].tolist()
            features = Features(
                selection_matrix,
                symmetrization_segment_indexes,
                symmetrization_factors,
                orbit_tracker,
                orbit_lengths,
            )

            # per_unitcell
            if "per_unitcell" in state.keys():
                per_unitcell = bool(state["per_unitcell"])
            else:
                per_unitcell = True
                state["per_unitcell"] = torch.tensor(per_unitcell, dtype=bool)

            # Load ECI model
            tar.extract("eci.pth")
            eci = load("eci.pth", weights_only=False)
            os.remove("eci.pth")

            # Load metadata
            metadata = {}
            if "metadata.json" in tar.getnames():
                metadata = json.load(tar.extractfile("metadata.json"))

            tar.close()

        # Load eCE

        model = cls(prim, sitebasis, features, eci, metadata, per_unitcell)
        model.load_state_dict(state)

        return model

    @classmethod
    def from_settings(
        cls, settings: str | dict, verbose: bool = True, prim: Prim | None = None
    ):
        """Read the settings input file with all the settings to construct the :py:obj:`eCE` model.

        Parameters
        ----------
        settings: str | dict
            Either a string with the path to the settings file containing in YAML format or a dictionary with the settings following to the same format as the settings file.

            Note
            ----
            Any missing parameters will be assigned the default settings as follows::

                {
                    "prim": "PRIM",
                    "accuracy": 6,
                    "symprec": None,
                    "angle_tolerance": None,
                    "basis": "chebyshev",
                    "orbit_tree_specs": {
                        "orbit_tree_length_filter": {
                            "0": {"min_length": 0, "max_length": 0},
                            "1": {"min_length": 0, "max_length": 0},
                            "2": {"min_length": 0, "max_length": 8}
                        }
                    },
                    "embedding_dimensions": [],
                    "nn_layers": [32, 32, 8],
                    "activation": "ReLU",
                    "globally_invariant": False,
                    "per_unitcell": True,
                }



            Note
            ----
            An empty list for the embedding_dimension parameter results in an automatic determination of the number of embedding dimesions such that the chemical embedding accounts for 95% of the variance.
            A scalar array for the embedding_dimensions parameter results in setting the same values for each Wyckoff group.
            Finally, a scalar array with value smaller or equal to 0 results in setting no embedding dimensions (i.e., embedding dimensions are equal to the number of allowed elements).

        verbose: bool, default : True
            Set to True to print information about the model as it is built
        prim: Prim | None, default: None
            (Optional) Prim object containing all references to the lattice. If provided, it uses this Prim object to build the eCE model.

        Returns
        -------
        eCE
            eCE model

        Example
        -------
        Below is an example of such a settings file.
        The path to the
        The eCE model is considers clusters with a maximum of 3 atoms (maximum body order is 3), whose maximum lengths are 10 A for the pair clusters and 4 A for the triplet clusters.
        The considered system contains 2 inequivalent sublattices projected to 2 and 3 embedding dimensions, respectively.
        Finally, the ECI neural network consists of 3 hidden layers with 32, 32, and 8 nodes, respectively, using ReLU activation functions between each layer:

        .. code-block:: YAML

            # Prim specifications
            "prim" : "PRIM"                        # Path to the PRIM file
            "basis": "chebyshev"                   # Full rank basis [`chebyshev`, `occupational`]
            "orbit_tree_specs":                    # Path to the PRIM file
               "orbit_tree_length_filter":         # Constraints on the orbit tree based on the cluster dimensions
                   "0":                            # Empty cluster
                       "min_length": 0
                       "max_length": 0
                   "1":                            # Point clusters
                       "min_length": 0
                       "max_length": 0
                   "2":                            # Pair clusters
                       "min_length": 0
                       "max_length": 10
                   "3":                            # Triplet clusters
                       "min_length": 0
                       "max_length": 4

            # ECI neural network specifications
            "embedding_dimensions": [3]            # Number of embedding dimensions for each site in the unitcell
            "nn_layers": [32, 32, 8]               # Number of nodes in each hidden layers
            "activation": "ReLU"                   # Activation function
            "globally_invariant": false            # Globally-invariant orbits as opposed to locally-invariant (i.e., site-centric) orbits (to be used if using a linear model)
            "normalization": True                  # Normalize the correlation functions per size of the orbit and number of permutations
            "per_unitcell": True                   # Normalize the computed property per unitcell
        """

        # Default settings
        dict_settings = {
            "prim": "PRIM",
            "accuracy": 6,
            "symprec": None,
            "angle_tolerance": None,
            "basis": "chebyshev",
            "orbit_tree_specs": {
                "orbit_tree_length_filter": {
                    "0": {},
                    "1": {},
                    "2": {"max_length": 8},
                }
            },
            "embedding_dimensions": [],
            "nn_layers": [32, 32, 8],
            "activation": "ReLU",
            "globally_invariant": False,
            "normalization": True,
            "per_unitcell": True,
        }

        # Load file
        if isinstance(settings, str):
            with open(settings) as f:
                dict_settings.update(yaml.load(f, Loader=yaml.SafeLoader))
                f.close()
        else:
            dict_settings.update(settings)

        # Cluster constraints
        list_cluster_size = list(
            dict_settings["orbit_tree_specs"]["orbit_tree_length_filter"].keys()
        )
        max_lengths = [
            (
                dict_settings["orbit_tree_specs"]["orbit_tree_length_filter"][key][
                    "max_length"
                ]
                if "max_length"
                in dict_settings["orbit_tree_specs"]["orbit_tree_length_filter"][key]
                else 0
            )
            for key in list_cluster_size
        ]

        # Prim object
        if prim is None:
            new_prim = Prim.from_file(
                path_to_file=dict_settings["prim"],
                accuracy=dict_settings["accuracy"],
                symprec=dict_settings["symprec"],
                angle_tolerance=dict_settings["angle_tolerance"],
            )
        else:
            new_prim = Prim.from_dict(prim.as_dict())

        new_prim.get_neighborhood(cutoff=max(max_lengths))
        if verbose:
            print(new_prim)

        # Build orbit tree
        def filter_condition(cluster):
            return orbit_tree_length_filter(
                cluster=cluster,
                orbit_specs=dict_settings["orbit_tree_specs"][
                    "orbit_tree_length_filter"
                ],
            )

        max_body_order = np.max(np.array(list_cluster_size).astype(int))
        tree = OrbitTree.generate(
            prim=new_prim,
            max_body_order=max_body_order,
            condition=filter_condition,
        )
        if verbose:
            print(tree)

        # Build basis
        sitebasis = SiteBasis.build_sitebasis(
            prim=new_prim,
            embedding_dimensions=np.array(
                dict_settings["embedding_dimensions"], dtype=int
            ),
            basis_type=dict_settings["basis"],
        )
        sitebasis.initialize(new_prim)
        if verbose:
            print(sitebasis)

        # Build features
        features = Features.build_features(
            tree=tree,
            sitebasis=sitebasis,
            site_centric=(not dict_settings["globally_invariant"]),
            normalization=dict_settings["normalization"],
        )
        if verbose:
            print(features)

        # Metadata
        now = datetime.datetime.now()
        metadata = {
            "generated_from_settings": True,
            "build": dict_settings | {"built_on": str(now)},
        }

        nn_layers = cast(list[int], dict_settings["nn_layers"])
        activation_name = cast(str, dict_settings["activation"])

        # Build eCE
        ECI = build_FNN(
            nodes_per_layers=[features.N_features] + nn_layers + [1],
            activation=getattr(nn, activation_name),
        )
        model = cls(
            prim=new_prim,
            sitebasis=sitebasis,
            features=features,
            eci=ECI,
            metadata=metadata,
            per_unitcell=dict_settings["per_unitcell"],
        )
        if verbose:
            print(model)
        return model


def build_FNN(nodes_per_layers: list[int], activation: nn.Module) -> nn.Module:
    """
    Constructs a Pytorch feed forward fully connected neural network

    Parameters
    ----------
    nodes_per_layers: list[int]
        Number of nodes per layers
    activation: nn.Module
        Pytorch activation function between each layers.

    Returns
    -------
    FNN: nn.Module
        Pytorch module of the feed forward fully connected neural network
    """
    FNN = nn.Sequential(
        nn.Linear(
            nodes_per_layers[0],
            nodes_per_layers[1],
            bias=False,
        )
    )
    for layer_index in range(2, len(nodes_per_layers)):
        FNN.append(activation())
        FNN.append(
            nn.Linear(nodes_per_layers[layer_index - 1], nodes_per_layers[layer_index])
        )
    return FNN
