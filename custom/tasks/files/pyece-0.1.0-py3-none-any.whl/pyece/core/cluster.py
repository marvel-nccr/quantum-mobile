from typing import Callable

import numpy as np
from numpy.typing import NDArray
from tabulate import SEPARATING_LINE, tabulate

from pyece.core.prim import Prim
from pyece.utils.coordinates import unitcell_to_fractional
from pyece.utils.symmetry import get_cosets


class Cluster:
    """
    Represents a finite collection of distinct atoms.

    A cluster is composed of atoms belonging to the neighborhood of the primitive unitcell, i.e., atoms in the neighborhood attribute of the Prim object. Hence, instead of describing a cluster by a collection of coordinates, the cluster is conveniently described by a collection of indexes referring to the atoms in the neighborhood.

    Note
    ----
    As a user, you will usually not interact directly with objects of this type.

    Parameters
    ----------
    atom_indexes: np.ndarray[int]
        Integer numpy array of the indexes of the atoms composing the cluster in the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object.
    prim: Prim
        Prim object containing all references to the lattice

    Attributes
    ----------
    indexes : np.ndarray[int]
        Integer numpy array of the indexes of the atoms in the cluster in the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object.
    unitcell_coord: np.ndarray[int]
        Integer numpy array of the unitcell coordinates of the atoms in the cluster
    fractional_coord: np.ndarray
        Numpy array of the fractional coordinates of the atoms in the cluster
    cartesian_coord: np.ndarray
        Numpy array of the cartesian coordinates of the atoms in the cluster
    orbit_indexes: np.ndarray[int]
        Integer numpy array of collection of indexes for each cluster in the orbit.
    """

    def __init__(self, atom_indexes: NDArray[np.int_], prim: Prim) -> None:
        assert (
            len(atom_indexes.shape) == 1
        ), "atom_indexes must be a 1-dimensional array of indexes."
        assert hasattr(
            prim, "neighborhood"
        ), "The 'neighborhood' attribute of the Prim object is not constructed yet."

        # Center cluster
        # Ensures that at least one atom in the cluster lies in the primitive unitcell.
        # By default, the first atom is chosen to be the centered one.
        atom_indexes = np.array(atom_indexes, dtype=int)
        unitcell_coord = prim.neighborhood[atom_indexes]
        if len(atom_indexes) > 0:
            unitcell_coord = center_cluster(unitcell_coord)[0][0]

        self.indexes: NDArray[np.int_] = prim.get_neighbor_site_indexes(unitcell_coord)
        self.unitcell_coord: NDArray[np.int_] = unitcell_coord
        self.fractional_coord: np.ndarray = unitcell_to_fractional(
            self.unitcell_coord, prim.basis
        )
        self.cartesian_coord: np.ndarray = prim.lattice.get_cartesian_coords(
            self.fractional_coord
        )

        return

    def __len__(self) -> int:
        return len(self.indexes)

    def __contains__(self, atom_index: int) -> bool:
        if len(self) == 0:
            return False
        return atom_index in self.indexes

    def __str__(self) -> str:
        return np.array2string(self.unitcell_coord)

    def get_cluster_lengths(self) -> np.ndarray:
        """
        Returns all distances between two atoms in the cluster

        Returns
        -------
        lengths: np.ndarray
            Numpy array of all distances between two atoms in the cluster
        """

        if len(self) < 2:
            return np.array([0])

        pairs = np.triu_indices(len(self), 1)
        lengths = np.linalg.norm(
            self.cartesian_coord[pairs[0]] - self.cartesian_coord[pairs[1]], axis=-1
        )
        return lengths

    def get_basis(self) -> NDArray[np.int_]:
        """
        Returns the primitive basis sites for all atoms composing the cluster

        Returns
        -------
        np.ndarray[int]
            Integer numpy array the basis index of all atoms in the cluster
        """
        return self.unitcell_coord[:, -1]

    def apply_symmetry_operations(
        self, prim: Prim, symmop_indexes: NDArray[np.int_]
    ) -> NDArray[np.int_]:
        """
        Apply a list of symmetry operations on the cluster

        The function returns a 2-dimensional array of the indexes referring to the atoms in the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object. Each row of the array corresponds to original cluster transformed by one of the symmetry operations listed in ``symmop_indexes``

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        symmop_index: int
            Index of the symmetry operation as listed in :py:attr:`pyece.core.prim.Prim.spacegroup_symmops`

        Returns
        -------
        indexes: np.ndarray[int]
            Integer numpy array of the indexes of each neighbor corresponding to each atoms
        """
        clusters = prim.apply_symmop(self.unitcell_coord, symmop_indexes)
        indexes = prim.get_neighbor_site_indexes(clusters)

        return indexes

    def get_cluster_orbit(self, prim: Prim) -> NDArray[np.int_]:
        """
        Computes all symmetry operations (:py:attr:`~.pyece.core.prim.Prim.spacegroup_symmops`) in :py:obj:`~.pyece.core.prim.Prim` object leaving at least one atom within the unitcell.
        The method returns all symmetrically-equivalent clusters, regardless of duplicate clusters. The clusters are centered to the first atom (i.e., the first atom is quaranteed to lie within the primitive unitcell).


        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice

        Returns
        -------
        centered_clusters: np.ndarray[int]
            Integer numpy array with the indexes of atoms composing each cluster in the orbit
        """

        if len(self) == 0:
            self.orbit_indexes = np.zeros(
                [len(prim.spacegroup_symmops), 0], dtype=np.int_
            )
            return self.orbit_indexes

        # Apply all symmetry operations
        clusters = prim.apply_symmop(
            self.unitcell_coord, np.arange(len(prim.spacegroup_symmops))
        )

        # Center operated clusters to each atom
        centered_clusters = center_cluster(clusters)[0]

        # Get atom indexes referred to the neighborhood
        self.orbit_indexes = prim.get_neighbor_site_indexes(centered_clusters)

        return self.orbit_indexes

    def invariant_symmetry_subgroup(
        self, permutations_allowed: bool = True
    ) -> tuple[NDArray[np.int_], NDArray[np.int_]]:
        """
        Determine the subgroup of symmetry operations (:py:attr:`~.pyece.core.prim.Prim.spacegroup_symmops`) that leave the cluster unchanged (stabilizer)

        There are two variants for considering two clusters as identical:
            1) All atom indexes are identical and are arranged the same way as in the orginal cluster (permutations are not allowed)
            2) All atom indexes are identicalas the original cluster but might be arranged differently (permutation-invariant <=> permutations are allowed)

        Parameters
        ----------
        permutations_allowed : bool, default: True
            Set to True if permutations are allowed.

        Returns
        -------
        tuple[np.ndarray[int], np.ndarray[int]]
            Tuple containing an integer numpy array with the indexes of the symmetry operations (:py:attr:`~.pyece.core.prim.Prim.spacegroup_symmops`) in the :py:obj:`~.pyece.core.prim.Prim` object and the indexes of the atoms composing each cluster.
        """

        assert hasattr(
            self, "orbit_indexes"
        ), "The 'orbit_indexes' attribute of the Cluster object is not built yet."

        if self.orbit_indexes.shape[-1] == 0:
            return (
                np.arange(len(self.orbit_indexes)).astype(int),
                np.arange(len(self.orbit_indexes)).astype(int),
            )

        list_clusters = (
            np.sort(self.orbit_indexes, axis=-1)
            if permutations_allowed
            else self.orbit_indexes
        )
        cluster = np.sort(self.indexes) if permutations_allowed else self.indexes

        indexes = np.nonzero(np.linalg.norm(list_clusters - cluster, axis=-1) == 0)
        subgroup = np.unique(indexes[0])
        list_clusters = self.orbit_indexes[indexes[0], indexes[1]]

        return (subgroup, list_clusters)

    def invariant_permutations(self) -> NDArray[np.int_]:
        """
        Determine all symmetrically-equivalent permutations of atoms that leave the cluster unchanged, i.e., permutations of the atoms in the cluster.

        To determine the invariant permutations, one determines the subgroup of symmetry operations that leave the cluster unchanged up to permutations with :py:meth:`~.pyece.core.cluster.Cluster.invariant_symmetry_subgroup`.
        Then, applying all symmetry operations of the subgroup to the original cluster results in identical clusters whose atoms may have different arrangements. These permutations in the arrangement of atoms constitute the set of invariant permutations.
        All these invariant permutations result from the application of symmetry operations.

        Returns
        -------
        permutations: np.ndarray[int]
            Integer numpy array with all permuations of atoms
        """

        permutations = self.invariant_symmetry_subgroup(permutations_allowed=True)[1]
        permutations = np.unique(permutations, axis=0)
        self.permutations = np.argsort(permutations)

        return self.permutations

    def add_atom(self, atom_index: int, prim: Prim):
        """
        Add the atom to the cluster

        Parameters
        ----------
        atom_index: int
            Index of the atom as found in :py:attr:`~.pyece.core.prim.Prim.neighborhood` to be added to the cluster
        prim: Prim
            Prim object containing all references to the lattice

        Returns
        -------
        Cluster
            Cluster object of the new cluster
        """

        return Cluster(np.append(self.indexes, atom_index), prim)

    def as_dict(self) -> dict:
        """
        MSONable dictionary representation of the :py:obj:`~.pyece.core.cluster.Cluster` object.
        """
        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "indexes": self.indexes.tolist(),
            "unitcell_coord": self.unitcell_coord.tolist(),
            "fractional_coord": self.fractional_coord.tolist(),
            "cartesian_coord": self.cartesian_coord.tolist(),
        }
        return dct


class Orbit:
    """
    Represents a collection of symmetrically equivalent atomic clusters.

    This class handles groups of atoms that are equivalent under symmetry operations,
    managing both their geometric arrangements and transformations.

    The construction of the orbit relies on basic results of group theory (See :doc:`description`).
    Essentially, one constructs a subgroup of the spacegroup :py:attr:`~.pyece.core.prim.Prim.spacegroup_symmops` composed of operations that leave the cluster identical, up to a lattice translation and permutations.
    Using this subgroup, one can partition the spacegroup into cosets (collections of symmetry operations). Two operations from the same coset, hence, results in identical clusters.
    One can thus choose only one representative operation in each coset (say the first element) to construct the orbit.

    There are three types of orbits such that at least one atom is in the primitive unitcell:
        1) :py:attr:`unique_orbit`: collection of translation and permutation distinct clusters.
        2) :py:attr:`sitecentric_orbit`: collection of permutation distinct clusters.
        3) :py:attr:`full_orbit`: collection of clusters obtained by performing all symmetry operations and centering the cluster to each atom in the cluster.

    Note
    ----
    As a user, you will usually not interact directly with objects of this type.

    Parameters
    ----------
    cluster: Cluster
        Cluster object of one representative of the orbit
    prim: Prim
        Prim object containing all references to the lattice

    Attributes
    ----------
    body_order: int
        Number of atoms in the cluster.
    lengths: np.ndarray
        The interatomic distances within the cluster.
    permutations: np.ndarray[int]
        Integer numpy array of index permutation arrays of atoms leaving the cluster symmetrically-equivalent.
    cosets: np.ndarray[int]
        Integer numpy array of cosets of symmetry operation indexes found in :py:attr:`~.pyece.core.prim.Prim.spacegroup_symmops`.
    unique_orbit: np.ndarray[int]
        Integer numpy array of collections of indexes of atoms found in :py:attr:`~.pyece.core.prim.Prim.neighborhood` that compose each cluster. It includes all translationally distinct clusters.
    sitecentric_orbit: np.ndarray[int]
        Integer numpy array of collections of indexes of atoms found in :py:attr:`~.pyece.core.prim.Prim.neighborhood` that compose each cluster. It includes all distinct clusters that have at least one atom centered in the primitive unitcell. A cluster may occur several time. Such a cluster is repeated as many times as there are atoms lying in the primitive unitcell (once of each site).
    full_orbit: np.ndarray[int]
        Integer numpy array of collections of indexes of atoms found in :py:attr:`~.pyece.core.prim.Prim.neighborhood` that compose all centered clusters obtained by applying all symmetry operations. It includes all possible symmetrically-equivalent clusters, differentiating centered atoms and permutations. Clusters may be repeated.
    prototype: np.ndarray[int]
        Integer numpy array of atom indexes of the reference cluster from which all other clusters can be generated. The indexes refer to the atoms in the :py:attr:`~.pyece.core.prim.Prim.neighborhood`.
    """

    def __init__(self, cluster: Cluster, prim: Prim) -> None:
        def check_orbit(full_orbit: NDArray[np.int_], cluster_orbit: NDArray[np.int_]):
            unique1 = np.unique(full_orbit, axis=0)
            unique2 = np.unique(cluster_orbit, axis=0)
            if not np.all(np.equal(unique1, unique2)):
                raise ValueError("The orbit is not complete")
            return

        if not hasattr(cluster, "orbit_indexes"):
            cluster.get_cluster_orbit(prim)

        # Body order
        self.body_order: int = len(cluster)

        # Lengths
        self.lengths: np.ndarray = cluster.get_cluster_lengths()

        # Invariant atomic site permutations
        self.permutations: NDArray[np.int_] = cluster.invariant_permutations()
        # Cosets of the cluster stabilizer to the spacegroup
        self.cosets: NDArray[np.int_] = get_cosets(
            prim.multiplication_table,
            cluster.invariant_symmetry_subgroup(permutations_allowed=True)[0],
        )

        # Symmetrically distinct orbit
        self.unique_orbit: NDArray[np.int_] = (
            cluster.orbit_indexes[self.cosets[:, 0], 0]
            if self.body_order != 0
            else np.zeros((1, 0), dtype=int)
        )
        # Site-centric orbit
        self.sitecentric_orbit: NDArray[np.int_] = (
            cluster.orbit_indexes[self.cosets[:, 0], :].reshape(-1, self.body_order)
            if self.body_order != 0
            else np.zeros((1, 0), dtype=int)
        )
        # Orbit with all symmetry operations applied to the cluster
        self.full_orbit: NDArray[np.int_] = (
            self.get_orbit_with_permutations(site_centric=True)
            if self.body_order != 0
            else np.zeros((1, 0), dtype=int)
        )

        # Prototypical cluster
        self.prototype: NDArray[np.int_] = cluster.indexes

        # Check
        if self.body_order != 0:
            check_orbit(
                self.full_orbit, cluster.orbit_indexes.reshape(-1, self.body_order)
            )

        return

    def __len__(self) -> int:
        return len(self.unique_orbit)

    def __contains__(self, cluster: Cluster) -> bool:
        if len(cluster) != self.body_order:
            return False
        test = (
            np.linalg.norm(
                np.sort(self.sitecentric_orbit, axis=-1) - np.sort(cluster.indexes),
                axis=-1,
            )
            == 0
        )
        return bool(np.any(test))

    def __str__(self) -> str:
        text = "\nOrbit:\n"
        text += "Lengths = %.3f/%.3f\n" % (np.max(self.lengths), np.min(self.lengths))
        text += "Subgroups: %s\n" % np.array2string(self.cosets[0])
        text += "Clusters:\n%s\n" % np.array2string(self.unique_orbit)
        text += "Permutations:\n%s" % np.array2string(self.permutations)
        text += "\n"
        return text

    def get_orbit_with_permutations(
        self, site_centric: bool = False
    ) -> NDArray[np.int_]:
        """
        Returns the indexes of the atoms in each cluster in the orbit, accounting for permutation.

        Parameters
        ----------
        site_centric: bool, default: False
            Set to True if site-centric orbit is desired.

        Returns
        -------
        indexes: np.ndarray[int]
            Integer numpy array of the indexes of atoms in each cluster in the orbit
        """

        if site_centric:
            indexes = np.take(self.sitecentric_orbit, self.permutations, axis=-1)
        else:
            indexes = np.take(self.unique_orbit, self.permutations, axis=-1)

        return indexes.reshape(-1, self.body_order)

    def get_orbit_coordinates(
        self, prim: Prim, site_centric: bool = False, permutations_allowed: bool = False
    ) -> NDArray[np.int_]:
        """
        Returns an array of all clusters in orbit in unitcell coordinates.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        site_centric: bool, default: False
            Set to True if site-centric orbit is desired.
        permutations_allowed: bool, default: False
            Set to True if permutations are allowed.

        Returns
        -------
        indexes: np.ndarray[int]
            Integer numpy array with the unitcell coordinates of atoms composing each cluster in the orbit
        """

        if self.body_order == 0:
            return np.zeros((1, 0), dtype=int)

        if site_centric and permutations_allowed:
            indexes = prim.neighborhood[self.get_orbit_with_permutations(site_centric)]
        elif not site_centric and permutations_allowed:
            indexes = prim.neighborhood[self.get_orbit_with_permutations(site_centric)]
        elif site_centric and not permutations_allowed:
            indexes = prim.neighborhood[self.sitecentric_orbit]
        elif not site_centric and not permutations_allowed:
            indexes = prim.neighborhood[self.unique_orbit]
        else:
            raise ValueError(
                "Invalid combination of site_centric and permutations_allowed."
            )

        return indexes

    def list_clusters(
        self, prim: Prim, site_centric: bool = False, permutations: bool = False
    ) -> list[Cluster]:
        """
        Returns a list of Cluster objects of all clusters in the orbit.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        site_centric: bool, default: False
            Set to True if site-centric orbit is desired.
        permutations: bool, default: False
            Set to True if permutations are desired.

        Returns
        -------
        list_clusters: list[Cluster]
            List of Cluster objects of all cluster in the orbit
        """

        if site_centric and permutations:
            indexes = self.get_orbit_with_permutations(site_centric)
        elif not site_centric and permutations:
            indexes = self.get_orbit_with_permutations(site_centric)
        elif site_centric and not permutations:
            indexes = self.sitecentric_orbit
        elif not site_centric and not permutations:
            indexes = self.unique_orbit
        else:
            raise ValueError(
                "Invalid combination of site_centric and permutations_allowed."
            )

        list_clusters = []
        for cluster in indexes:
            list_clusters.append(Cluster(cluster, prim))

        return list_clusters


class OrbitBranch:
    """
    Collection of :py:obj:`Orbit` of same body order

    Note
    ----
    As a user, you will usually not interact directly with objects of this type.

    Parameters
    ----------
    body_order: int
        Integer number corresponding to the number of atoms in each cluster

    Attributes
    ----------
    body_order: int
        Number of atoms in each cluster.
    list_orbits: list[Orbit]
        List of :py:obj:`Orbit` objects.
    """

    def __init__(self, body_order: int) -> None:
        self.body_order: int = body_order
        self.list_orbits: list[Orbit] = []

        return

    def __len__(self) -> int:
        return len(self.list_orbits)

    def __contains__(self, cluster: Cluster) -> bool:
        if len(cluster) != self.body_order:
            return False
        return bool(np.any([(cluster in orbit) for orbit in self.list_orbits]))

    def __str__(self) -> str:
        text = "\nBranch %d\n" % self.body_order
        text += "Contains the %d orbits represented by:\n" % len(self)
        for orbit in self.list_orbits:
            text += str(orbit.unique_orbit) + "\n"
        return text

    def add_orbit(self, orbit: Orbit) -> None:
        """
        Add the ``orbit`` to :py:attr:`list_orbits`.

        Parameters
        ----------
        orbit: Orbit
            Orbit object to be added to :py:attr:`list_orbits`
        """

        assert (
            orbit.body_order == self.body_order
        ), "Orbit body order doed not match the the body order of the branch."

        self.list_orbits.append(orbit)
        return


class OrbitTree:
    """
    Collection of :py:obj:`Orbit` objects ordered by body order in :py:obj:`OrbitBranch` objects

    Parameters
    ----------
    prim: Prim
        Prim object containing all references to the lattice

    Tip
    ---
    :py:obj:`OrbitTree` objects can conveniently be constructed using the function :py:meth:`~generate`.

    Attributes
    ----------
    prim: Prim
        Prim object.
    list_bodyorders: list[int]
        List of the body orders.
    list_branches: list[OrbitBranch]
        List of Branch objects sorted as in :py:attr:`list_bodyorders`.
    """

    def __init__(self, prim: Prim) -> None:
        self.prim: Prim = prim
        self.list_bodyorders: list[int] = []
        self.list_branches: list[OrbitBranch] = []

        return

    def __len__(self) -> int:
        return len(self.list_branches)

    def __contains__(self, cluster: Cluster) -> np.bool_:
        return np.any([(cluster in branch) for branch in self.list_branches])

    def __str__(self) -> str:
        """String representation."""
        table = []
        for i, body_order in enumerate(self.list_bodyorders):
            table.append(
                [
                    "Branch %d" % body_order,
                    ": ",
                    "%d Orbits" % len(self.list_branches[i]),
                ]
            )
        txt = tabulate([[tabulate(table, tablefmt="plain")]], tablefmt="heavy_grid")
        width = len(txt.split("\n")[0]) + 8
        txt = (
            "\n{s: ^{n}}\n".format(s="\033[1m ORBIT TREE \033[0m", n=width) + txt + "\n"
        )
        return txt

    def add_branch(self, branch: OrbitBranch) -> None:
        """
        Add the ``branch`` to :py:attr:`list_branches`.

        Parameters
        ----------
        branch: OrbitBranch
            Branch object to be added to :py:attr:`list_branches`
        """

        body_order = branch.body_order
        self.list_bodyorders.append(body_order)
        self.list_branches.append(branch)

        return

    def add_cluster(self, cluster: Cluster) -> None:
        """
        Add a ``cluster`` to the tree. If the ``cluster`` does not already belong to an :py:obj:`Orbit` in the tree, this function will create the :py:obj:`Orbit` and add it to the :py:obj:`OrbitBranch` in the tree.

        Parameters
        ----------
        cluster: Cluster
            Cluster object of one representative of the :py:obj:`Orbit`
        """

        if cluster not in self:
            # Create Orbit
            orbit = Orbit(cluster, self.prim)

            # Create Branch
            if orbit.body_order not in self.list_bodyorders:
                branch = OrbitBranch(orbit.body_order)
                self.add_branch(branch)

            # Add Orbit in Branch
            branch_index = self.list_bodyorders.index(orbit.body_order)
            self.list_branches[branch_index].add_orbit(orbit)

        return

    def sort_tree(self) -> None:
        """
        Sorts the ``orbits`` in the tree by increasing order of the length of the clusters.
        """

        for branch_index, branch in enumerate(self.list_branches):
            lengths = np.zeros(len(branch.list_orbits))
            for orbit_index, orbit in enumerate(branch.list_orbits):
                lengths[orbit_index] = np.max(orbit.lengths)
            orbit_order = np.argsort(lengths)
            self.list_branches[branch_index].list_orbits = [
                branch.list_orbits[arg] for arg in orbit_order
            ]
        return

    def get_site_indexes(self, site_centric: bool = True) -> NDArray[np.int_]:
        """
        Returns an array of the indexes of the neighbor atoms involved in any of the orbits included in the orbit tree.

        Parameters
        ----------
        site_centric: bool, default: True
            Set to True if site-centric orbit is desired.

        Returns
        -------
        indexes: np.ndarray[int]
            Integer array of the neighbor sites involved in the orbit tree
        """

        list_neighbor_sites = []
        for branch in self.list_branches:
            for orbit in branch.list_orbits:
                list_neighbor_sites.append(
                    orbit.sitecentric_orbit.flatten()
                    if site_centric
                    else orbit.unique_orbit.flatten()
                )
        array_neighbor_sites = np.hstack(list_neighbor_sites, dtype=int)

        indexes = np.unique(array_neighbor_sites)
        return indexes

    def print_all_orbits(
        self, site_centric: bool = False, permutations: bool = False
    ) -> str:
        """
        Pretty print all orbits contained in the tree.

        Parameters
        ----------
        site_centric: bool, default: False
            Set to True if site-centric orbit is desired.
        permutations: bool, default: False
            Set to True if permutations are desired.
        """
        tabs = []

        for branch_index, branch in enumerate(self.list_branches):
            body_order = branch.body_order
            for orbit_index, orbit in enumerate(branch.list_orbits):
                max_length = orbit.lengths.max()
                min_length = orbit.lengths.min()

                vectors = orbit.get_orbit_coordinates(
                    self.prim,
                    site_centric=site_centric,
                    permutations_allowed=permutations,
                )
                N = len(vectors)
                if body_order == 0:
                    vectors = np.array([["_", "_", "_", "_"]])
                vectors = vectors.reshape(-1, 4)
                table = [
                    [
                        tabulate(
                            [
                                [
                                    "\n".join(
                                        [
                                            "max length",
                                            "min length",
                                            "number of symmetries",
                                            "number of permutations",
                                        ]
                                    ),
                                    "\n".join(
                                        [
                                            "%.3f Å" % max_length,
                                            "%.3f Å" % min_length,
                                            "%d" % len(orbit.cosets[0]),
                                            "%d" % len(orbit.permutations),
                                        ]
                                    ),
                                ]
                            ],
                            tablefmt="plain",
                            colalign=("left", "right"),
                        )
                    ],
                    SEPARATING_LINE,
                    [
                        tabulate(
                            [
                                [
                                    "Index\n"
                                    + "\n".join(
                                        [
                                            (
                                                str(i)
                                                + ":"
                                                + (
                                                    "\n" * (body_order - 1)
                                                    if body_order > 0
                                                    else " "
                                                )
                                            )
                                            for i in range(N)
                                        ]
                                    ),
                                    "R_x\n"
                                    + "\n".join([str(v) for v in vectors[:, 0]]),
                                    "R_y\n"
                                    + "\n".join([str(v) for v in vectors[:, 1]]),
                                    "R_z\n"
                                    + "\n".join([str(v) for v in vectors[:, 2]]),
                                    "Basis\n"
                                    + "\n".join([str(v) for v in vectors[:, 3]]),
                                ]
                            ],
                            tablefmt="plain",
                            colalign=("left", "right", "right", "right", "right"),
                        )
                    ],
                ]

                tabs.append(
                    [
                        tabulate(
                            table,
                            ["Orbit %d.%d\n-----------" % (branch_index, orbit_index)],
                            tablefmt="plain",
                        )
                    ]
                )

        txt = tabulate(
            tabs,
            # tablefmt="mixed_outline",
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = "\n{s: ^{n}}\n".format(s="\033[1m TREE \033[0m", n=width) + txt + "\n"

        print(txt)
        return txt

    @classmethod
    def generate(cls, prim: Prim, max_body_order: int, condition: Callable):
        """
        Construct an orbit tree containing all :py:obj:`Orbit` objects in a hierarchical manner

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        max_body_order: int
            Maximum number of atoms allowed within one cluster
        condition: callable
            Function that should take a :py:obj:`Cluster` object as input and return a boolean value, depending on whether the cluster should be added or not

        Returns
        -------
        tree: OrbitTree
            OrbitTree object

        Examples
        --------
        The following example generates all :py:obj:`Orbit` of the orbit tree whose pair, triplet, and quadruplet clusters are no longer than 8 A, 6 A, and 4 A, respectively::

            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.cluster import OrbitTree, orbit_tree_length_filter

            >>> # Fe-Al alloy on BCC
            >>> structure = Structure([[-1.8, 1.8, 1.8], [1.8, -1.8, 1.8], [1.8, 1.8, -1.8]],
            ...                       ["Fe"],
            ...                       [[0, 0, 0]])
            >>> bcc = Prim(structure=structure,
            ...            allowed_elements=[['Fe','Al']])
            >>> bcc.get_neighborhood(cutoff=8)

            >>> # Generate orbit tree
            >>> tree = OrbitTree.generate(
            ...     bcc,
            ...     max_body_order=4,
            ...     condition=lambda x: orbit_tree_length_filter(
            ...         cluster=x,
            ...         orbit_specs={"0": {},
            ...                      "1": {},
            ...                      "2": {"max_length": 8},
            ...                      "3": {"max_length": 6},
            ...                      "4": {"max_length": 4}}
            ...     ),
            ... )
            >>> print(tree)
        """

        tree = cls(prim)

        # 0th cluster
        cluster = Cluster(np.array([]), prim)
        tree.add_cluster(cluster)

        # Loop over body orders
        for body_order in range(max_body_order):
            # loop over smaller orbits
            for orbit in tree.list_branches[body_order].list_orbits:
                cluster = Cluster(orbit.prototype, prim)
                # Loop over all atoms considered in the neighborhood
                for atom_index in range(len(prim.neighborhood)):
                    # Test if atom already in cluster
                    if atom_index in cluster:
                        continue

                    # New cluster
                    test_cluster = cluster.add_atom(atom_index, prim)

                    # Test condition
                    if not condition(test_cluster):
                        continue

                    # Test if cluster already in tree
                    if test_cluster in tree:
                        continue

                    # Add test cluster to tree
                    tree.add_cluster(test_cluster)
        tree.sort_tree()

        return tree


def center_cluster(cluster: NDArray[np.int_]) -> tuple:
    """
    Center the ``cluster`` to each atom belonging to the cluster

    The function returns a collection of clusters and associated tranlation vectors. The clusters in the collection correspond to all possible rigid translations of the original cluster such that at least one atom lies in the primitive unitcell.

    Parameters
    ----------
    cluster: np.ndarray[int]
        Integer numpy array with the unitcell coordinates of each atom in a cluster

    Returns
    -------
    tuple[np.ndarray[int], np.ndarray[int]]
        Tuple containing an integer numpy array with repeated clusters centered at each atom and an integer numpy array with the associated translation vectors
    """

    N = cluster.shape[-2]
    cluster_array = np.repeat(np.expand_dims(cluster, axis=-3), repeats=N, axis=-3)

    translation_matrix = np.eye(4, dtype=int)
    translation_matrix[-1, -1] = 0
    translations = np.repeat(
        np.expand_dims(cluster @ translation_matrix, axis=-2), repeats=N, axis=-2
    )

    cluster_array -= translations

    return (cluster_array, np.take(translations, [0, 1, 2], axis=-1))


def orbit_tree_length_filter(cluster: Cluster, orbit_specs: dict) -> bool:
    """
    Returns a boolean variable whether the ``cluster`` should be added to the tree, based on conditions on the lengths of the ``cluster``.

    Parameters
    ----------
    cluster: Cluster
        Cluster object of one representative of the orbit
    orbit_specs: dict
        Dictionary with orbit length specifications.
        The first layer of the dictionary is composed of the body-order, while the second level specifies the maximum (`max_length`) and minimum (`min_length`) lengths the cluster with that specified body-order are allowed.
        If minimum or maximum lengths are not spcified, the value 0 is set by default.

        Example
        -------
        Here is an example of specifications to include the empty, point, pair, and triplet clusters. The included pair clusters have cluster lengths smaller or equal to 10 Å, while triplet clusters cluster lengths comprised between 4 and 8 Å.
        .. code-block:: JSON

            {
                "0": {},
                "1": {},
                "2": {"max_length": 10},
                "3": {"min_length": 4, "max_length": 8}
            }

    Returns
    -------
    bool
        Returns True if the cluster satisfies the filtering criteria.
    """

    body_order = (
        str(len(cluster))
        if isinstance(list(orbit_specs.keys())[0], str)
        else len(cluster)
    )
    cluster_lengths = cluster.get_cluster_lengths()

    max_length = (
        orbit_specs[body_order]["max_length"]
        if "max_length" in orbit_specs[body_order]
        else 0
    )
    min_length = (
        orbit_specs[body_order]["min_length"]
        if "min_length" in orbit_specs[body_order]
        else 0
    )

    return (np.max(cluster_lengths) <= max_length) * (
        np.min(cluster_lengths) >= min_length
    )
