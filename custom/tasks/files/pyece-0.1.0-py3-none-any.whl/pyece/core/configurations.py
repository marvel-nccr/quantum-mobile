r"""
This module deals with the configurational structures, input for any on-lattice models.

Given a primitive unitcell :math:`L` that defines the underlying lattice, any configuration on this lattice can be mapped onto a supercell :math:`S` of this primitive cell as:

.. math:: S = L \cdot T

with :math:`T` being the transformation matrix made of integer entries. The absolute value of the determinant of the transformation matrix :math:`|det(T)|` defines number of time the primitive cell is repeated in the supercell. Once the supercell is determined, the configurtation consists in a particular arrangement of chemical species on the atomic sites of the supercell.
"""

from __future__ import annotations

from typing import Callable, Tuple

import numpy as np
import torch
from monty.json import MSONable
from numpy.typing import NDArray
from pymatgen.core import Structure
from tabulate import tabulate
from torch import Tensor, no_grad

from pyece.core.prim import Prim
from pyece.utils import mapping
from pyece.utils.coordinates import fractional_to_unitcell, unitcell_to_fractional
from pyece.utils.toolbox import within


def get_neighborhood_per_cell(
    structure: Structure, prim: Prim, supercell_transformation: NDArray[np.int_]
) -> NDArray[np.int_]:
    r"""
    Returns the neighbor site indexes for each primitive cell `prim` contained in the supercell `structure`.

    For each primitive cell in the input `structure`, a list of neighbor sites is determined. Each list is built as a mapping of the atomic sites in the :py:attr:`~.madeclex.core.prim.Prim.neighborhood` of the `prim` object to the sites in the `structure`.

    Parameters
    ----------
    structure: Structure
        Pymatgen atomic structure
    prim: Prim
        Prim object containing all references to the lattice
    supercell_transformation: np.ndarray[int]
        Integer numpy array of the supercell transformation from the `prim` to the `stucture`

        Warning
        -------
        The array must respect the row-wise convention.

    Returns
    -------
    indexes: np.ndarray[int]
        Integer numpy array with the atomic site indexes in the structure for each neighborhood contained in the structure

    Example
    -------
    This example displays the construction of the neighborhoods for the two primitive cells in a B2 configuration. The neighborhood consists of the center site itself and the 8 nearest neighbor sites::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.core.configurations import get_neighborhood_per_cell

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[["Al", "Fe"]])
        >>> # Neighborhood in unitcell coordinates
        >>> bcc.get_neighborhood(cutoff=3.5)
        >>> bcc.neighborhood
        np.array([[ 0,  0,  0,  0],
                  [-1,  0,  0,  0],
                  [ 0, -1,  0,  0],
                  [ 0,  0, -1,  0],
                  [ 0,  0,  1,  0],
                  [ 0,  1,  0,  0],
                  [ 1,  0,  0,  0],
                  [-1, -1, -1,  0],
                  [ 1,  1,  1,  0]])

        >>> # B2 configuration
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice
        >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])

        >>> # Indexes of the neighbor sites for the two primitive unitcells in the structure
        >>> get_neighborhood_per_cell(structure, bcc, transformation)
        np.array([[0, 1, 1, 1, 1, 1, 1, 1, 1],
                  [1, 0, 0, 0, 0, 0, 0, 0, 0]])

    This example displays the construction of the neighborhoods for the two primitive cells in a supercell of size 2 of an :math:`\omega` structure.
    The structure consists of two The neighborhood consists of two :math:`\omega` structures stacked on top of each other.
    The neighborhood consists of the center sites themselves and the 4 nearest neighbor sites::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.core.configurations import get_neighborhood_per_cell

        >>> # Omega primitive structure
        >>> omega_lattice = np.array([[4, 0, 0], [2, np.sqrt(3) * 2, 0], [0, 0, 3]])
        >>> omega_structure = Structure(
        ...     omega_lattice,
        ...     ["Ti"]*3,
        ...     [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [2 / 3, 2 / 3, 0.5]]
        ... )
        >>> omega = Prim(structure=omega_structure,
        ...            allowed_elements=[["Ti", "Zr"]] * 3)
        >>> # Neighborhood in unitcell coordinates
        >>> omega.get_neighborhood(cutoff=2.5)
        >>> omega.neighborhood
        np.array([[ 0,  0,  0,  0],
                  [ 0,  0,  0,  1],
                  [ 0,  0,  0,  2],
                  [-1,  0,  0,  2],
                  [ 0, -1,  0,  2],
                  [ 0,  1,  0,  1],
                  [ 1,  0,  0,  1]])

        >>> # Supercell configuration
        >>> transformation = np.diag([1, 1, 2])
        >>> lattice = transformation @ omega_lattice
        >>> structure = Structure(
        ...     lattice,
        ...     ["Ti", "Zr"] * 3,
        ...     [
        ...         [0, 0, 0],
        ...         [1 / 3, 1 / 3, 0.25],
        ...         [2 / 3, 2 / 3, 0.25],
        ...         [0, 0, 0.5],
        ...         [1 / 3, 1 / 3, 0.75],
        ...         [2 / 3, 2 / 3, 0.75],
        ...     ]
        ... )

        >>> # Indexes of the neighbor sites for the two primitive unitcells in the structure
        >>> get_neighborhood_per_cell(structure, omega, transformation)
        np.array([[0, 1, 2, 2, 2, 1, 1],
                  [3, 4, 5, 5, 5, 4, 4]])

    """

    # supercell factor
    factor = int(
        np.around(abs(np.linalg.det(supercell_transformation)), decimals=prim.accuracy)
    )

    # Structure site coordinates in the Prim reference
    fractional_coordinates = structure.frac_coords @ supercell_transformation
    unitcell_coordinates = fractional_to_unitcell(
        fractional_coordinates, prim.basis, prim.accuracy
    )

    # Determine unitcell translation vectors
    center = 0
    ind = np.nonzero(unitcell_coordinates[:, -1] == center)[0]
    if len(ind) != factor:
        raise RuntimeError(
            "Not able to detect the primcells contained in the structure. Try to increase accuracy in Prim object."
        )
    translations = unitcell_coordinates[ind]
    translations[:, -1] = 0

    # Determine neighborhoods in supercell fractional coordinates
    neighborhoods = translations[:, np.newaxis] + prim.neighborhood[np.newaxis]
    neighborhoods = unitcell_to_fractional(neighborhoods, prim.basis)
    neighborhoods @= np.linalg.inv(supercell_transformation)

    # Determine neighborhood per primcell (loop necessary to avoid memory overload !!!)
    indexes = -np.ones((factor, len(prim.neighborhood)), dtype=int)
    for neighborhood_index in range(factor):
        indexes[neighborhood_index] = fractional_to_unitcell(
            neighborhoods[neighborhood_index], structure.frac_coords, prim.accuracy
        )[:, -1]

    return indexes


class Config(MSONable):
    r"""
    Particular arrangement of atoms on a supercell.

    Parameters
    ----------
    occupation: np.ndarray[int]
        Integer numpy array with the chemical indexes of the atoms sitting at each site in the configurational structure
    neighborhood_per_primcell: np.ndarray[int]
        Integer numpy array with the neighbor site indexes for each primitive cell `prim` contained in the supercell `structure`.

        Tip
        ---
        This task can conveniently by performed by the :py:func:`get_neighborhood_per_cell`.
    fractional_coordinates: np.ndarray
        Numpy array with the fractional coordinates of the atomic sites in the structure.

        Warning
        -------
        The array must respect the row-wise convention.

    lattice: np.ndarray
        Numpy array with the lattice vectors.

        Warning
        -------
        The array must respect the row-wise convention.

    list_elements: np.ndarray[str]
        String numpy array with the list of allowed chemical species in the :py:obj:`~.pyece.core.prim.Prim` object.
    device: str, default: 'cpu'
        Device to be used for pytorch operations.

    Tip
    ---
    :py:obj:`Config` objects can conveniently be constructed using the function :py:meth:`~from_structure` from a pymatgen :obj:`Structure` or using the function :py:meth:`~from_dict` from a MSONable dictionary.

    Example
    -------
    This example displays the construction of :py:obj:`Config` object from a B2 configuration::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.core.configurations import Config, get_neighborhood_per_cell

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[["Al", "Fe"]])
        >>> # Neighborhood in unitcell coordinates
        >>> bcc.get_neighborhood(cutoff=3.5)

        >>> # B2 configuration
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice
        >>> occupation = [1, 0]
        >>> structure = Structure(
        ...     lattice,
        ...     bcc.elements[occupation],
        ...     [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]]
        ... )

        >>> # Construct the Config object
        >>> B2 = Config(
        ...     occupation,
        ...     get_neighborhood_per_cell(structure, bcc, transformation),
        ...     structure.frac_coords,
        ...     lattice,
        ...     bcc.elements,
        ... )
        >>> print(B2)

    This example displays the construction of :py:obj:`Config` object a supercell of size 2 of an :math:`\omega` structure.
    The structure consists of two The neighborhood consists of two :math:`\omega` structures stacked on top of each other::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.core.configurations import Config, get_neighborhood_per_cell

        >>> # Omega primitive structure
        >>> omega_lattice = np.array([[4, 0, 0], [2, np.sqrt(3) * 2, 0], [0, 0, 3]])
        >>> omega_structure = Structure(
        ...     omega_lattice,
        ...     ["Ti"]*3,
        ...     [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [2 / 3, 2 / 3, 0.5]]
        ... )
        >>> omega = Prim(structure=omega_structure,
        ...            allowed_elements=[["Ti", "Zr"]] * 3)
        >>> # Neighborhood in unitcell coordinates
        >>> omega.get_neighborhood(cutoff=2.5)

        >>> # Supercell configuration
        >>> transformation = np.diag([1, 1, 2])
        >>> lattice = transformation @ omega_lattice
        >>> occupation = [0, 1, 0, 1, 0, 1]
        >>> structure = Structure(
        ...     lattice,
        ...     omega.elements[occupation],
        ...     [
        ...         [0, 0, 0],
        ...         [1 / 3, 1 / 3, 0.25],
        ...         [2 / 3, 2 / 3, 0.25],
        ...         [0, 0, 0.5],
        ...         [1 / 3, 1 / 3, 0.75],
        ...         [2 / 3, 2 / 3, 0.75],
        ...     ]
        ... )

        >>> # Construct the Config object
        >>> scel = Config(
        ...     occupation,
        ...     get_neighborhood_per_cell(structure, omega, transformation),
        ...     structure.frac_coords,
        ...     lattice,
        ...     omega.elements,
        ... )
        >>> print(scel)

    Attributes
    ----------
    occupation: np.ndarray[int]
        Integer numpy array with the chemical indexes of the atoms sitting at each site in the configurational structure
    neighborhood_per_primcell: np.ndarray[int]
        Integer numpy array with the neighbor site indexes for each primitive cell `prim` contained in the supercell `structure`. For each primitive cell, the neighbor sites are sorted the same way as in :py:attr:`~.pyece.core.prim.Prim.neighborhood`.
    fractional_coordinates: np.ndarray
        Numpy array with the fractional coordinates of the atomic sites in the structure.
    lattice: np.ndarray
        Numpy array with the lattice vectors.
    list_elements: np.ndarray[str]
        String numpy array with the list of allowed chemical species in the :py:obj:`~.pyece.core.prim.Prim` object.
    N_variable_sites: int
        Number of sites with an occupancy degree of freedom greater than 1
    device: str, default: 'cpu'
        Device to be used for pytorch operations.
    """

    def __init__(
        self,
        occupation: NDArray[np.int_],
        neighborhood_per_primcell: NDArray[np.int_],
        fractional_coordinates: np.ndarray,
        lattice: np.ndarray,
        list_elements: NDArray[np.str_],
        device: str = "cpu",
    ) -> None:
        # Structure
        self.occupation: Tensor = torch.tensor(occupation, device=device).int()
        self.fractional_coordinates: np.ndarray = fractional_coordinates
        self.lattice: np.ndarray = lattice
        self.list_elements: NDArray[np.str_] = list_elements

        # Neighborhood
        self.neighborhood_per_primcell: Tensor = torch.tensor(
            neighborhood_per_primcell, device=device
        ).int()
        self.N_variable_sites: int = len(
            np.unique(self.neighborhood_per_primcell.numpy(force=True))
        )
        self.variable_sites: Tensor = self.get_sites_in_unitcells().flatten()

        self.device: str = device

        return

    def __len__(self) -> int:
        return len(self.neighborhood_per_primcell)

    def get_element_dict(self) -> dict:
        """
        Returns a dictionary that associates the name of the elements with their index

        Returns
        -------
        element_dict: dict
        """
        element_dict = {}
        for index, element in enumerate(self.list_elements):
            element_dict[element] = index
        return element_dict

    def get_sites_in_unitcells(self) -> Tensor:
        """
        Returns a tensor with the indexes of the sites in each unitcell in the configuration.

        Returns
        -------
        Tensor
        """
        N_sites_in_unitcells = int(
            self.N_variable_sites / len(self.neighborhood_per_primcell)
        )
        return self.neighborhood_per_primcell[:, :N_sites_in_unitcells]

    def get_neighborhood_occupations(self) -> Tensor:
        """
        Returns the occupations for each neighborhood in the configuration.

        Returns
        -------
        Tensor
            Pytorch tensor with the neighborhood occupations
        """
        return self.occupation[self.neighborhood_per_primcell]

    def compute_site_in_neighborhoods(self) -> list[Tuple[Tensor, ...]]:
        """
        Computes a list of tuples containing the positions of each site in all neighborhoods

        Returns
        -------
        list[Tuple[Tensor, ...]]
            List of tuples containing pytorch tensor with the sites included in each neighborhood
        """
        return [
            torch.nonzero(self.neighborhood_per_primcell == site_index, as_tuple=True)
            for site_index in range(len(self.occupation))
        ]

    def get_unitcell_index_per_sites(self) -> NDArray[np.int_]:
        """
        Computes the unitcell index to which belongs the site, for all sites in the configuration.

        Returns
        -------
        unitcell_indexes: np.ndarray[Any,int]
            Integer numpy array where the ith entry corresponds to the unitcell index to which belongs the the ith site.
        """
        sites_in_unitcells = self.get_sites_in_unitcells().numpy(force=True)
        unitcell_indexes = -np.ones(len(self.occupation), dtype=int)
        for site in range(len(self.occupation)):
            mask: NDArray[np.bool_] = sites_in_unitcells == site
            index = np.nonzero(mask)[0]
            if len(index) == 1:
                unitcell_indexes[site] = index[0]
        return unitcell_indexes

    def compute_primcells_in_neighborhoods(
        self, prim: Prim, per_primcells: bool = True
    ) -> Tensor:
        """
        Computes a tensor containing the indexes of the primcells included in each neighborhood

        Parameters
        ----------
        prim: Prim
            Prim object describing the lattice
        per_primcells: bool, default: True
            Set it to True to have the result per primcells or False for the result per atomic site.

        Returns
        -------
        primcells: Tensor
            Integer pytorch tensor with the indexes of the primcells included in the neighborhood of each unitcell.
        """
        prim_sites = self.neighborhood_per_primcell[
            :, np.nonzero(np.sum(np.abs(prim.neighborhood[:, :-1]), axis=-1) == 0)[0]
        ]
        indexes = np.sort(
            np.unique(prim.neighborhood[:, :-1], axis=0, return_index=True)[1]
        )
        basis = prim.neighborhood[indexes, -1]

        primcells = torch.cat(
            [
                torch.nonzero(
                    prim_sites[:, basis].T
                    == neighborhood[indexes]
                    .reshape(-1, 1)
                    .repeat([1, len(prim_sites)]),
                )[:, 1].reshape(1, -1)
                for neighborhood in self.neighborhood_per_primcell
            ]
        )
        if not per_primcells:
            arg = (
                (torch.argsort(prim_sites.flatten()) / prim_sites.shape[-1])
                .floor()
                .int()
            )
            primcells = primcells[arg]
        return primcells

    def get_wyckoff_indexes(self, prim: Prim) -> Tensor:
        """
        Returns the Wyckoff group index for each site

        Parameters
        ----------
        prim: Prim
            Prim object describing the lattice

        Returns
        -------
        wyckoff_vector: Tensor
            Integer pytorch tensor with the Wyckoff indexes for each site
        """
        prim_sites = np.nonzero(
            np.sum(np.abs(prim.neighborhood[:, :-1]), axis=-1) == 0
        )[0]
        wyckoff = prim.get_prim_wyckoff_indexes()[prim.neighborhood[:, -1][prim_sites]]
        wyckoff_vector = -np.ones(len(self.occupation), dtype=int)
        for neighborhood in self.neighborhood_per_primcell:
            wyckoff_vector[neighborhood.numpy(force=True)[prim_sites]] = wyckoff
        if np.sum(wyckoff_vector[self.variable_sites] == -1) != 0:
            raise ValueError("Some Wyckoff sites are incorrectly assigned")
        return torch.tensor(wyckoff_vector, device=self.device).int()

    def get_composition(self) -> Tensor:
        """
        Returns the number of sites assigned to a given species for all species.

        Returns
        -------
        Tensor
            Integer pytorch tensor with the number of sites assigned to each specie.
        """
        return torch.cat(
            [
                (self.occupation == i).sum().reshape(1)
                for i in range(len(self.list_elements))
            ],
            dim=0,
        )

    def swap(self, site_index: int, new_specie_index: int) -> None:
        """
        Swaps the specie at a given site with a new specie

        Parameters
        ----------
        site_index: int
            Index of the atomic site in the configuration
        new_specie_index: int
            Index of the new specie as found in list_elements
        """
        self.occupation[site_index] = new_specie_index
        return

    def get_structure(self, keep_vacancies: bool = False) -> Structure:
        """
        Create a `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ from the configuration

        Parameters
        ----------
        keep_vacancies: bool
            Set to True to write the vacancies as a dummy species with label X0+

        Returns
        -------
        structure: Structure
            `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_
        """
        if keep_vacancies:
            list_elements = np.array(self.list_elements.copy(), dtype="<U4")
            list_elements[list_elements == "Va"] = "X0+"

            structure = Structure(
                lattice=self.lattice,
                species=list_elements[self.occupation.tolist()].tolist(),
                coords=self.fractional_coordinates,
                coords_are_cartesian=False,
            )
        else:
            non_vacancy_indexes = np.nonzero(
                self.list_elements[self.occupation.tolist()] != "Va"
            )[0]

            structure = Structure(
                lattice=self.lattice,
                species=self.list_elements[self.occupation.tolist()][
                    non_vacancy_indexes
                ].tolist(),
                coords=self.fractional_coordinates[non_vacancy_indexes],
                coords_are_cartesian=False,
            )
        return structure

    def to(self, device: str = "cpu"):
        """
        Set the device for pytorch calculations (cpu or cuda)

        Parameters
        ----------
        device: str
            Device to be used for pytorch operations (default: \'cpu\')
        """
        self.occupation = self.occupation.to(device)
        self.neighborhood_per_primcell = self.neighborhood_per_primcell.to(device)
        self.device = device
        return self

    def as_dict(self) -> dict:
        """
        MSONable dictionary of the Config class.
        """

        structure = {
            "lattice": self.lattice.tolist(),
            "occupation": self.occupation.tolist(),
            "fractional_coordinates": self.fractional_coordinates.tolist(),
        }

        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "structure": structure,
            "neighborhood_per_primcell": self.neighborhood_per_primcell.tolist(),
            "list_elements": self.list_elements.tolist(),
        }

        return dct

    @classmethod
    def from_dict(cls, dct: dict, device: str = "cpu"):
        """
        Create the Config class from a MSONable dictionary.

        Parameters
        ----------
        device: str
            Device to be used for pytorch operations (default: \'cpu\')
        """

        occupation = np.array(dct["structure"]["occupation"], dtype=int)
        neighborhood_per_primcell = np.array(
            dct["neighborhood_per_primcell"], dtype=int
        )
        fractional_coordinates = np.array(dct["structure"]["fractional_coordinates"])
        lattice = np.array(dct["structure"]["lattice"])
        list_elements = np.array(dct["list_elements"], dtype=str)

        return cls(
            occupation,
            neighborhood_per_primcell,
            fractional_coordinates,
            lattice,
            list_elements,
            device,
        )

    @classmethod
    def from_structure(
        cls,
        structure: Structure,
        prim: Prim,
        list_try_maps: list[Callable] = [mapping.quick_map],
        list_checks: list[Callable] = [mapping.check_mapping],
        vacancy_species: bool = False,
        device: str = "cpu",
        return_map: bool = False,
    ):
        r"""
        Construct a :py:obj:`Config` object from a pymatgen atomic Structure.

        Parameters
        ----------
        structure: Structure
            Pymatgen atomic structure
        prim: Prim
            Prim object containing all references to the lattice
        list_try_maps: list[callable], default: [mapping.quick_map]
            List of callable mapping functions sorted as trial order.
        list_checks: list[callable], default: [mapping.check_mapping]
            List of callable check functions that ensures the mapping respects some criteria.
        vacancy_species: bool, default: False,
            Set to True if vacancies are present and represented by dummy species X0+
        device: str, default: 'cpu'
            Device to be used for pytorch operations (default: \'cpu\')
        return_map: bool, default: False
            Set it to True to return the deformation matrix and displacement field to map the structure.

        Returns
        -------
        config: Config
            Config object
        tuple
            Tuple with numpy arrays containing the deformation matrix and the displacement field, if `return_map` is set to True.

        Example
        -------
        This example displays the construction of :py:obj:`Config` object from a B2 configuration::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.configurations import Config

            >>> # BCC primitive structure
            >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
            >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
            >>> bcc = Prim(structure=bcc_structure,
            ...            allowed_elements=[["Al", "Fe"]])
            >>> # Neighborhood in unitcell coordinates
            >>> bcc.get_neighborhood(cutoff=3.5)

            >>> # B2 configuration
            >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
            >>> lattice = transformation @ bcc_lattice
            >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])

            >>> # Construct the Config object
            >>> B2 = Config.from_structure(structure, bcc)
            >>> print(B2)

        This example displays the construction of :py:obj:`Config` object a supercell of size 2 of an :math:`\omega` structure.
        The structure consists of two The neighborhood consists of two :math:`\omega` structures stacked on top of each other::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.configurations import Config

            >>> # Omega primitive structure
            >>> omega_lattice = np.array([[4, 0, 0], [2, np.sqrt(3) * 2, 0], [0, 0, 3]])
            >>> omega_structure = Structure(
            ...     omega_lattice,
            ...     ["Ti"]*3,
            ...     [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [2 / 3, 2 / 3, 0.5]]
            ... )
            >>> omega = Prim(structure=omega_structure,
            ...            allowed_elements=[["Ti", "Zr"]] * 3)
            >>> # Neighborhood in unitcell coordinates
            >>> omega.get_neighborhood(cutoff=2.5)

            >>> # Supercell configuration
            >>> transformation = np.diag([1, 1, 2])
            >>> lattice = transformation @ omega_lattice
            >>> structure = Structure(
            ...     lattice,
            ...     ["Ti", "Zr"] * 3,
            ...     [
            ...         [0, 0, 0],
            ...         [1 / 3, 1 / 3, 0.25],
            ...         [2 / 3, 2 / 3, 0.25],
            ...         [0, 0, 0.5],
            ...         [1 / 3, 1 / 3, 0.75],
            ...         [2 / 3, 2 / 3, 0.75],
            ...     ]
            ... )

            >>> # Construct the Config object
            >>> scel = Config.from_structure(structure, omega)
            >>> print(scel)
        """
        if vacancy_species:
            prim_dict = prim.as_dict()
            for i, elems in enumerate(prim_dict["occupancy"]["elements_per_site"]):
                prim_dict["occupancy"]["elements_per_site"][i] = [
                    "X0+" if e == "Va" else e for e in elems
                ]
            prim_map = Prim.from_dict(prim_dict)
        else:
            prim_map = Prim.from_dict(prim.as_dict())

        errors = []
        for map_fn, check_fn in zip(list_try_maps, list_checks):
            try:
                (
                    mapped_structure,
                    supercell_transformation,
                    deformation,
                    displacements,
                ) = map_fn(structure, prim_map)
                check_fn(structure, mapped_structure, deformation, displacements)
                break
            except (ValueError, RuntimeError) as except_err:
                errors.append(except_err)
                continue
        if len(errors) >= len(list_try_maps):
            err_txt = ""
            for map_fn, err in zip(list_try_maps, errors):
                err_txt += "   %s: %s\n" % (map_fn.__qualname__, err)
            raise RuntimeError(
                "Not able to map structure... \nList of errors:\n%s" % err_txt
            )

        # Wrap structure
        for site_index, site in enumerate(mapped_structure.copy()):
            if vacancy_species:
                label = "Va" if (site.label == "X0+") else site.label
            else:
                label = site.label
            mapped_structure.replace(
                site_index,
                site.specie,
                label=label,
                coords=within(site.frac_coords, 12),
                coords_are_cartesian=False,
            )

        # occupation
        occupation = np.array(
            [
                np.nonzero(prim.elements == elem)[0][0]
                for elem in mapped_structure.labels
                if elem in prim.elements
            ],
            dtype=int,
        )
        if len(occupation) != len(mapped_structure):
            raise ValueError("Some elements are not found in the Prim object")

        # Neighborhood_per_primcell
        neighborhood_per_primcell = get_neighborhood_per_cell(
            mapped_structure, prim, supercell_transformation
        )

        config = cls(
            occupation,
            neighborhood_per_primcell,
            mapped_structure.frac_coords,
            mapped_structure.lattice.matrix,
            prim.elements,
            device,
        )

        if return_map:
            return config, (deformation, displacements)
        return config

    def _get_string(self) -> str:
        """
        String representation of the :py:obj:`Config` object that provides an overview of
        the lattice and chemical species at each site of the configuration.

        Returns
        -------
        txt: string
            Multi-line string representation of the :py:obj:`Config` object.
        """

        tabs = []

        # Tabulate General
        table = [
            [
                "Composition",
                ":",
                tabulate(
                    [
                        self.list_elements.tolist(),
                        self.get_composition().numpy(force=True).tolist(),
                    ],
                    tablefmt="plain",
                    colalign=["right"] * len(self.list_elements),
                ),
            ],
            ["Number of unitcells", ":", "%d neighborhoods" % len(self)],
            [
                "Neighborhood size",
                ":",
                "%d atoms" % len(self.neighborhood_per_primcell[0]),
            ],
        ]
        tabs.append([tabulate(table, ["General:\n--------", "", ""], tablefmt="plain")])

        # Tabulate Lattice
        table = [
            [
                "a\nb\nc",
                tabulate(
                    [[value for value in vector] for vector in self.lattice],
                    tablefmt="plain",
                    # floatfmt=".6f",
                ),
            ],
        ]
        tabs.append([tabulate(table, ["Lattice:\n--------", ""], tablefmt="plain")])

        # Tabulate Basis
        indexes: list[list[str]] = [[], []]
        sites_in_unitcells = self.get_sites_in_unitcells().numpy(force=True)
        for site_index in range(len(self.occupation)):
            ind = np.nonzero(sites_in_unitcells == site_index)
            if len(ind[0]) == 0:
                indexes[0].append(".")
                indexes[1].append(".")
            else:
                indexes[0].append(str(ind[0][0]))
                indexes[1].append(str(ind[1][0]))
        table = [
            [
                "\n".join([str(i) for i in range(len(self.occupation))]),
                tabulate(
                    [
                        [value for value in vector]
                        for vector in self.fractional_coordinates
                    ],
                    tablefmt="plain",
                    # floatfmt=".6f",
                ),
                "\n".join([str(i) for i in indexes[0]]),
                "\n".join([str(i) for i in indexes[1]]),
                "\n".join([self.list_elements[i] for i in self.occupation]),
            ],
        ]
        tabs.append(
            [
                tabulate(
                    [
                        [
                            tabulate(
                                table,
                                [
                                    "Index",
                                    "Coordinates",
                                    "Unitcell",
                                    "Basis index",
                                    "Chemical species",
                                ],
                                tablefmt="simple",
                                colalign=("left", "left", "center", "center", "center"),
                            )
                        ]
                    ],
                    ["Basis:\n------"],
                    tablefmt="plain",
                )
            ]
        )

        txt = tabulate(
            tabs,
            # tablefmt="mixed_outline",
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = (
            "\n{s: ^{n}}\n".format(
                s="\033[1m CONFIGURATION %s \033[0m"
                % self.get_structure().reduced_formula,
                n=width,
            )
            + txt
            + "\n"
        )

        return txt

    def __str__(self) -> str:
        """String representation."""
        return "\n" + self._get_string() + "\n"


class ClexInput:
    """
    Input features for the embedded cluster expansion (eCE).

    Parameters
    ----------
    neighborhood_occupations: Tensor
        Integer pytorch tensors with the chemical indexes in each neighborhoods that one wished to evaluate.
        The tensor must be a NxM tensor where N is the number of unitcell neighborhoods and M is the number of sites in the neighborhood.

        Warning
        -------
        The number of sites (M) per neighborhood must match the size of the :py:attr:`~.pyece.core.prim.Prim.neighborhood` attribute of the :py:obj:`~.pyece.core.prim.Prim` object used to construct the :py:obj:`~.pyece.core.clex.eCE` model.

    segment_indexes: Tensor | None, default: None
        Variable used to keep neighborhoods belonging to the same structure together

        -   If the neighborhoods are required to be held by groups of neighborhoods belonging to the same configuration, use a pytorch tensor with the indexes
            of the configuration to which each one of the N neighborhoods belong to, in compressed
            format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_)
        -   If neighborhoods can be treated individually, set the variable to None
    device: str, default: 'cpu'
        Device to be used for pytorch operations.

    Tip
    ---
    :py:obj:`ClexInput` objects can conveniently be constructed using the function :py:meth:`~from_structure` from a single :py:obj:`Config` object or using the function :py:meth:`~from_list_structures` from a list of :py:obj:`Config` objects.

    Attributes
    ----------
    neighborhood_occupations: Tensor
        Integer pytorch tensors with the chemical indexes in each neighborhoods that one wished to evaluate.
        The tensor must be a NxM tensor where N is the number of unitcell neighborhoods and M is the number of sites in the neighborhood.
    segment_indexes: Tensor | None
        Variable used to keep neighborhoods belonging to the same structure together
            -   A pytorch tensor with the indexes of the configuration to which each one of the N neighborhoods belong to, in compressed
                format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_), is used
                if the neighborhoods are required to be held by groups of neighborhoods belonging to the same configuration
            -   None is used if the neighborhoods can be treated individually.
    device: str
        Device to be used for pytorch operations.

    Note
    ----
    Consider a dataset composed of two configurations, one being a supercell of size 2 and another one a supercell of size 3, this dataset is composed of 2+3=5 neighborhoods with M sites in each.
    :py:attr:`~ClexInput.neighborhood_occupations` has a shape 5xM. In this case, one needs to keep the neighborhoods belonging to the same configuration together in order to evaluate the two configurations.
    This task of keeping track of wish neighborhoods belong together is performed by :py:attr:`~ClexInput.segment_indexes`.

    Tip
    ---
    Generally, when training the model, the :py:obj:`ClexInput` object contains several configurations in a dataset. In this case, one wishes to keep the neighborhoods belonging to the same configuration together and :py:attr:`~ClexInput.segment_indexes` is a pytorch tensor.
    When producing data, such as when performing a MCMC simulation, the :py:obj:`ClexInput` object only contains one configuration and :py:attr:`~ClexInput.segment_indexes` can be None. In this case, the eCE model will evaluate each neighborhood separately.

    Example
    -------
    This example illustrate the construction of a :py:obj:`ClexInput` corresponding to a dataset composed of one A2-Fe, one B2-FeAl, and one A2-Al configurations. The model considers only the nearest neighbor sites::

        >>> import numpy as np
        >>> from torch import tensor
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.core.configurations import Config, ClexInput

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[["Al", "Fe"]])
        >>> # Neighborhood in unitcell coordinates
        >>> bcc.get_neighborhood(cutoff=3.5)

        >>> # A2-Fe configuration
        >>> structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> A2_Fe = Config.from_structure(structure, bcc)
        >>> A2_Fe.neighborhood_per_primcell
        tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
        >>> A2_Fe.get_neighborhood_occupations()
        tensor([[1, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)

        >>> # B2-FeAl configuration
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice
        >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
        >>> B2_FeAl = Config.from_structure(structure, bcc)
        >>> B2_FeAl.neighborhood_per_primcell
        tensor([[0, 1, 1, 1, 1, 1, 1, 1, 1],
                [1, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
        >>> B2_FeAl.get_neighborhood_occupations()
        tensor([[1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)

        >>> # A2-Al configuration
        >>> structure = Structure(bcc_lattice, ["Al"], [[0, 0, 0]])
        >>> A2_Al = Config.from_structure(structure, bcc)
        >>> A2_Al.neighborhood_per_primcell
        tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
        >>> A2_Al.get_neighborhood_occupations()
        tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)

        >>> # Construct the ClexInput object
        >>> neighborhood_occupations = np.vstack([A2_Fe.neighborhood_per_primcell,
        ...                                       B2_FeAl.neighborhood_per_primcell,
        ...                                       A2_Al.neighborhood_per_primcell])
        >>> segment_indexes = tensor([0,1,3,4])
        >>> inp = ClexInput(tensor(neighborhood_occupations), segment_indexes)
        >>> inp.neighborhood_occupations
        tensor([[1, 1, 1, 1, 1, 1, 1, 1, 1],
                [1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 1],
                [0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)

    """

    @no_grad()
    def __init__(
        self,
        neighborhood_occupations: Tensor,
        segment_indexes: Tensor | None = None,
        device: str = "cpu",
    ):
        self.neighborhood_occupations: Tensor = neighborhood_occupations
        self.segment_indexes: Tensor | None = segment_indexes
        self.to(device)
        self.device: str = device
        return

    def __getitem__(self, index):
        neighborhood_occupations, segment_indexes = self.get_selection(index)
        return ClexInput(neighborhood_occupations, segment_indexes, self.device)

    def __add__(self, clex_input):
        # Get inputs for each object
        neighborhood_occupations_1, segment_indexes_1 = self.get_selection(
            torch.arange(len(self))
        )
        if segment_indexes_1 is None:
            segment_indexes_1 = torch.tensor(
                [0, len(neighborhood_occupations_1)], device=self.device
            ).int()
        neighborhood_occupations_2, segment_indexes_2 = clex_input.get_selection(
            torch.arange(len(clex_input))
        )
        if segment_indexes_2 is None:
            segment_indexes_2 = torch.tensor(
                [0, len(neighborhood_occupations_2)], device=self.device
            ).int()
        segment_indexes_2 = (
            segment_indexes_2[1:].to(self.device) + segment_indexes_1[-1]
        )

        # Compute new input corresponding to the addition of the objects
        neighborhood_occupations = torch.cat(
            (
                neighborhood_occupations_1,
                neighborhood_occupations_2.to(self.device),
            ),
            dim=0,
        )
        segment_indexes = torch.cat((segment_indexes_1, segment_indexes_2), dim=0)

        return ClexInput(neighborhood_occupations, segment_indexes, self.device)

    def __len__(self):
        return len(self.segment_indexes) - 1 if self.segment_indexes is not None else 1

    def to(self, device: str = "cpu"):
        """
        Set the device for pytorch calculations (cpu or cuda)

        Parameters
        ----------
        device: str
            Device to be used for pytorch operations (default: \'cpu\')
        """
        self.neighborhood_occupations = self.neighborhood_occupations.to(device)
        if self.segment_indexes is not None:
            self.segment_indexes = self.segment_indexes.to(device)
        self.device = device
        return self

    def get_selection(self, selection_indexes):
        """
        Returns the inputs necessary to initiate the object given a selection_indexes input

        Returns
        -------
        tuple
            Pytorch tensors of the features and scatter matrix
        """

        if self.segment_indexes is None:
            if len(self.neighborhood_occupations[selection_indexes, 0].shape) == 0:
                selection_indexes = [selection_indexes]
            return self.neighborhood_occupations[selection_indexes], None

        start_indexes = self.segment_indexes[:-1][selection_indexes]
        end_indexes = self.segment_indexes[1:][selection_indexes]
        if len(start_indexes.shape) == 0:
            start_indexes = start_indexes.reshape(1)
            end_indexes = end_indexes.reshape(1)

        index = 0
        select = []
        segment_indexes = [index]
        for start, end in zip(start_indexes, end_indexes):
            index += int(end - start)
            select += list(range(start, end))
            segment_indexes.append(index)

        return (
            self.neighborhood_occupations[
                select
            ],  # self.features[site_index].clone()[select]
            torch.tensor(segment_indexes),
        )

    @classmethod
    def from_list_configs(
        cls,
        list_configs: list[Config],
        device: str = "cpu",
    ):
        """
        Construct a :py:obj:`ClexInput` object from a list of :py:obj:`Config`.

        Parameters
        ----------
        list_configs: list[Config]
            List of Config objects used as input for the eCE model
        sitebasis: SiteBasis
            SiteBasis object
        device: str, default: \'cpu\'
            Device to be used for pytorch operations.

        Returns
        -------
        clexinput: ClexInput
            ClexInput object

        Example
        -------
        This example illustrate the construction of a :py:obj:`ClexInput` corresponding to a dataset composed of one A2-Fe, one B2-FeAl, and one A2-Al configurations. The model considers only the nearest neighbor sites::

            >>> import numpy as np
            >>> from torch import tensor
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.configurations import Config, ClexInput

            >>> # BCC primitive structure
            >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
            >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
            >>> bcc = Prim(structure=bcc_structure,
            ...            allowed_elements=[["Al", "Fe"]])
            >>> # Neighborhood in unitcell coordinates
            >>> bcc.get_neighborhood(cutoff=3.5)

            >>> # A2-Fe configuration
            >>> structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
            >>> A2_Fe = Config.from_structure(structure, bcc)
            >>> A2_Fe.neighborhood_per_primcell
            tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
            >>> A2_Fe.get_neighborhood_occupations()
            tensor([[1, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)

            >>> # B2-FeAl configuration
            >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
            >>> lattice = transformation @ bcc_lattice
            >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
            >>> B2_FeAl = Config.from_structure(structure, bcc)
            >>> B2_FeAl.neighborhood_per_primcell
            tensor([[0, 1, 1, 1, 1, 1, 1, 1, 1],
                    [1, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
            >>> B2_FeAl.get_neighborhood_occupations()
            tensor([[1, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)

            >>> # A2-Al configuration
            >>> structure = Structure(bcc_lattice, ["Al"], [[0, 0, 0]])
            >>> A2_Al = Config.from_structure(structure, bcc)
            >>> A2_Al.neighborhood_per_primcell
            tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
            >>> A2_Al.get_neighborhood_occupations()
            tensor([[0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)

            >>> # Construct the ClexInput object
            >>> inp = ClexInput.from_list_configs([A2_Fe, B2_FeAl, A2_Al])
            >>> inp.neighborhood_occupations
            tensor([[1, 1, 1, 1, 1, 1, 1, 1, 1],
                    [1, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 1, 1, 1, 1, 1, 1, 1, 1],
                    [0, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
            >>> inp.segment_indexes
            tensor([0, 1, 3, 4], dtype=torch.int32)
        """

        neighborhood_occupations = torch.cat(
            [config.get_neighborhood_occupations() for config in list_configs],
        )
        segment_indexes = torch.tensor(
            np.cumsum([0] + [len(config) for config in list_configs]),
            device=device,
        ).int()

        return cls(neighborhood_occupations, segment_indexes, device)

    @classmethod
    def from_config(
        cls,
        config: Config,
        device: str = "cpu",
    ):
        """
        Construct a :py:obj:`ClexInput` object from a single :py:obj:`Config`.

        Parameters
        ----------
        config: Config
            Config object used as input for the eCE model
        device: str, default: \'cpu\'
            Device to be used for pytorch operations.

        Returns
        -------
        clexinput: ClexInput
            ClexInput object

        Note
        ----
        Because there is only one configuration, the :py:attr:`~ClexInput.segment_indexes` is set to None by default. The eCE model will evaluate each neighborhood separately.

        Example
        -------
        This example illustrate the construction of a :py:obj:`ClexInput` corresponding to a dataset composed of one A2-Fe, one B2-FeAl, and one A2-Al configurations. The model considers only the nearest neighbor sites::

            >>> import numpy as np
            >>> from torch import tensor
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.configurations import Config, ClexInput

            >>> # BCC primitive structure
            >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
            >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
            >>> bcc = Prim(structure=bcc_structure,
            ...            allowed_elements=[["Al", "Fe"]])
            >>> # Neighborhood in unitcell coordinates
            >>> bcc.get_neighborhood(cutoff=3.5)

            >>> # B2-FeAl configuration
            >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
            >>> lattice = transformation @ bcc_lattice
            >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
            >>> B2_FeAl = Config.from_structure(structure, bcc)
            >>> B2_FeAl.neighborhood_per_primcell
            tensor([[0, 1, 1, 1, 1, 1, 1, 1, 1],
                    [1, 0, 0, 0, 0, 0, 0, 0, 0]], dtype=torch.int32)
            >>> B2_FeAl.get_neighborhood_occupations()
            tensor([[1, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)

            >>> # Construct the ClexInput object
            >>> inp = ClexInput.from_config(B2_FeAl)
            >>> inp.neighborhood_occupations
            tensor([[1, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 1, 1, 1, 1, 1, 1, 1, 1]], dtype=torch.int32)
            >>> inp.segment_indexes
            None
        """

        return cls(config.get_neighborhood_occupations(), None, device)
