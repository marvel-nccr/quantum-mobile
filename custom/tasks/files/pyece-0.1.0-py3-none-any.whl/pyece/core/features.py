import numpy as np
import torch
from monty.json import MSONable
from numpy.typing import NDArray
from tabulate import tabulate
from torch import Tensor, nn

from pyece.core.cluster import OrbitTree
from pyece.core.sitebasis import SiteBasis
from pyece.utils.toolbox import segment

# from torch_geometric.utils import segment

# from torch_scatter import segment_csr


class Features(nn.Module, MSONable):
    r"""
    Collection of descriptor functions used to differentiate particular arrangements on a lattice.

    The descriptor :math:`\tilde{\Theta}_\alpha` corresponds to a cluster function in the cluster expansion formalism. It is computed as symmetrized tensor products of embedded site-basis functions evaluated at different sites on the lattice (See :doc:`description` for more details):

    .. math::

        \tilde{\Theta}_\alpha = \sum_{g \in G \cdot C} \prod_{(i_g,k) \in \alpha} \tilde{\varphi}_k(\sigma_{i_g})

    where :math:`G` is the spacegroup, :math:`i_g` the lattice site after applying the `g`'th symmetry operation to the cluster :math:`C`, and :math:`\tilde{\varphi}_k` the `k`'th embedded site-basis function.

    Parameters
    ----------
    selection_matrix: Tensor
        Integer pytorch tensor that selects the atomic sites for each cluster.
        The first index corresponds to the site index within the neighborhood, while the second index corresponds to the sitebasis function index.
    symmetrization_segment_indexes: Tensor
        Integer pytorch tensor with the indexes of cluster functions to produces symmetry-invariant cluster functions, in compressed format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_)
    symmetrization_factors: Tensor
        Pytorch tensor with factors to multiply symmetry-invariant cluster functions with
    orbit_tracker: dict
        Dictionary with the idexes of the features corresponding to each orbit.
    orbit_lengths: dict, default: {}
        Dictionary with the lengths of the clusters in each orbit.

    Tip
    ---
    :py:obj:`Features` objects can conveniently be constructed using the function :py:meth:`~build_features` from a :py:obj:`~.pyece.core.cluster.OrbitTree` object and a :py:obj:`~.pyece.core.sitebasis.SiteBasis` object or using the function :py:meth:`~from_dict` from a MSONable dictionary.

    Attributes
    ----------
    selection_matrix: Tensor
        Integer pytorch tensor that selects the atomic sites for each cluster.
        The first index corresponds to the site index within the neighborhood, while the second index corresponds to the sitebasis function index.
    symmetrization_segment_indexes: Tensor
        Integer pytorch tensor with the indexes of cluster functions to produces symmetry-invariant cluster functions, in compressed format (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_)
    symmetrization_factors: Tensor
        Pytorch tensor with factors to multiply symmetry-invariant cluster functions with
    """

    def __init__(
        self,
        selection_matrix: Tensor,
        symmetrization_segment_indexes: Tensor,
        symmetrization_factors: Tensor,
        orbit_tracker: dict,
        orbit_lengths: dict = {},
    ) -> None:
        super().__init__()

        self.N_features: int = len(symmetrization_segment_indexes) - 1
        self.selection_matrix: Tensor
        self.register_buffer("selection_matrix", selection_matrix)
        self.symmetrization_segment_indexes: Tensor
        self.register_buffer(
            "symmetrization_segment_indexes",
            symmetrization_segment_indexes.int(),
        )
        self.symmetrization_factors: Tensor
        self.register_buffer("symmetrization_factors", symmetrization_factors.float())

        # Feature characterization
        self.orbits: list[str] = list(orbit_tracker.keys())
        for orbit in orbit_tracker.keys():
            self.register_buffer(orbit, torch.tensor(orbit_tracker[orbit]).int())
        if len(orbit_lengths) == len(orbit_tracker):
            for orbit in orbit_tracker.keys():
                self.register_buffer(
                    "Lengths_" + orbit, torch.tensor(orbit_lengths[orbit]).float()
                )

        return

    def forward(
        self, sitebasis_functions: Tensor, neighborhood_occupations: Tensor
    ) -> Tensor:
        """
        Pytorch forward function that evaluates symmetrized cluster functions (features)

        Parameters
        ----------
        sitebasis_functions: Tensor
            Pytorch tensor with the global embedded site-basis functions as obtained by :py:meth:`~.pyece.core.sitebasis.SiteBasis.forward` or stored in :py:attr:`~.pyece.core.sitebasis.SiteBasis.sitebasis_functions`.
        neighborhood_occupations: Tensor
            Integer pytorch tensor with the chemical index for all neighboring sites as found in :py:attr:`~.pyece.core.prim.Prim.neighborhood` for all sites in structures.

        Returns
        -------
        features: Tensor
            Pytorch tensor with evaluated (symmetrized) cluster functions (features)
        """
        cluster_functions = torch.prod(
            sitebasis_functions[
                self.selection_matrix[:, 1],
                neighborhood_occupations[:, self.selection_matrix[:, 0]],
            ],
            dim=-1,
        )
        features = (
            segment(cluster_functions, self.symmetrization_segment_indexes)
            * self.symmetrization_factors
        )
        return features

    def orbit_tracker(self):
        """
        Returns
        -------
        orbit_tracker: dict
            Dictionary containing the lists of cluster functions belonging to the same orbit for each orbit in the orbit tree (as computed by :py:meth:`pyece.core.cluster.OrbitTree.generate`).
        """
        orbit_tracker = {}
        for orbit in self.orbits:
            orbit_tracker[orbit] = self.__getattr__(orbit).tolist()
        return orbit_tracker

    def orbit_lengths(self):
        """
        Returns
        -------
        orbit_lengths: dict
            Dictionary containing the lists of cluster lengths for each orbit in the orbit tree (as computed by :py:meth:`pyece.core.cluster.OrbitTree.generate`).
        """
        orbit_lengths = {}
        for orbit in self.orbits:
            if hasattr(self, "Lengths_" + orbit):
                orbit_lengths[orbit] = self.__getattr__("Lengths_" + orbit).tolist()
            else:
                orbit_lengths[orbit] = [None]
        return orbit_lengths

    def as_dict(self) -> dict:
        """
        MSONable dictionary of the :py:obj:`Features` class.

        Returns
        -------
        dct: dict
            MSONable dictionary
        """

        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "selection_matrix": self.selection_matrix.tolist(),
            "symmetrization": {
                "segment_indexes": self.symmetrization_segment_indexes.tolist(),
                "factors": self.symmetrization_factors.tolist(),
            },
            "orbit_tracker": self.orbit_tracker(),
            "orbit_lengths": self.orbit_lengths(),
        }

        return dct

    @classmethod
    def from_dict(cls, dct: dict):
        """
        Create the :py:obj:`Features` class from a MSONable dictionary.

        Parameters
        ----------
        dct: dict
            MSONable dictionary of the :py:obj:`Features`.
        """

        selection_matrix = torch.tensor(dct["selection_matrix"]).int()
        symmetrization_segment_indexes = torch.tensor(
            dct["symmetrization"]["segment_indexes"]
        ).int()
        symmetrization_factors = torch.tensor(dct["symmetrization"]["factors"]).float()
        orbit_tracker = dct["orbit_tracker"]
        orbit_lengths = dct["orbit_lengths"]

        return cls(
            selection_matrix,
            symmetrization_segment_indexes,
            symmetrization_factors,
            orbit_tracker,
            orbit_lengths,
        )

    @classmethod
    def build_features(
        cls,
        tree: OrbitTree,
        sitebasis: SiteBasis,
        site_centric: bool = True,
        normalization: bool = True,
    ):
        """
        Construct the :py:obj:`Features` module that evaluates the descriptor functions of particular arrangements on a lattice.

        Parameters
        ----------
        tree: OrbitTree
            OrbitTree object with all symmetrically distinct orbits of clusters
        sitebasis: SiteBasis
            SiteBasis functions module with all site-basis functions
        site_centric: bool, default: True
            Set to True for site-centric cluster functions
        normalization: bool, default: True
            Set to True for normalized correlation functions per size of the orbit and number of permutations

        Returns
        -------
        Functions
            Features pytorch modules

        Examples
        --------
        The following example illustrate the construction of a :py:obj:`Features` object from Cr-Mo-Nb-Ta-V-W BCC alloy with 3 embedding dimensions with pair, triplet, and quadruplet clusters whose lengths are no longer than 8 A, 6 A, and 4 A, respectively::

            >>> import torch
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.cluster import OrbitTree, orbit_tree_length_filter
            >>> from pyece.core.sitebasis import SiteBasis
            >>> from pyece.core.features import Features

            >>> # Cr-Mo-Nb-Ta-V-W high entropy alloy on BCC
            >>> structure = Structure([[-1, 1, 1], [1, -1, 1], [1, 1, -1]],
            ...                       ["Nb"],
            ...                       [[0, 0, 0]])
            >>> bcc = Prim(structure=structure,
            ...            allowed_elements=[['Cr','Mo', 'Nb', 'Ta', 'V', 'W']])
            >>> bcc.get_neighborhood(cutoff=8)
            >>> print(bcc)

            >>> # Generate orbit tree
            >>> tree = OrbitTree.generate(
            ...     bcc,
            ...     max_body_order=4,
            ...     condition=lambda x: orbit_tree_length_filter(
            ...         cluster=x, max_lengths={"0": 0, "1": 0, "2": 8, "3": 6, "4": 4}
            ...     ),
            ... )
            >>> print(tree)

            >>> # Construct site-basis functions
            >>> basis = SiteBasis.build_sitebasis(
            ...     prim=bcc,
            ...     embedding_dimensions=np.array([3]),
            ... )
            >>> print(basis)

            >>> # Construct descriptor functions
            >>> features = Features.build_features(
            ...     tree=tree,
            ...     sitebasis=basis,
            ... )
            >>> print(features)
        """

        def fill_selection_matrix(
            orbit: NDArray[np.int_],
            cluster_fct: NDArray[np.int_],
            max_order: int,
        ) -> NDArray[np.int_]:
            body_order = orbit.shape[-1]
            fcts = np.zeros((len(orbit), len(cluster_fct), max_order, 2), dtype=int)
            fcts[:, :, :body_order, 0] = np.tile(
                orbit[:, np.newaxis], reps=(1, len(cluster_fct), 1)
            )
            fcts[:, :, :body_order, 1] = np.tile(
                cluster_fct[np.newaxis], reps=(len(orbit), 1, 1)
            )
            return np.transpose(fcts.reshape(-1, max_order, 2), (0, 2, 1))

        def fill_symmetrized_matrix(
            matrix: list, N_clusters: int, degeneracy: int
        ) -> list:
            M = N_clusters * degeneracy
            col_index = len(matrix[1])
            matrix[0].append(symmetrized_matrix[0][-1] + M)
            matrix[1] += list(range(col_index, col_index + M))
            matrix[2] += [np.sqrt(1 / degeneracy) * 1 / N_clusters] * M
            return matrix

        N = np.max(tree.list_bodyorders)
        basis_assignment = sitebasis.neighbor_basis_index.cpu().numpy()
        cumulated_dim_out = np.hstack(
            [1, sitebasis.list_dim_out.cpu().numpy()]
        ).cumsum()
        freedom_per_site = cumulated_dim_out[
            np.vstack([basis_assignment, basis_assignment + 1])
        ].T

        # Selection matrix
        selection_matrix = []

        # Sparse matrix [compact_column_index, row_index, data] for the symmetrization
        symmetrized_matrix = [[0], [], []]
        symmetrization_factors = []

        # Orbit characterization dictionaries
        orbit_tracker = {}
        orbit_lengths = {}

        # Loop over orbits
        orbit_counter = 0
        for branch_index, branch in enumerate(tree.list_branches):
            for orbit_index, orbit in enumerate(branch.list_orbits):
                orbit_clusters = (
                    orbit.sitecentric_orbit if site_centric else orbit.unique_orbit
                )
                N_clusters = len(orbit_clusters)

                # Determine the basis index of all atoms composing the cluster
                basis_indexes = orbit.prototype
                if len(basis_indexes) == 0:
                    selection_matrix.append(np.zeros((1, 2, N), dtype=int))
                    symmetrized_matrix = fill_symmetrized_matrix(
                        symmetrized_matrix, 1, 1
                    )
                    symmetrization_factors.append(symmetrized_matrix[2][-1])
                    orbit_tracker["Orbit_%d_%d" % (branch_index, orbit_index)] = [
                        orbit_counter
                    ]
                    orbit_lengths["Orbit_%d_%d" % (branch_index, orbit_index)] = (
                        orbit.lengths.tolist()
                    )
                    orbit_counter += 1
                    continue

                # Determine all possible permutation of site basis
                cluster_functions = np.vstack(
                    [
                        arr.flatten()
                        for arr in np.meshgrid(
                            *[
                                range(freedom[0], freedom[1])
                                for freedom in freedom_per_site[basis_indexes]
                            ],
                            indexing="ij",
                        )
                    ],
                    dtype=int,
                ).T

                # Find all symmetrically-permutated cluster functions for all listed cluster functions
                permuted_cluster_functions = cluster_functions[:, orbit.permutations]
                # Remove duplicate cluster functions
                (cluster_functions, inverse_indexes) = np.unique(
                    permuted_cluster_functions.reshape(-1, len(basis_indexes)),
                    return_inverse=True,
                    axis=0,
                )
                # Remove duplicate permutations
                inverse_indexes = inverse_indexes.reshape(
                    permuted_cluster_functions.shape[:-1]
                )
                unique_permutations_indexes = np.unique(
                    np.sort(inverse_indexes, axis=-1), axis=0
                )

                # Fill matrices with unique symmetrically-permuted cluster functions
                for permutation_indexes in unique_permutations_indexes:
                    indexes = np.unique(permutation_indexes)

                    selection_matrix.append(
                        fill_selection_matrix(
                            orbit_clusters,
                            cluster_functions[indexes],
                            N,
                        )
                    )
                    symmetrized_matrix = fill_symmetrized_matrix(
                        symmetrized_matrix, N_clusters, len(indexes)
                    )
                    symmetrization_factors.append(symmetrized_matrix[2][-1])
                orbit_tracker["Orbit_%d_%d" % (branch_index, orbit_index)] = list(
                    range(
                        orbit_counter, orbit_counter + len(unique_permutations_indexes)
                    )
                )
                orbit_lengths["Orbit_%d_%d" % (branch_index, orbit_index)] = (
                    orbit.lengths.tolist()
                )
                orbit_counter += len(unique_permutations_indexes)

        selection_tensor = torch.tensor(np.vstack(selection_matrix)).int()
        symmetrization_segment_indexes = torch.tensor(symmetrized_matrix[0]).int()
        if normalization:
            symmetrization_factors_tensor = torch.tensor(symmetrization_factors).float()
        else:
            symmetrization_factors_tensor = torch.tensor(
                np.ones_like(symmetrization_factors)
            ).float()

        return cls(
            selection_tensor,
            symmetrization_segment_indexes,
            symmetrization_factors_tensor,
            orbit_tracker,
            orbit_lengths,
        )

    def _get_string(self) -> str:
        """
        String representation of the :py:obj:`Features` object that provides an overview of
        the correlation functions.

        Returns
        -------
        txt: string
            Multi-line string representation of the :py:obj:`Features` object.
        """

        tabs = []
        table = []
        # Sublattices involved in orbits
        list_fcts = []
        sublattices = []
        orbit_tracker = self.orbit_tracker()
        orbit_lengths = self.orbit_lengths()
        for orbit_key, __ in orbit_tracker.items():
            indexes = orbit_tracker[orbit_key]
            sitebasis = self.selection_matrix[
                self.symmetrization_segment_indexes[
                    indexes[0]
                ] : self.symmetrization_segment_indexes[indexes[-1] + 1],
                1,
                :,
            ].numpy(force=True)
            list_fcts.append(np.unique(sitebasis, axis=0, return_counts=True))
            sublattices.append(
                [
                    "_".join(np.unique(sitebasis[:, i]).astype(str))
                    for i in range(sitebasis.shape[-1])
                ]
            )
        unique_sublattices = np.unique(sum(sublattices, [])).tolist()
        for orbit_index, orbit_key, fct in zip(
            range(len(orbit_tracker)), orbit_tracker, list_fcts
        ):
            list_feature_indexes = orbit_tracker[orbit_key]
            list_lengths = orbit_lengths[orbit_key]
            if list_lengths == [None]:
                list_lengths = [np.nan]
            table.append(
                [
                    orbit_index,
                    fct[1][0],
                    "%.3f / %.3f" % (min(list_lengths), max(list_lengths)),
                    len(list_feature_indexes),
                    (
                        "%d -> %d" % (list_feature_indexes[0], list_feature_indexes[-1])
                        if len(list_feature_indexes) > 1
                        else "%d" % list_feature_indexes[0]
                    ),
                    " - ".join(
                        [
                            str(unique_sublattices.index(sublat) - 1)
                            for sublat in sublattices[orbit_index]
                            if unique_sublattices.index(sublat) != 0
                        ]
                    ),
                ]
            )
        tabs.append(
            [
                tabulate(
                    table,
                    [
                        "Orbit\nindex",
                        "Orbit\nsize",
                        "Orbit\nDimensions",
                        "Number of\nfeatures",
                        "Feature\nindexes",
                        "Cluster\ncomposition",
                    ],
                    tablefmt="simple",
                    colalign=["left", "right", "right", "right", "right", "center"],
                )
            ]
        )

        txt = tabulate(
            tabs,
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = "\n{s: ^{n}}\n".format(s="\033[1m FEATURES \033[0m", n=width) + txt + "\n"

        return txt

    def __str__(self) -> str:
        """String representation."""
        return "\n" + self._get_string() + "\n"
