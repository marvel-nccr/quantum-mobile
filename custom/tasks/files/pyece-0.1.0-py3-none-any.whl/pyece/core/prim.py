from __future__ import annotations

from warnings import warn

import numpy as np
from monty.json import MSONable
from numpy.typing import NDArray
from pymatgen.core import DummySpecies, Lattice, Structure
from pymatgen.io.vasp import Poscar
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer, SymmetrizedStructure
from tabulate import tabulate

from pyece.utils import coordinates, symmetry, toolbox


class Prim(MSONable):
    """Primitive unit cell of on-lattice models.

    This class defines the primitive crystal structure and degrees of freedom in each sublattice. It fundamentally defines the physical system to investigate.

    Parameters
    ----------
    structure : Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ of the prototype primitive cell
    allowed_elements : list[list[str]]
        List of list of allowed chemical species per atomic site in the structure

        Note
        ----
            Vacancies are treated as chemical species. The recognized symbol is \'Va\'.

    accuracy : int, default: 6
        Number of decimal places for floating point numbers. This parameter is used whenever an equality test is performed and serves as a tolerance parameter. Importantly, the lattice vectors and the atomic site vectors must display the same accuracy.
    symprec: float | None, default: None
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_. If None, the tolerence is set to 10^-accuracy.
    angle_tolerance: float | None, default: None
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_. If None, the tolerence is set to 10^-accuracy.

    Examples
    --------
    The following snippets illustrate several common systems::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim

        >>> # Fe-Al alloy on BCC
        >>> structure = Structure([[-1, 1, 1], [1, -1, 1], [1, 1, -1]],
        ...                       ["Fe"],
        ...                       [[0, 0, 0]])
        >>> bcc = Prim(structure=structure,
        ...            allowed_elements=[['Fe','Al']])
        >>> print(bcc)

        >>> # Cr-Mo-Nb-Ta-V-W high entropy alloy with vacancies (Va) on BCC
        >>> structure = Structure([[-1, 1, 1], [1, -1, 1], [1, 1, -1]],
        ...                       ["Nb"],
        ...                       [[0, 0, 0]])
        >>> bcc = Prim(structure=structure,
        ...            allowed_elements=[['Cr','Mo', 'Nb', 'Ta', 'V', 'W', 'Va']])
        >>> print(bcc)

        >>> # Ti-Zr alloy on omega
        >>> structure = Structure([[1, 0, 0], [0.5, np.sqrt(3) / 2, 0], [0, 0, 1]],
        ...                       ["Ti"] * 3,
        ...                       [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [2 / 3, 2 / 3, 0.5]])
        >>> omega = Prim(structure=structure,
        ...              allowed_elements=[['Ti', 'Zr']] * 3)
        >>> print(omega)

    Tip
    ---
    :py:obj:`~Prim` objects can conveniently be constructed using the function :py:meth:`~from_file` from a POSCAR file or using the function :py:meth:`~from_dict` from a MSONable dictionary.

    Attributes
    ----------
    accuracy : int, default: 6
        Number of decimal places for floating point numbers. This parameter is used whenever an equality test is performed and serves as a tolerance parameter. Importantly, the lattice vectors and the atomic site vectors must display the same accuracy.
    basis : np.ndarray
        Fractional coordinates of the atomic sites in the primitive unit cell
    elements : np.ndarray[str]
        List of all allowed chemical species in the primitive unit cell
    elements_per_site : list
        List of list of allowed chemical species per atomic site
    wyckoff_sites : dict
        Dictionary of symmetrically-equivalent atomic sites:
            - ``site_index``: list[list] -- prim site indexes in each group of symmetrically-equivalent sites
            - ``allowed_elements``: list[list] -- elements allowed in each group of symmetry-equivalent sites
            - ``wyckoff_symbols``: list -- Wyckoff symbol associated to each Wyckoff site
    structure : SymmetrizedStructure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ of the prototype primitive cell with permitted species for each site.
    lattice : Lattice
        Pymatgen Lattice object of the primitive unit cell
    spacegroup_symmops : np.ndarray[Any, int]
        Integer numpy array of spacegroup symmetry operations in fractional coordinates (row-wise convension)
    multiplication_table : np.ndarray[Any, int]
        Integer numpy array of the multiplication table of the spacegroup symmetry operations
    basis_action : np.ndarray[Any, int]
        Integer numpy array of the transformed basis atomic sites after performing all symmetry operations, i.e., group action of the spacegroup symmetry operations on the basis
    cutoff : float
        Cutoff radius of interactions to build the neighborhood
    neighborhood : np.ndarray[Any, int]
        Integer numpy array of the neighborhood of atomic sites in unitcell coordinates within the cutoff radius
    symprec: float
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.
    angle_tolerance: float
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.
    """

    def __init__(
        self,
        structure: Structure,
        allowed_elements: list[list[str]],
        accuracy: int = 6,
        symprec: float | None = None,
        angle_tolerance: float | None = None,
    ) -> None:
        def sort_elems(elements):
            sorted_elements = sorted(list(elements))
            if "Va" in elements:
                sorted_elements.pop(sorted_elements.index("Va"))
                sorted_elements.append("Va")
            if "Zzz" in elements:
                sorted_elements.pop(sorted_elements.index("Zzz"))
                sorted_elements.append("Zzz")
            return sorted_elements

        assert len(structure) == len(allowed_elements), RuntimeError(
            "The number of atomic sites in the structure (%d) does not match the number of lists in allowed_elements (%d)"
            % (len(structure), len(allowed_elements))
        )

        elements_per_site_dof = []
        elements_per_site_fixed = []
        site_index = 0
        for elems in allowed_elements:
            # elems = sort_elems(elems)
            specie = (
                DummySpecies("X" + "".join(elems), oxidation_state=None)
                if len(elems) > 1
                else elems[0]
            )
            if len(elems) > 1:
                structure.replace(
                    site_index, specie, properties={"permitted_species": elems}
                )
                elements_per_site_dof.append(elems)
                site_index += 1
            else:
                coords = structure.frac_coords[site_index]
                structure.remove_sites([site_index])
                structure.insert(
                    len(structure),
                    specie,
                    coords,
                    coords_are_cartesian=False,
                    properties={"permitted_species": elems},
                )
                elements_per_site_fixed.append(elems)
                warn(
                    "The atomic site %d has no chemical degree of freedom and is hence moved to the end of the atomic site list."
                    % site_index
                )
        elements_per_site = elements_per_site_dof + elements_per_site_fixed

        # Symmetrized structure
        self.symprec: float
        if symprec is None:
            self.symprec = 10**-accuracy
        else:
            self.symprec = symprec

        self.angle_tolerance: float
        if angle_tolerance is None:
            self.angle_tolerance = 10**-accuracy
        else:
            self.angle_tolerance = angle_tolerance

        sym_structure = SpacegroupAnalyzer(
            structure, symprec=self.symprec, angle_tolerance=self.angle_tolerance
        ).get_symmetrized_structure()

        # accuracy for comparison
        self.accuracy: int = accuracy

        # prim structure
        self.structure: SymmetrizedStructure = sym_structure
        self.lattice: Lattice = sym_structure.lattice

        # occupancy
        self.basis: np.ndarray = sym_structure.frac_coords.astype(float)
        self.elements: NDArray[np.str_] = np.array(
            sort_elems(np.unique(sum(allowed_elements, []))), dtype="str"
        )
        self.elements_per_site: list[list] = elements_per_site
        self.site_occupancy_matrix: NDArray[np.int_] = np.array(
            [
                [elem in self.elements_per_site[site_index] for elem in self.elements]
                for site_index in range(len(self.basis))
            ],
            dtype=int,
        )
        self.wyckoff_sites: dict = {
            "site_index": sym_structure.equivalent_indices,
            "allowed_elements": [
                elements_per_site[list_indexes[0]]
                for list_indexes in sym_structure.equivalent_indices
            ],
            "wyckoff_symbols": sym_structure.wyckoff_symbols,
        }

        # spacegroup operations
        self.spacegroup_symmops: NDArray[np.floating] = (
            symmetry.generate_spacegroup_matrices(
                self.structure,
                cartesian=False,
                symprec=self.symprec,
                angle_tolerance=self.angle_tolerance,
            )
        )
        self.multiplication_table: NDArray[np.int_] = symmetry.get_multiplication_table(
            self.spacegroup_symmops, accuracy
        )
        self.basis_action: NDArray[np.int_] = coordinates.fractional_to_unitcell(
            symmetry.group_action(self.spacegroup_symmops, self.basis),
            self.basis,
            self.accuracy,
        )

        return

    def get_element_dict(self) -> dict:
        """Returns a dictionary that associates the name of the elements with their
        index.

        Returns
        -------
        element_dict: dict
        """
        element_dict = {}
        for index, element in enumerate(self.elements):
            element_dict[element] = index
        return element_dict

    def get_prim_wyckoff_indexes(self) -> NDArray[np.int_]:
        """Returns the index of the Wyckoff group of sites that each basis site in the
        prim belongs to. Two sites are fined as symmetrically-equivalent if there exists a symmetry
        operation that transforms one site to the other and if they allow for the same
        chemical species.

        Returns
        -------
        wyckoff: np.ndarray[int]
            Integer numpy array with the indexes of the Wyckoff group for each atomic site.
        """
        site_indexes = np.arange(
            sum([len(indexes) for indexes in self.wyckoff_sites["site_index"]])
        )
        wyckoff = np.zeros(len(site_indexes), dtype=int)
        for site_id in site_indexes:
            for wyckoff_id, list_sites in enumerate(self.wyckoff_sites["site_index"]):
                if site_id not in list_sites:
                    continue
                wyckoff[site_id] = wyckoff_id
        return wyckoff

    def apply_symmop(
        self, unitcell_array: NDArray[np.int_], symmop_index: NDArray[np.int_]
    ) -> NDArray[np.int_]:
        """Apply the symmetry operation to the unitcell_array object.

        Parameters
        ----------
        unitcell_array: np.ndarray[int]
            Numpy array of the object in unitcell coordinates
        symmop_index: np.array[int]
            Integer numpyarray of indexes of the symmetry operations as listed in self.spacegroup_symmops

        Returns
        -------
        unitcell_array: np.ndarray[int]
            Numpy array of unitcell coordinates (symmop_index.shape + unitcell_array.shape)
        """

        # Operation translation vector
        translations = np.take(unitcell_array, [0, 1, 2], axis=-1)
        translations = translations @ self.spacegroup_symmops[symmop_index, :-1].astype(
            int
        )

        # Operation basis
        basis = np.take(unitcell_array, 3, axis=-1)
        unitcell_array = np.take(
            np.take(self.basis_action, symmop_index, axis=0), basis, axis=-2
        )
        unitcell_array += translations

        return unitcell_array

    def get_neighborhood(self, cutoff: float) -> None:
        r"""Collect all neighboring atomic sites within a sphere of ``cutoff`` radius,
        centered in the middle of the unitcell. The neighbor site corrdinates are in unitcell coordinates.

        Parameters
        ----------
        cutoff: float
            Cutoff radius of interaction

        Examples
        --------
        The following example show the neighborhood of a BCC structure with a cutoff radius of 4 \A::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim

            >>> # Fe-Al alloy on BCC
            >>> structure = Structure([[-1.8, 1.8, 1.8], [1.8, -1.8, 1.8], [1.8, 1.8, -1.8]],
            ...                       ["Fe"],
            ...                       [[0, 0, 0]])
            >>> bcc = Prim(structure=structure,
            ...            allowed_elements=[['Fe','Al']])
            >>> bcc.get_neighborhood(cutoff=4)
            >>> bcc.neighborhood
            np.array([[ 0  0  0  0],
                      [-1  0  0  0],
                      [ 0 -1  0  0],
                      [ 0  0 -1  0],
                      [ 0  0  1  0],
                      [ 0  1  0  0],
                      [ 1  0  0  0],
                      [-1 -1  0  0],
                      [-1  0 -1  0],
                      [ 0 -1 -1  0],
                      [ 0  1  1  0],
                      [ 1  0  1  0],
                      [ 1  1  0  0],
                      [-1 -1 -1  0],
                      [ 1  1  1  0]])
        """

        # All neighbors for all atomic sites in the unitcell
        neighbor_list = self.structure.get_neighbor_list(
            r=max(cutoff, 1e-10), exclude_self=False
        )

        # Keep sites with some degree of freedom
        sites_with_freedom = np.array(
            [
                site
                for site in range(len(self.elements_per_site))
                if len(self.elements_per_site[site]) > 1
            ]
        )
        selection = [
            ind
            for ind in range(len(neighbor_list[0]))
            if (neighbor_list[0][ind] in sites_with_freedom)
            and (neighbor_list[1][ind] in sites_with_freedom)
        ]

        # Sort neighbors according to the unitcell indexes
        neighborhood = np.hstack(
            [neighbor_list[2].astype(int), neighbor_list[1].reshape(-1, 1)]
        )[selection]
        sorted_indexes = np.unique(
            np.hstack(
                [
                    np.sort(np.abs(neighborhood[:, :-1]), axis=1)[:, ::-1],
                    neighborhood,
                ]
            ),
            axis=0,
            return_index=True,
        )[1]
        neighborhood = neighborhood[sorted_indexes]

        self.cutoff = cutoff
        self.neighborhood = neighborhood
        return

    def get_neighbor_site_indexes(
        self, unitcell_array: NDArray[np.int_]
    ) -> NDArray[np.int_]:
        """Matches the unitcell coordinates in `unitcell_array` with neighboring atomic
        sites in :py:attr:`~.Prim.neighborhood`.

        Parameters
        ----------
        unitcell_array: np.ndarray[int]
            Numpy array of the unitcell coordinates

        Returns
        -------
        indexes: np.ndarray[int]
            Integer numpy array with the indexes of the neighboring atomic sites

        Examples
        --------
        The following example show the indexes of the neighboring atomic site for three different coordinates::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim

            >>> # Fe-Al alloy on BCC
            >>> structure = Structure([[-1.8, 1.8, 1.8], [1.8, -1.8, 1.8], [1.8, 1.8, -1.8]],
            ...                       ["Fe"],
            ...                       [[0, 0, 0]])
            >>> bcc = Prim(structure=structure,
            ...            allowed_elements=[['Fe','Al']])
            >>> bcc.get_neighborhood(cutoff=4)
            >>> bcc.neighborhood
            np.array([[ 0  0  0  0],
                      [-1  0  0  0],
                      [ 0 -1  0  0],
                      [ 0  0 -1  0],
                      [ 0  0  1  0],
                      [ 0  1  0  0],
                      [ 1  0  0  0],
                      [-1 -1  0  0],
                      [-1  0 -1  0],
                      [ 0 -1 -1  0],
                      [ 0  1  1  0],
                      [ 1  0  1  0],
                      [ 1  1  0  0],
                      [-1 -1 -1  0],
                      [ 1  1  1  0]])

            >>> # coordinate array to find the indexes of
            >>> unitcell_array = np.array([[0, 0, 0, 0],
            ...                            [0, 1, 0, 0],
            ...                            [1, 0, 1, 0],])
            >>> bcc.get_neighbor_site_indexes(unitcell_array)
            np.array([ 0,  5, 11])
        """
        assert hasattr(
            self, "neighborhood"
        ), "The 'neighborhood' attribute of the Prim object is not built yet."

        shape = list(unitcell_array.shape)

        # find equals
        unitcell_array = unitcell_array.reshape(-1, 4)
        differences = (
            np.tile(self.neighborhood[:, np.newaxis], reps=[1, len(unitcell_array), 1])
            - unitcell_array
        )

        # indexes
        indexes_tuple = np.nonzero(
            np.linalg.norm(differences, axis=-1) < 10**-self.accuracy
        )
        if len(indexes_tuple[0]) != len(unitcell_array):
            raise ValueError(
                "Unable to find all atoms in the neighborhood. Try to increase the cutoff radius when computing the neighborhood."
            )
        indexes = indexes_tuple[0][np.argsort(indexes_tuple[1])].reshape(shape[:-1])
        return indexes.astype(int)

    def get_supercell_transformation(self, supercell: np.ndarray) -> NDArray[np.int_]:
        """Find the supercell transformation matrix that transforms the prim cell to the
        supercell assuming the structure is ideal (i.e., no lattice deformation).

        Parameters
        ----------
        supercell: np.ndarray
            Numpy array of the lattice of the superstructure (in row-wise convention)

        Returns
        -------
        transformation: np.ndarray[int]
            Integer numpy array of the supercell transformation (in row-wise convention)
        """
        transformation = np.matmul(supercell, np.linalg.inv(self.lattice.matrix))
        transformation = np.around(transformation, decimals=self.accuracy)
        if not np.all(toolbox.is_integer(transformation)):
            raise RuntimeError("Transformation matrix is not made of integers only.")
        return np.rint(transformation).astype(int)

    def as_dict(self) -> dict:
        """MSONable dictionary of the Prim class.

        Returns
        -------
        dct: dict
            MSONable dictionary
        """

        occ = {
            "basis_sites": self.basis.tolist(),
            "elements": self.elements.tolist(),
            "elements_per_site": self.elements_per_site,
            "wyckoff_sites": self.wyckoff_sites,
        }
        spg = {
            "symmops": self.spacegroup_symmops.tolist(),
            "multiplication_table": self.multiplication_table.tolist(),
            "group_action_on_basis": self.basis_action.tolist(),
            "symprec": self.symprec,
            "angle_tolerance": self.angle_tolerance,
        }

        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "structure": self.structure.as_dict()["structure"],
            "occupancy": occ,
            "spacegroup": spg,
            "accuracy": self.accuracy,
        }

        if hasattr(self, "neighborhood"):
            dct["neighbors"] = {
                "neighborhood": self.neighborhood.tolist(),
                "cutoff": self.cutoff,
            }

        return dct

    @classmethod
    def from_dict(cls, dct):
        """Create the Prim class from a MSONable dictionary.

        Parameters
        ----------
        dct: dict
            MSONable dictionary of the :py:obj:`Prim`.
        """

        structure = Structure.from_dict(dct["structure"])
        for site_index in range(len(structure)):
            structure.replace(site_index, "X", label="X")

        prim = cls(
            structure,
            dct["occupancy"]["elements_per_site"],
            dct["accuracy"],
            dct["spacegroup"]["symprec"] if "symprec" in dct["spacegroup"] else None,
            (
                dct["spacegroup"]["angle_tolerance"]
                if "angle_tolerance" in dct["spacegroup"]
                else None
            ),
        )
        if "neighbors" in dct.keys():
            prim.cutoff = dct["neighbors"]["cutoff"]
            prim.neighborhood = np.array(dct["neighbors"]["neighborhood"], dtype=int)

        return prim

    @classmethod
    def from_file(
        cls,
        path_to_file: str,
        accuracy: int = 6,
        symprec: float | None = None,
        angle_tolerance: float | None = None,
    ):
        """Read the PRIM input file that describes the primitive crystal structure and
        the degree of freedom of the sublattices. The PRIM file basically consists of a
        VASP POSCAR file with no chemical species line (i.e. line 6 in convensional
        POSCAR file). Instead, the allowed chemical species per atomic sites are written
        after the coordinates of each atomic site.

        Parameters
        ----------
        path_to_file: str
            String with the path to the PRIM file containing the prim structure and allowed chemical species on each atomic site
        accuracy : int, default: 6
            Number of decimal places for floating point numbers. This parameter is used whenever an equality test is performed and serves as a tolerance parameter. Importantly, the lattice vectors and the atomic site vectors must display the same accuracy.
        symprec: float | None, default: None
            Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_. If None, the tolerence is set to 10^-accuracy.
        angle_tolerance: float | None, default: None
            Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_. If None, the tolerence is set to 10^-accuracy.

        Returns
        -------
        Prim
            Prim object

        Example
        -------
        Below is an example of such a PRIM file for a conventional BCC cell with two distinct atomic sites (one allowing for Al and Ti and the other allowing for Nb and Ti):

        .. code-block:: text

            BCC
            1.00000000000000
                3.57279320 0.00000000 0.00000000
                0.00000000 3.57279320 0.00000000
                0.00000000 0.00000000 3.57279320
                2
            Direct
                0.00000000 0.00000000 0.00000000 Al Ti
                0.50000000 0.50000000 0.50000000 Nb Ti
        """

        # Read PRIM file
        with open(path_to_file, "r") as f:
            file = f.readlines()
            f.close()

        # Read structure
        N = len([s for s in file[5].split(" ") if (len(s) and (s != "\n"))])
        string_poscar = (
            "".join(file[:5])
            + " ".join(["X%d" % i for i in range(N)])
            + "\n"
            + "".join(file[5:])
        )  # create single-element structure
        structure = Poscar.from_str(string_poscar).structure

        # Read allowed chemical species per site
        allowed_elements = []
        with open(path_to_file, "r") as f:
            file = f.readlines()
            f.close()
        for line in file[7 : 7 + len(structure)]:
            elems, indexes = np.unique(line.split()[3:], return_index=True)
            allowed_elements.append(elems[np.argsort(indexes)].tolist())

        return cls(structure, allowed_elements, accuracy, symprec, angle_tolerance)

    def _get_string(self) -> str:
        """
        String representation of the :py:obj:`Prim` object that provides an overview of
        the lattice and permitted species at each site.

        Returns
        -------
        txt: string
            Multi-line string representation of the :py:obj:`Prim` object.
        """

        tabs = []

        # Tabulate General
        table = [
            [
                "Space group",
                ":",
                "{} ({})".format(
                    self.structure.get_space_group_info()[0],
                    self.structure.get_space_group_info()[1],
                ),
            ],
            [
                "Chemical species\nChemical indexes",
                ":",
                tabulate(
                    [self.elements.tolist(), list(range(len(self.elements)))],
                    tablefmt="plain",
                    colalign=["right"] * len(self.elements),
                ),
            ],
            ["Symmetries", ":", "{} operations".format(len(self.spacegroup_symmops))],
            ["Accuracy", ":", "{} digits".format(self.accuracy)],
            [
                "Cutoff",
                ":",
                "{} Å".format(self.cutoff) if hasattr(self, "cutoff") else "Not set",
            ],
            [
                "neighborhood size",
                ":",
                (
                    "{} atomic sites".format(len(self.neighborhood))
                    if hasattr(self, "neighborhood")
                    else "Not set"
                ),
            ],
        ]
        tabs.append([tabulate(table, ["General:\n--------", "", ""], tablefmt="plain")])

        # Tabulate Lattice
        table = [
            [
                "a\nb\nc",
                tabulate(
                    [[value for value in vector] for vector in self.lattice.matrix],
                    tablefmt="plain",
                    # floatfmt=".6f",
                ),
            ],
        ]
        tabs.append([tabulate(table, ["Lattice:\n--------", ""], tablefmt="plain")])

        # Tabulate Basis
        table = [
            [
                "\n".join([str(i) for i in range(len(self.basis))]),
                tabulate(
                    [[value for value in vector] for vector in self.basis],
                    tablefmt="plain",
                    # floatfmt=".6f",
                ),
                "\n".join(
                    [
                        "%d (%s)" % (i, self.wyckoff_sites["wyckoff_symbols"][i])
                        for i in self.get_prim_wyckoff_indexes()
                    ]
                ),
                tabulate(
                    [
                        [elem for elem in site.properties["permitted_species"]]
                        for site in self.structure
                    ],
                    tablefmt="plain",
                ),
            ],
        ]
        tabs.append(
            [
                tabulate(
                    [
                        [
                            tabulate(
                                table,
                                [
                                    "Index",
                                    "Coordinates",
                                    "Wyckoff",
                                    "Permitted species",
                                ],
                                tablefmt="simple",
                                colalign=("left", "left", "center", "left"),
                            )
                        ]
                    ],
                    ["Basis:\n------"],
                    tablefmt="plain",
                )
            ]
        )

        txt = tabulate(
            tabs,
            # tablefmt="mixed_outline",
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = "\n{s: ^{n}}\n".format(s="\033[1m PRIM \033[0m", n=width) + txt + "\n"

        return txt

    def __str__(self) -> str:
        """String representation."""
        return "\n" + self._get_string() + "\n"
