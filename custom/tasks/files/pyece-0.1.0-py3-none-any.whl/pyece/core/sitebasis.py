import warnings
from typing import Literal

import numpy as np
import torch
from monty.json import MSONable
from numpy.typing import NDArray
from tabulate import SEPARATING_LINE, tabulate
from torch import Tensor, nn, no_grad

from pyece.core.prim import Prim


class SiteBasis(nn.Module, MSONable):
    r"""
    Collection of learnable site-basis functions.

    Site-basis functions are site-dependent functions that return a unique value as a function of the chemical specie sitting at the atomic site. All sites belonging to the same Wyckoff group of equivalent sites are assigned the same set of site-basis functions. The number of sets of site-basis functions is equal to the number of groups of equivalent sites.
    The constant function, i.e., function that returns the value 1 regardless of the chemical specie, is present in all sets of site-basis functions by construction.
    The number of site-basis functions included in each Wyckoff group of equivalent sites determines the embedding dimension.

    Embedded site-basis functions :math:`\tilde{\varphi}` are constructed as:

    .. math::

        \tilde{\varphi} = \mathcal{T} \varphi

    where :math:`\mathcal{T}` is the learnable projection (embedding) matrix, and :math:`\varphi` the unprojected site-basis functions (e.g., the Chebyshev basis).

    Parameters
    ----------
    list_species_in: list[Tensor]
        List of integer pytorch tensors with the chemical indexes of permitted chemical species for all Wyckoff groups of equivalent sites
    list_dim_out: Tensor
        Integer pytorch tensor with the embedding freedom (embedding dimensions - 1) for each Wyckoff group of equivalent sites.
    neighbor_basis_index: Tensor
        Integer pytorch tensor with the index of the set of site-basis functions :math:`\tilde{\varphi}` associated with each neighbor site found in :py:attr:`~.pyece.core.prim.Prim.neighborhood`.
    list_basis: Tensor
        List of pytorch tensors with the unprojected site-basis functions :math:`\varphi`

    Tip
    ---
    :py:obj:`SiteBasis` objects can conveniently be constructed using the function :py:meth:`~build_sitebasis` from a :py:obj:`~.pyece.core.prim.Prim` object or using the function :py:meth:`~from_dict` from a MSONable dictionary.

    Attributes
    ----------
    neighbor_basis_index: Tensor
        Integer pytorch tensor with the index of the set of site-basis functions :math:`\tilde{\varphi}` associated with each neighbor site found in :py:attr:`~.pyece.core.prim.Prim.neighborhood`.
    N_species : int
        Total number of chemical species in the system
    list_dim_in: Tensor
        Integer pytorch tensor with the chemical freedom (number of admissible chemcial species - 1) for each Wyckoff group of equivalent sites (input dimensions of the projection matrices).
    list_dim_out: Tensor
        Integer pytorch tensor with the embedding freedom (embedding dimensions - 1) for each Wyckoff group of equivalent sites (output dimensions of the projection matrices).
    projection_matrices: nn.ModuleList
        Pytorch ModuleList object containing the learnable projection (embedding) matrices
    sitebasis_functions: Tensor
        The projected (embedded) site-basis functions in the form of a unique tensor (to be generated with :py:meth:`compute_sitebasis_functions`)
    """

    def __init__(
        self,
        list_species_in: list[Tensor],
        list_dim_out: Tensor,
        neighbor_basis_index: Tensor,
        list_basis: list[Tensor],
    ) -> None:
        super().__init__()

        # Assignment of basis for each site in neighborhood
        self.neighbor_basis_index: Tensor
        self.register_buffer("neighbor_basis_index", neighbor_basis_index.int())

        # Projection matrices
        self.N_species: int = max([int(ls.max()) for ls in list_species_in]) + 1
        self.list_dim_in: Tensor = torch.tensor(
            [len(ls) - 1 for ls in list_species_in]
        ).int()
        self.list_dim_out: Tensor
        self.register_buffer("list_dim_out", list_dim_out.int())
        self.constant_padding = nn.ConstantPad2d((0, 0, 1, 0), 1)
        self.projection_matrices: nn.ModuleList = nn.ModuleList(
            [
                (
                    nn.Sequential(
                        (
                            nn.Linear(
                                in_features=int(dim_in),
                                out_features=int(dim_out),
                                bias=False,
                            )
                            if dim_in > dim_out
                            else nn.Identity()
                        ),
                        nn.ConstantPad2d(
                            (0, 0, 0, self.N_species - int(dim_in) - 1), float("Inf")
                        ),
                    )
                )
                for dim_in, dim_out in zip(self.list_dim_in, list_dim_out)
            ]
        ).to(self.list_dim_out.device)

        # Unprojected matrices
        self.list_indexes: list[int] = [
            basis_index
            for basis_index, basis in enumerate(list_basis)
            if len(basis) > 1
        ]
        self.N_sitebasis: int = len(list_basis)
        for basis_index, basis in enumerate(list_basis):
            self.register_buffer(
                "species_in_%d" % basis_index, list_species_in[basis_index].int()
            )
            mask = torch.ones(
                self.N_species, device=list_species_in[basis_index].device
            ).bool()
            mask[list_species_in[basis_index]] = False
            self.register_buffer(
                "permutation_%d" % basis_index,
                torch.cat(
                    [list_species_in[basis_index], torch.nonzero(mask).reshape(-1)]
                )
                .argsort()
                .int(),
            )
            self.register_buffer("basis_%d" % basis_index, basis.float())

        return

    def forward(self) -> Tensor:
        """
        Pytorch forward functions that evaluates the projected site-basis functions

        Returns
        -------
        Tensor
            Pytorch tensor with the projected site basis functions for all neighbor sites
        """
        list_basis = []
        for basis_index in self.list_indexes:
            basis = self.__getattr__("basis_%d" % basis_index)
            list_basis.append(
                self.projection_matrices[basis_index](basis[1:].T).T[
                    :, self.__getattr__("permutation_%d" % basis_index)
                ]
            )
        return self.constant_padding(torch.cat(list_basis, dim=0))

    def prod(self, mode: bool = True) -> None:
        """
        Set the module in producing mode.

        In producing mode, the projection (embedding) matrix does not need to be learnt at every step. It can therefore be evaluated once and for all. The site-basis functions are stored in :py:attr:`~.pyece.core.sitebasis.SiteBasis.sitebasis_functions`.

        Parameters
        ----------
        mode: bool, default: True
            Whether to set procuction mode (True) or not (False).
        """
        if not isinstance(mode, bool):
            raise ValueError("Producing mode is expected to be boolean")
        if mode:
            self.eval()
            self.compute_sitebasis_functions()
        return

    def list_species_in(self):
        """
        Returns the chemical indexes of permitted chemical species for each Wyckoff group of equivalent sites.

        Returns
        -------
        list_species_in: list[Tensor]
            List of integer pytorch tensor with the chemical indexes of permitted chemcial species for each Wyckoff group of equivalent sites
        """
        list_species = []
        for basis_index in range(self.N_sitebasis):
            list_species.append(self.__getattr__("species_in_%d" % basis_index))
        return list_species

    def basis(self):
        """
        Returns the unprojected site-basis functions for each Wyckoff group of equivalent sites.

        Returns
        -------
        list_basis: list[Tensor]
            List of pytorch tensors with the unprojected site-basis functions for each Wyckoff group of equivalent sites
        """
        list_basis = []
        for basis_index in range(self.N_sitebasis):
            list_basis.append(self.__getattr__("basis_%d" % basis_index))
        return list_basis

    def projection(self) -> list[Tensor]:
        """
        Returns the projection (embedding) matrices for each Wyckoff group of equivalent sites

        Returns
        -------
        list_basis: list[Tensor]
            List of pytorch tensors with the weights of the projection (embedding) matrices for each Wyckoff group of equivalent sites
        """
        return [
            (
                matrix[0].weight.data
                if isinstance(matrix[0], nn.Linear)
                else torch.eye(int(dim_in))
            )
            for dim_in, matrix in zip(self.list_dim_in, self.projection_matrices)
        ]

    @no_grad()
    def embedded_basis(self):
        r"""
        Returns the embedded site-basis functions :math:`\tilde{\varphi}` for each Wyckoff group of equivalent sites.

        Returns
        -------
        list_basis: list[Tensor]
            List of pytorch tensors with the embedded site-basis functions :math:`\tilde{\varphi}` for each Wyckoff group of equivalent sites
        """
        list_basis = []
        for basis_index in range(self.N_sitebasis):
            basis = self.__getattr__("basis_%d" % basis_index)
            list_basis.append(
                self.constant_padding(
                    self.projection_matrices[basis_index][0](basis[1:].T).T
                )
            )
        return list_basis

    @no_grad()
    def compute_sitebasis_functions(self):
        """
        Computes and stores the projected (embedded) site-basis functions in :py:attr:`~.pyece.core.sitebasis.SiteBasis.sitebasis_functions` in the form of a unique tensor.

        """
        # self.register_buffer("sitebasis_functions", self())
        self.sitebasis_functions = self()
        return

    def normalize(self) -> None:
        """
        Normalize the rows of the projection (embedding) matrices
        """
        for matrix in self.projection_matrices:
            if isinstance(matrix[0], nn.Linear):
                matrix[0].weight.data = nn.functional.normalize(
                    matrix[0].weight.data, dim=1
                )
        return

    def initialize(self, prim: Prim) -> None:
        """
        Initialize the projection (embedding) matrices based on chemical properties of the admissible chemical species.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        """
        device = self.neighbor_basis_index.device
        for matrix, B, elements in zip(
            self.projection_matrices,
            self.basis(),
            prim.wyckoff_sites["allowed_elements"],
        ):
            if isinstance(matrix[0], nn.Linear):
                try:
                    P = chemical_preconditioning(elements)[0]
                    U, S, V = np.linalg.svd(
                        B[1:].numpy(force=True), full_matrices=False
                    )
                    M = P[: int(matrix[0].out_features)] @ V.T @ np.diag(S**-1) @ U.T
                    matrix[0].weight.data = torch.tensor(
                        M,
                        device=device,
                    ).float()
                except np.linalg.LinAlgError:
                    warnings.warn(
                        "Impossible to find an initialization to the elements %s"
                        % "-".join(elements)
                    )
            elif isinstance(matrix[0], nn.Identity):
                continue
            else:
                raise ValueError
        self.normalize()
        return

    def set_basis_matrix(self, initial_basis: np.ndarray, basis_index: int) -> None:
        """
        Function used to set a given unprojected site-basis matrix with a self-determined matrix.

        Parameters
        ----------
        basis_matrix: np.ndarray
            Numpy array with the matrix of the self-determined unprojected basis.
        basis_index: int
            Index of the unprojected basis to intialize.
        """
        device = self.neighbor_basis_index.device
        self.__setattr__(
            "basis_%d" % basis_index,
            torch.tensor(
                initial_basis,
                device=device,
            ).float(),
        )
        return

    def set_projection_matrix(
        self, initial_matrix: np.ndarray, matrix_index: int
    ) -> None:
        """
        Function used to initialize a given projection (embedding) matrix with a self-determined matrix.

        Parameters
        ----------
        initial_matrix: np.ndarray
            Numpy array with the initial self-determined projection matrix.
        matrix_index: int
            Index of the matrix in :py:attr:`projection_matrices` to intialize.
        """
        device = self.neighbor_basis_index.device
        self.projection_matrices[matrix_index][0].weight.data = torch.tensor(
            initial_matrix,
            device=device,
        ).float()
        self.normalize()
        return

    def get_basis_assignment(self) -> list[Tensor]:
        """
        For each set of site-basis functions, assigns all neighbor sites associated to that set of site-basis functions, i.e., groups neighbor sites belonging to the same Wyckoff group of equivalent sites together.

        Returns
        -------
        basis_assignment: Tensor
            Pytorch tensor with the indexes of all neighbor sites assigned to each set of site-basis functions
        """
        basis_assignment = [
            torch.nonzero(self.neighbor_basis_index == basis_index).reshape(-1).int()
            for basis_index in range(len(self.list_dim_in))
        ]
        return basis_assignment

    def as_dict(self) -> dict:
        """
        MSONable dictionary of the :py:obj:`SiteBasis` class.

        Returns
        -------
        dct: dict
            MSONable dictionary
        """

        neighbor = {
            "neighbor_basis_index": self.neighbor_basis_index.tolist(),
            "basis_assignment": [
                assignment.tolist() for assignment in self.get_basis_assignment()
            ],
        }
        basis = {
            "species_in": [
                species_in.tolist() for species_in in self.list_species_in()
            ],
            "matrices": [basis.tolist() for basis in self.basis()],
        }
        projection = {
            "list_dim_in": self.list_dim_in.tolist(),
            "list_dim_out": self.list_dim_out.tolist(),
            "matrices": [
                matrix.weight.data.detach().tolist()
                for matrix in self.projection_matrices
            ],
        }

        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "neighborhood": neighbor,
            "basis": basis,
            "projection": projection,
        }

        return dct

    @classmethod
    def from_dict(cls, dct):
        """
        Create the :py:obj:`SiteBasis` class from a MSONable dictionary.

        Parameters
        ----------
        dct: dict
            MSONable dictionary of the :py:obj:`SiteBasis`.
        """

        list_species_in = [
            torch.tensor(species).int() for species in dct["basis"]["species_in"]
        ]
        list_dim_out = torch.tensor(dct["projection"]["list_dim_out"]).int()
        neighbor_basis_index = torch.tensor(
            dct["neighborhood"]["neighbor_basis_index"]
        ).int()
        basis = [torch.tensor(B) for B in dct["basis"]["matrices"]]

        sitebasis = cls(list_species_in, list_dim_out, neighbor_basis_index, basis)
        for index, matrix in enumerate(sitebasis.projection_matrices):
            matrix.weight = nn.Parameter(
                torch.tensor(dct["projection"]["matrices"][index]).float()
            )

        return sitebasis

    @classmethod
    def build_sitebasis(
        cls,
        prim: Prim,
        embedding_dimensions: NDArray[np.int_],
        basis_type: (
            Literal["chebyshev", "occupational"]
            | list[Literal["chebyshev", "occupational"]]
        ) = "chebyshev",
    ):
        """
        Constructs the :py:obj:`SiteBasis` module

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice
        embedding_dimensions:  np.ndarray[Any, int]
            Integer numpy array of the embedding dimensions for each sublattices (atomic sites in :py:obj:`~.pyece.core.prim.Prim`).
            The dimensions are expected to be sorted the same way as the atomic site coordinates in :py:attr:`~.pyece.core.prim.Prim.basis`.
            In case of conflict (i.e., two equivalent sites assigned different embedding dimensions), the largest dimension will be chosen.
            In case of an empty array, the embedding dimensions are automatically determined such that the chemical embedding accounts for 95% of the variance.
            In case of a scalar array, the embedding dimensions are set to the same values for each Wyckoff group.
            Finally, in case of a scalar array with value smaller or equal to 0, no embedding dimensions is set (i.e., embedding dimensions are equal to the number of allowed elements).
        basis_type: str | list[str], default: \'chebyshev\'
            Type of unprojected site-basis functions (\'chebyshev\' or \'occupational\').
            If a string is given, the same type of unprojected site-basis functions is used for all asymmetric sites.
            Otherwise, a list of unprojected site-basis function types can be given for each site in the prim unitcell. The list must be of the same length as the number of sites in the the prim unitcell.

        Returns
        -------
        SiteBasis
            :py:obj:`SiteBasis` pytorch module

        Examples
        --------
        The following example illustrate the construction of a :py:obj:`SiteBasis` object from Cr-Mo-Nb-Ta-V-W BCC alloy with 3 embedding dimensions::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.sitebasis import SiteBasis

            >>> # Cr-Mo-Nb-Ta-V-W high entropy alloy on BCC
            >>> structure = Structure(
            ...     np.array([[-1, 1, 1], [1, -1, 1], [1, 1, -1]]) * 1.65,
            ...     ["Nb"],
            ...     [[0.0, 0.0, 0.0]],
            ... )
            >>> bcc = Prim(
            ...     structure=structure,
            ...     allowed_elements=[
            ...         ["Cr", "Mo", "Nb", "Ta", "V", "W"],
            ...     ],
            ... )
            >>> bcc.get_neighborhood(4.0)
            >>> print(bcc)

            >>> # Construct site-basis functions
            >>> basis = SiteBasis.build_sitebasis(
            ...     prim=bcc,
            ...     embedding_dimensions=np.array([3]),
            ... )
            >>> print(basis)


        The following example illustrate the construction of a :py:obj:`SiteBasis` object for the same alloy but now H atoms (or vacancies) can additionally sit on octaedral interstitial sites.
        The metal atoms are projected to 3 dimensions with a Chebyshev unprojected site-basis function type, while the octaedral interstitial sites are of occupational type::

            >>> import numpy as np
            >>> from pymatgen.core import Structure
            >>> from pyece.core.prim import Prim
            >>> from pyece.core.sitebasis import SiteBasis

            >>> # Cr-Mo-Nb-Ta-V-W high entropy alloy on BCC
            >>> structure = Structure(
            ...     np.array([[-1, 1, 1], [1, -1, 1], [1, 1, -1]]) * 1.65,
            ...     ["Nb", "H", "H", "H"],
            ...     [[0.0, 0.0, 0.0], [0.0, 0.5, 0.5], [0.5, 0.0, 0.5], [0.5, 0.5, 0.0]],
            ... )
            >>> bcc = Prim(
            ...     structure=structure,
            ...     allowed_elements=[
            ...         ["Cr", "Mo", "Nb", "Ta", "V", "W"],
            ...         ["Va", "H"],
            ...         ["Va", "H"],
            ...         ["Va", "H"],
            ...     ],
            ... )
            >>> bcc.get_neighborhood(4.0)
            >>> print(bcc)

            >>> # Construct site-basis functions
            >>> basis = SiteBasis.build_sitebasis(
            ...     prim=bcc,
            ...     embedding_dimensions=np.array([3, 2, 2, 2]),
            ...     basis_type=["chebyshev", "occupational", "occupational", "occupational"],
            ... )
            >>> print(basis)
        """

        # Assignment of basis for each site
        basis_indexes = prim.get_prim_wyckoff_indexes()

        def assign_chemical_freedom(list_dims, number_elements):
            list_dims = np.array(list_dims, dtype=int)
            # No embedding/chemical compression
            list_dims[list_dims <= 0] = number_elements
            list_dims = np.where(
                list_dims < number_elements, list_dims, number_elements
            )
            return np.max(list_dims) - 1

        # Determination of the chemical freedom per Wyckoff group of equivalent sites
        chemical_freedom = []
        if len(embedding_dimensions.shape) == 0:
            # Scalar input
            embedding_dimensions = np.array([embedding_dimensions] * len(prim.basis))
        if len(embedding_dimensions) == 1:
            # List with one value as input
            embedding_dimensions = np.array([embedding_dimensions[0]] * len(prim.basis))
        if len(embedding_dimensions) == 0:
            # Assign default embedding dimension in case of empty array
            for elements in prim.wyckoff_sites["allowed_elements"]:
                singular = chemical_preconditioning(elements)[1]
                proportions = singular.cumsum() / singular.sum()
                dim = np.nonzero(proportions > 0.95)[0][0]
                chemical_freedom.append(min(dim, len(elements) - 1))
            warnings.warn(
                "Automatic determination of the embedding dimensions: %s\nThe singular values are: %s\nThe weights of each singular values are: %s"
                % (
                    np.array2string(np.array(chemical_freedom, dtype=int)),
                    np.array2string(singular),
                    np.array2string(proportions),
                )
            )
        else:
            assert len(embedding_dimensions) >= len(basis_indexes), (
                "The number of embedding dimensions (%d) is smaller than the number of atomic sites in prim (%d)."
                % (
                    len(embedding_dimensions),
                    len(basis_indexes),
                )
            )
            if len(embedding_dimensions) > len(basis_indexes):
                warnings.warn(
                    "The number of embedding dimensions (%d) is greater than the number of atomic sites in prim (%d). Only the first %d numbers are treated."
                    % (
                        len(embedding_dimensions),
                        len(basis_indexes),
                        len(basis_indexes),
                    )
                )
                embedding_dimensions = embedding_dimensions[: len(basis_indexes)]

            for wyckoff_index in np.unique(basis_indexes):
                dims = embedding_dimensions[basis_indexes == wyckoff_index]
                chemical_freedom.append(
                    assign_chemical_freedom(
                        dims,
                        len(prim.wyckoff_sites["allowed_elements"][wyckoff_index]),
                    )
                )
                if len(np.unique(dims)) > 1:
                    warnings.warn(
                        "A conflict arose in the embedding dimensions for the Wyckoff group index %d. The largest value %d (among the following embedding dimensions %s) is chosen."
                        % (
                            wyckoff_index,
                            chemical_freedom[-1],
                            np.array2string(dims),
                        )
                    )

        # Input species for each basis
        species_in = [
            torch.tensor(
                [np.nonzero(prim.elements == elem)[0][0] for elem in list_elements]
            ).int()
            for list_elements in prim.wyckoff_sites["allowed_elements"]
        ]
        # Unprojected basis functions
        if isinstance(basis_type, str):
            list_basis_type = [basis_type] * len(chemical_freedom)
            if len(prim.basis) > 1:
                warnings.warn(
                    "All sites are assigned to the same basis type (%s)." % basis_type
                )
        elif len(basis_type) == 1:
            list_basis_type = basis_type * len(chemical_freedom)
            if len(prim.basis) > 1:
                warnings.warn(
                    "All sites are assigned to the same basis type (%s)."
                    % basis_type[0]
                )
        else:
            if len(basis_type) != len(prim.basis):
                raise ValueError(
                    "The number of basis types (%d) is different from the number of sites in the primitive structure (%d)"
                    % (len(basis_type), len(prim.basis))
                )
            list_basis_type = []
            for wyckoff_index, site_indexes in enumerate(
                prim.wyckoff_sites["site_index"]
            ):
                list_basis_type.append(basis_type[site_indexes[0]])
                if np.any(
                    [basis_type[ind] != list_basis_type[-1] for ind in site_indexes]
                ):
                    raise ValueError(
                        "The unprojected site-basis type for asymmetric sites %d are different."
                        % wyckoff_index
                    )
        list_basis = [
            torch.tensor(compute_site_basis(b_type, len(elems)))
            for elems, b_type in zip(
                prim.wyckoff_sites["allowed_elements"], list_basis_type
            )
        ]
        # Assignment of basis for each site in neighborhood
        neighbor_basis = torch.tensor(basis_indexes[prim.neighborhood[:, -1]])

        return cls(
            species_in, torch.tensor(chemical_freedom), neighbor_basis, list_basis
        )

    def _get_string(self) -> str:
        """
        String representation of the :py:obj:`SiteBasis` object that provides an overview of
        the site-basis functions.

        Returns
        -------
        string
            Multi-line string representation of the :py:obj:`SiteBasis` object.
        """

        tabs = []

        # Dimension
        table = [
            [
                "\n".join(
                    [
                        "Wyckoff group index %d" % wyckoff_index
                        for wyckoff_index in range(len(self.list_dim_in))
                    ]
                ),
                "\n".join([": "] * len(self.list_dim_in)),
                tabulate(
                    [
                        [index for index in site_species]
                        for site_species in self.list_species_in()
                    ],
                    tablefmt="plain",
                ),
                "\n".join(["->"] * len(self.list_dim_in)),
                "\n".join(
                    ["%d embedding dimensions" % (dim + 1) for dim in self.list_dim_out]
                ),
            ]
        ]
        tabs.append(
            [
                tabulate(
                    table,
                    ["Embedding Dimensions:\n" + "-" * 21, "", "", "", ""],
                    tablefmt="plain",
                    colalign=("left", "center", "right", "center", "left"),
                )
            ]
        )

        # Site-basis Functions
        table = []
        with no_grad():
            basis = self()
            basis = basis.numpy(force=True)
        table.append(SEPARATING_LINE)
        table.append(["", ""] + basis[0].tolist())
        basis_index = 1
        for wyckoff_index in self.list_indexes:
            table.append(SEPARATING_LINE)
            for fct in range(self.list_dim_out[wyckoff_index]):
                table.append(
                    [
                        "Wyckoff group index %d" % wyckoff_index if fct == 0 else "",
                        ": " if fct == 0 else "",
                    ]
                    + basis[basis_index].tolist()
                )
                basis_index += 1
        tabs.append(
            [
                tabulate(
                    [
                        [
                            tabulate(
                                table,
                                ["Chemical indexes", ": "]
                                + list(range(self.N_species)),
                                tablefmt="plain",
                                colalign=["left", "center"] + ["right"] * len(basis[0]),
                                floatfmt=".4f",
                            )
                        ]
                    ],
                    ["Site-basis Functions:\n" + "-" * 21],
                    tablefmt="plain",
                )
            ]
        )

        txt = tabulate(
            tabs,
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = (
            "\n{s: ^{n}}\n".format(s="\033[1m SITE-BASIS \033[0m", n=width) + txt + "\n"
        )

        return txt

    def _get_string_representation(self) -> str:
        """
        String representation of the :py:obj:`SiteBasis` object that provides an overview of
        the site-basis functions.

        Returns
        -------
        txt: string
            Multi-line string representation of the :py:obj:`SiteBasis` object.
        """
        left_width = 18
        right_width = 30
        total_width = max(
            left_width + right_width + 3 * self.N_species,
            left_width + 8 * self.N_species,
        )

        # General information
        txt = []
        txt += ["{s:=^{n}}".format(s=" SITE BASIS ", n=total_width)]
        for site_index, species_in, dim_out in zip(
            range(len(self.list_dim_in)), self.list_species_in(), self.list_dim_out
        ):
            s = " {:<{n}} :".format("Sublattice %d" % site_index, n=left_width - 2)
            s += "{:>{n}} -".format(
                "[" + " ".join(species_in.numpy(force=True).astype(str)) + "]",
                n=total_width - left_width - right_width - 2,
            )
            s += "> {:<{n}}".format(
                "%d embedding dimension%s"
                % (int(dim_out) + 1, "s" if dim_out > 0 else ""),
                n=right_width - 2,
            )
            txt += [s]
        txt += ["-" * total_width]

        # Site-basis functions
        txt += [" Site-basis functions"] + [""]
        with no_grad():
            basis = self()
            basis = basis.numpy(force=True)
        add_line_indexes = [2] + (
            self.list_dim_out.numpy(force=True).cumsum() + 2
        ).tolist()[:-1]
        for ind, array in enumerate(
            np.array2string(
                np.vstack([np.arange(self.N_species).astype(float), basis]),
                precision=3,
                suppress_small=True,
                floatmode="fixed",
                sign=" ",
                max_line_width=10000,
                threshold=10000,
            )[:-1].split("\n")
        ):
            line = array.replace("[", " ").replace("]", " ")[2:]
            if ind == 0:
                txt += [
                    " {:{n}} : ".format("Chemical indexes", n=left_width - 2)
                    + "    "
                    + line.replace(".000", "    ")
                ]
                txt += [""]
            elif ind in add_line_indexes:
                txt += [" " * (left_width + 2) + "-" * (len(line) - 1)]
                txt += [
                    " {:{n}} : ".format(
                        "Sublattice %d" % (add_line_indexes.index(ind)),
                        n=left_width - 2,
                    )
                    + line
                ]
            else:
                txt += [" " * (left_width + 2) + line]

        txt += [""]
        txt += ["=" * total_width]
        return "\n".join(txt)

    def __str__(self) -> str:
        """String representation."""
        return "\n" + self._get_string() + "\n"


def occupational_basis(N: int, background: int = 0) -> np.ndarray:
    """
    Contructs a complete set of site-basis functions based on occupational variables

    Parameters
    ----------
    N: int
        Dimension of the basis
    background: int, default: 0
        Specie index of the background specie whose sitebasis function is a vector of 0.

    Returns
    -------
    np.ndarray
        NxN Numpy array

    Examples
    --------
    The following illustrates the occupational matrix of size 3::

        >>> from pyece.core.sitebasis import occupational_basis

        >>> occupational_basis(3)
        np.array([[1., 1., 1.]
                  [0., 1., 0.]
                  [0., 0., 1.]])
    """
    return np.vstack(
        [
            np.ones((1, N)),
            np.eye(N, N)[
                np.arange(N) != (background if (background >= 0) else (N + background))
            ],
        ]
    )


def chebyshev_basis(N: int) -> np.ndarray:
    """
    Contructs a complete set of site-basis functions built as an orthogonal discrete Chebyshev basis of first kind

    Parameters
    ----------
    N: int
        Dimension of the basis

    Returns
    -------
    np.ndarray
        NxN Numpy array with orthonormal rows, normalized to sqrt(N)

    Examples
    --------
    The following illustrates the Chebyshev matrix of size 3::

        >>> from pyece.core.sitebasis import chebyshev_basis

        >>> chebyshev_basis(3)
        np.array([[ 1.00000000,  1.00000000,  1.00000000]
                  [-1.22474487,  0.00000000,  1.22474487]
                  [ 0.70710678, -1.41421356,  0.70710678]])
    """
    x = np.polynomial.chebyshev.chebpts1(N)
    basis = np.polynomial.chebyshev.chebval(x, np.diag(np.ones(N)))
    normalization = np.ones(N) * np.sqrt(2)
    normalization[0] = 1
    return basis * np.repeat(normalization.reshape(-1, 1), N, axis=1)


def compute_site_basis(
    basis_type: Literal["chebyshev", "occupational"], N: int
) -> np.ndarray:
    """
    Contructs a complete set of site-basis functions

    Parameters
    ----------
    basis_type: str
        Type of site basis (\'chebyshev\' or \'occupational\')
    N: int
        Dimension of the basis

    Returns
    -------
    basis_matrix: np.ndarray
        NxN Numpy array
    """
    if basis_type == "chebyshev":
        basis_matrix = np.around(chebyshev_basis(N), decimals=12)
    elif basis_type == "occupational":
        basis_matrix = occupational_basis(N)
    else:
        raise (
            ValueError(
                "So far basis needs to be initialized between 'chebyshev' and 'occupational', you can modify it manually once the class is initialized."
            )
        )
    return basis_matrix


def chemical_preconditioning(elements: list[str]) -> tuple[np.ndarray, np.ndarray]:
    """
    Computes a set of preconditioned site-basis functions based on chemical properties

    Parameters
    ----------
    elements: list[str]
        List if chemical species

    Returns
    -------
    v: np.ndarray
        Numpy array of the chemically-preconditioned site-basis functions
    s: np.ndarray
        Numpy array of the singular values
    """
    from pymatgen.core import Element
    from sklearn.preprocessing import StandardScaler

    properties_list = []
    for i, elem in enumerate(elements):
        try:
            element = Element(elem)
            properties_list.append(
                [
                    element.Z,
                    element.atomic_radius_calculated,
                    element.X,
                    element.density_of_solid,
                    element.melting_point,
                    element.bulk_modulus if element != Element("Zr") else 94.0,
                    element.youngs_modulus,
                    element.brinell_hardness,
                ]
            )
        except ValueError:
            warnings.warn(
                f"Element {elem} not found in the database. Adding zeros to the properties matrix."
            )
            properties_list.append([0, 0, 0, 0, 0, 0, 0, 0])
    properties_matrix = np.array(properties_list)
    scaler = StandardScaler().fit(properties_matrix)
    scaled_properties_matrix = np.array(scaler.transform(properties_matrix)).T
    u, s, v = np.linalg.svd(scaled_properties_matrix)
    return v, s
