from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from monty.json import MSONable
from numpy.typing import NDArray
from pymatgen.core import Structure
from torch import Tensor
from torch.utils.data import DataLoader, Dataset

from pyece.core.clex import eCE
from pyece.core.configurations import ClexInput, Config
from pyece.utils.mapping import check_mapping, ideal_map


class ConfigData(MSONable):
    """
    Configuration data to be used in cluster expansion.
    Contains the configuration, the property associated to the configuration and the path to the data file.

    Attributes
    ----------
    config: Config
        Config object containing the computational information of the atomic configuration.
    prop: float
        Property associated to the configuration for learning.
    weight: float
        Weight of the configuration in the dataset to be used for training.
    metadata: dict
        Dictionary with metadata
    """

    def __init__(
        self,
        configuration: Config,
        config_property: float,
        weight: float = 1.0,
        metadata: dict = {},
    ) -> None:
        """
        Configuration data to be used in cluster expansion

        Parameters
        ----------
        configuration: Config
            Config object containing the computational information of the atomic configuration
        config_property: float
            Property associated to the configuration for learning.
        weight: float = 1.0
            Weight of the configuration in the dataset
        metadata: dict, default: {}
            Dictionary with metadata
        """

        self.config: Config = configuration
        self.prop: float = config_property
        self.weight: float = weight
        self.metadata: dict = metadata

        return

    def __len__(self) -> int:
        return len(self.config)

    def __str__(self) -> str:
        return (
            str(self.config.get_structure())
            + "\nProperty: "
            + str(self.prop)
            + "\nPath: "
            + str(self.metadata)
        )

    def as_dict(self) -> dict:
        """
        MSONable dictionary of the ClexData class.
        """

        dct = {
            "@module": type(self).__module__,
            "@class": type(self).__name__,
            "config": self.config.as_dict(),
            "property": self.prop,
            "weight": self.weight,
            "metadata": self.metadata,
        }

        return dct

    @classmethod
    def from_dict(cls, dct):
        """
        Create the ClexData class from a MSONable dictionary.
        """

        configuration = Config.from_dict(dct["config"])
        config_property = dct["property"]
        weight = dct.get("weight", 1.0)
        metadata = dct["metadata"]
        return cls(
            configuration,
            config_property,
            weight,
            metadata,
        )


class ClexDataset(MSONable, Dataset):
    """
    Dataset object containing the features and labels for the cluster expansion learning process.

    Parameters
    ----------
    features: ClexInput
        ClexInput object with all the features used as input in the cluster expansion model
    labels: Tensor
        Pytorch tensor with all the labels
    weight: Tensor
        Pytorch tensor with all the weights to associate with the data.
    device: str, default: \'cpu\'
        Device to be used for pytorch operations

    Attributes
    ----------
    X: ClexInput
        ClexInput object with all the features used as input in the cluster expansion model
    y: Tensor
        Pytorch tensor with all the labels
    w: Tensor
        Pytorch tensor with all the weights
    device: str, default: \'cpu\'
        Device to be used for pytorch operations
    """

    def __init__(
        self,
        features: ClexInput,
        labels: Tensor,
        weights: Tensor,
        device: str = "cpu",
    ) -> None:
        self.X = features
        self.y = labels
        self.w = weights
        self.device = device
        self.weights = weights
        return

    def __getitem__(self, index):
        return self.X[index], self.y[index], self.w[index]

    def __len__(self):
        return len(self.y)

    def to(self, device: str = "cpu"):
        """
        Set the device for pytorch calculations (cpu or cuda)

        Parameters
        ----------
        device: str, default: \'cpu\'
            Device to be used for pytorch operations
        """
        self.X = self.X.to(device)
        self.y = self.y.to(device)
        self.w = self.w.to(device)
        self.device = device
        return self

    @classmethod
    def build_dataset(
        cls,
        list_data: list[ConfigData],
        device: str = "cpu",
    ):
        """
        Construct a ClexDataset object from a list of ConfigData

        Parameters
        ----------
        list_data: list[ConfigData]
            List containing all ConfigData object to be used to train the cluster expansion model
        device: str, default: \'cpu\'
            Device to be used for pytorch operations

        Returns
        -------
        dataset: ClexDataset
            ClexDataset object
        """
        clex_input = ClexInput.from_list_configs(
            [data.config for data in list_data], device
        )
        list_properties = torch.tensor(
            [data.prop for data in list_data], device=device
        ).float()
        weights = torch.tensor(
            [data.weight for data in list_data], device=device
        ).float()
        return cls(clex_input, list_properties, weights, device=device)

    def build_dataloader(
        self, batch_size: int = 50, shuffle: bool = True
    ) -> DataLoader:
        """
        Construct a Pytorch DataLoader object.
        Parameters
        ----------
        batch_size: int, default: 50
            Number of samples per batch to load.
        shuffle: bool, default: True
            Set to True to have the data reshuffled at every epoch.
        Returns
        -------
        dataset: ClexDataset
            ClexDataset object
        """
        return DataLoader(self, batch_size=batch_size, shuffle=shuffle)


class DataBase(pd.DataFrame):
    """
    `Pandas DataFrame <https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html>`_ containing information related to some configurations. It must contain at least the following columns:

    * The composition (columns as \'x_SPECIES\' with SPECIES being the name of the species): it corresponds to a float value
    * The value of the associated property (column as \'property\'): it corresponds to a float value of the property to cluster expand.
    * The structure (column as \'structure\'): it corresponds to a string of the `VASP POSCAR <https://www.vasp.at/wiki/index.php/POSCAR>`_ of the ideal structure, i.e., mapped to the ideal lattice.
    * (Optional) The value of the associated weight (column as \'weight\'): it corresponds to a float value of the weight of the data during training, a value of 1 is automatically set if the column is missing.
    * (Optional) The dictionary of the :py:obj:`ConfigData` object (column as \'ConfigData\'): it corresponds to a dictionary object
    * Other columns might be added but their names must be distinct from the column names above.

    Parameters
    ----------
    *args
        Arguments as in `Pandas DataFrame <https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html>`_
    **kwargs
        Arguments as in `Pandas DataFrame <https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html>`_
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        comp_cols = ["x_" in col for col in self.columns]
        if np.sum(comp_cols) < 1:
            raise ValueError(
                "The DataBase object requires the presence of columns named 'x_SPECIES' with SPECIES being the name of the species, corresponding to the composition."
            )
        if "property" not in self.columns:
            raise ValueError(
                "The DataBase object requires the presence of a column named 'property' corresponding to the property to cluster expand."
            )
        if "structure" not in self.columns:
            raise ValueError(
                "The DataBase object requires the presence of a column named 'structure' corresponding to the POSCAR string of the ideal structure."
            )
        if "weight" not in self.columns:
            self.insert(loc=len(self.columns), column="weight", value=1.0)
        return

    def to_ClexDataset(self, model: eCE | None = None) -> ClexDataset:
        """Creates a :py:obj:`~.pyece.learn.data.ClexDataset` object out of the database.
        If the database does not contain a column named \'ConfigData\' that contains the dictionaries of :py:obj:`~.pyece.learn.data.ConfigData` objects, then these objects need to be constructed and the model needs to be provided.

        Parameters
        ----------
        model: eCE | None, default: None
            eCE object of the embedded cluster expansion model

        Returns
        -------
        ClexDataset
        """
        if "ConfigData" in self.columns:
            list_configdata = [
                ConfigData.from_dict(data) for data in self["ConfigData"]
            ]
        else:
            if model is None:
                raise ValueError(
                    "If the database does not contain a column named 'ConfigData', the model argument must be provided to construct the ConfigData objects."
                )
            list_configdata = []
            for index in range(len(self)):
                structure = Structure.from_str(
                    self.iloc[index]["structure"], fmt="poscar"
                )
                config = Config.from_structure(
                    structure,
                    model.prim,
                    list_try_maps=[ideal_map],
                    list_checks=[
                        lambda struc, map_s, deform, disp: check_mapping(
                            structure=struc,
                            mapped_structure=map_s,
                            deformation=deform,
                            displacements=disp,
                            vac_concentration_max=1,
                        )
                    ],
                )
                prop = self.iloc[index]["property"]
                weight = self.iloc[index]["weight"]
                list_configdata.append(
                    ConfigData(
                        config,
                        prop,
                        weight,
                        {
                            "supercell_size": len(config),
                            "index": index,
                        },
                    )
                )
        return ClexDataset.build_dataset(list_configdata)

    @classmethod
    def from_pickle(cls, path):
        """
        Load the database from a pickle dataframe format

        Parameters
        ----------
        path: str
            Location to load the database from
        """
        return cls(pd.read_pickle(path))

    @classmethod
    def from_json(cls, path):
        """
        Load the database from a JSON-dictionary dataframe format

        Parameters
        ----------
        path: str
            Location to load the database from
        """
        return cls(pd.read_json(path))

    @classmethod
    def from_csv(cls, path):
        """
        Load the database from a CSV dataframe format

        Parameters
        ----------
        path: str
            Location to load the database from
        """
        return cls(
            pd.read_csv(
                path,
                sep=None,
                header=None,
                skip_blank_lines=True,
                skipinitialspace=True,
                engine="python",
            )
        )

    @classmethod
    def from_file(cls, path):
        """
        Load the database from a file dataframe. Supports .pkl, .json, .csv and .txt formats.

        Parameters
        ----------
        path: str
            Location to load the database from
        """
        if path.endswith(".pkl"):
            database = DataBase.from_pickle(path)
        elif path.endswith(".json"):
            database = DataBase.from_json(path)
        elif path.endswith(".csv"):
            database = DataBase.from_csv(path)
        elif path.endswith(".txt"):
            database = DataBase.from_csv(path)
        else:
            raise ValueError("Unsupported dataset file format: %s" % path)
        return database

    def summary(self) -> pd.DataFrame:
        """
        Returns a DataFrame that summarizes the content of the DataBase

        Returns
        -------
        pd.DataFrame
        """
        labels = [label for label in self.columns if "x_" in label] + [
            "scel_size",
            "property",
            "weight",
        ]
        if "mapping_cost" in self.columns:
            labels.append("mapping_cost")
        return self[labels]


def random_split_data(
    proportions: np.ndarray,
    N_data: int,
    list_indexes_in: list | None = None,
) -> list[NDArray[np.int_]]:
    """Randomly splits the total dataset into disjoint datasets satisfying some proportions.

    Parameters
    ----------
    proportions: np.ndarray
        Non-negative numpy array with the proportions of data included in each datasets.
    N_data: int
        Number of total data available.
    list_indexes_in: list | None, default: None
        List of integer numpy array with data indexes to include in each dataset (the number of arrays must match the number of proportions)

    Returns
    -------
    list_indexes: list[np.ndarray[Any,int]]
        List of integer numpy arrays with the data indexes to form random disjoint datasets.
    """

    # Index mask
    mask = np.ones(N_data, dtype=bool)

    # Remaining data
    if list_indexes_in is None:
        list_indexes_in = [[] for _ in range(len(proportions))]
    N_available = N_data - len(np.unique(np.hstack(list_indexes_in)))

    # Index mask
    mask = np.ones(N_data, dtype=bool)
    for indexes_in in list_indexes_in:
        mask[indexes_in] = False

    # Size of datasets
    N_splits = np.rint(proportions / proportions.sum() * N_available).astype(int)
    N_splits[-1] += N_available - N_splits.sum()

    # dataset splitting
    list_indexes = []
    for indexes_in, size in zip(list_indexes_in, N_splits):
        indexes_in[indexes_in < 0] += N_data
        indexes_in = np.unique(indexes_in).astype(int)
        indexes = np.random.choice(np.nonzero(mask)[0], size=size, replace=False)
        mask[indexes] = False
        list_indexes.append(np.hstack([indexes_in, indexes]))
    return list_indexes
