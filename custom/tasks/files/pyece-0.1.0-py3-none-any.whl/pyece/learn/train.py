from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict
from warnings import warn

import numpy as np
import torch
from numpy.typing import NDArray
from torch import nn, no_grad, optim
from torch.utils.data import DataLoader

from pyece.core.clex import eCE


class EarlyStopping:
    """
    Early stops the training if validation loss doesn't improve after a given patience.

    Attributes
    ----------
    patience: int
        How long to wait after last time validation loss improved.
    verbose: bool
        If True, prints a message for each validation loss improvement.
    counter: int
        Counter with the number of epochs since the last improvement.
    best_score: float
        The best validation score achieved so far.
    early_stop: bool
        Boolean value to stop the training.
    val_loss_min: float
        Minimum value of the validation loss.
    delta: float
        Minimum change in the monitored quantity to qualify as an improvement.
    best_state_dict: dict
        State dictionary of the model with the best validation loss.
    """

    def __init__(self, patience: int = 7, verbose: bool = False, delta: float = 0):
        """
        Parameters
        ----------
        patience: int
            How long to wait after last time validation loss improved. (default: 7)
        verbose: bool
            If True, prints a message for each validation loss improvement. (default: False)
        delta: float
            Minimum change in the monitored quantity to qualify as an improvement. (default: 0)
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.early_stop = False
        self.val_loss_min = np.inf
        self.delta = delta
        self.best_state_dict: Dict[str, Any]

    def __call__(self, val_loss: float, model: nn.Module) -> None:
        if val_loss < self.val_loss_min - self.delta:
            if self.verbose:
                print(
                    f"Validation loss decreased ({self.val_loss_min:.8f} --> {val_loss:.8f}).  Saving model ..."
                )
            self.val_loss_min = val_loss
            self.save_checkpoint(model)
            self.counter = 0
        else:
            self.counter += 1
            if self.verbose:
                print(f"EarlyStopping counter: {self.counter} out of {self.patience}")
            if self.counter >= self.patience:
                self.early_stop = True

    def save_checkpoint(self, model: nn.Module) -> None:
        """Saves model when validation loss decrease."""
        self.best_state_dict = deepcopy(model.state_dict())

    def load_best_state_dict(self, model: nn.Module) -> None:
        """Load best model state dictionary"""
        model.load_state_dict(self.best_state_dict)


def train(
    dataloader: DataLoader,
    model: eCE,
    loss_fct: nn.Module,
    optimizer: optim.Optimizer,
    scheduler: optim.lr_scheduler.LRScheduler,
    device: str = "cpu,",
) -> float:
    """
    Performs one training step given a dataset.

    Parameters
    ----------
    dataloader: DataLoader
        Pytorch dataloader object containing the features and labels to train on
    model: nn.Module
        Pytorch Module object of the model to train
    loss_fct: nn.Module
        Pytorch Module object of the loss function to be minimized
    optimizer: optim.Optimizer
        Pytorch Optimizer object with the optimization algorithm to use
    scheduler: optim.lr_scheduler
        Pytorch learning rate scheduler object
    device: str
        Device to be used for pytorch operations

    Returns
    -------
    float
        Value of the loss function evaluated for the last batch
    """
    model.train()
    model.to(device)

    if dataloader.batch_sampler is None:
        raise ValueError("Dataloader must have a batch size defined for training.")

    for indexes in dataloader.batch_sampler:
        X, y, w = dataloader.dataset[indexes]
        X, y, w = X.to(device), y.to(device), w.to(device)

        def closure() -> float:
            optimizer.zero_grad()
            y_pred = model(X.neighborhood_occupations, X.segment_indexes)
            normalized_weights = len(y) * w / torch.sum(w)
            if isinstance(loss_fct, nn.L1Loss):
                loss = loss_fct(normalized_weights * y_pred, normalized_weights * y)
            elif isinstance(loss_fct, nn.MSELoss):
                normalized_weights = torch.sqrt(normalized_weights)
                loss = loss_fct(normalized_weights * y_pred, normalized_weights * y)
            else:
                warn(
                    "You are using a loss function that is not L1Loss or MSELoss. The weights will not be used."
                )
                loss = loss_fct(y_pred, y)
            loss.backward()
            return loss.item()

        loss = optimizer.step(closure)
    scheduler.step()
    model.normalize()
    return loss


def test(
    dataloader: DataLoader, model: nn.Module, loss_fct: nn.Module, device: str = "cpu"
) -> float:
    """
    Evaluates the loss function for a given dataset.

    Parameters
    ----------
    dataloader: DataLoader
        Pytorch dataloader object containing the features and labels to test on
    model: eCE
        Pytorch Module object of the model to train
    loss_fct: nn.Module
        Pytorch Module object of the loss function to be used for testing. Note that weights are not used for testing.
    device: str
        Device to be used for pytorch operations

    Returns
    -------
    float
        Value of the averaged loss function
    """
    model.eval()
    model.to(device)
    test_loss = 0.0

    if dataloader.batch_sampler is None:
        raise ValueError("Dataloader must have a batch size defined for testing.")

    with no_grad():
        for indexes in dataloader.batch_sampler:
            X, y, _ = dataloader.dataset[indexes]
            X, y = X.to(device), y.to(device)
            pred = model(X.neighborhood_occupations, X.segment_indexes)
            test_loss += loss_fct(pred, y).item() * len(indexes)
    test_loss /= float(len(dataloader.dataset))
    return test_loss


def optimize(
    train_dataloader: DataLoader,
    model: nn.Module,
    loss_fct: nn.Module,
    optimizer: optim.Optimizer,
    scheduler: optim.lr_scheduler.LRScheduler,
    n_epochs: int,
    device: str = "cpu",
    verbose: bool = True,
    valid_dataloader: DataLoader | None = None,
    early_stopping: EarlyStopping | None = None,
) -> list[np.ndarray]:
    """
    Optimization function.

    Parameters
    ----------
    train_dataloader: DataLoader
        Pytorch dataloader object containing the features and labels to train on
    model: nn.Module
        Pytorch Module object of the model to train
    loss_fct: nn.Module
        Pytorch Module object of the loss function to be minimized
    optimizer: optim.Optimizer
        Pytorch Optimizer object with the optimization algorithm to use
    scheduler: optim.lr_scheduler
        Pytorch learning rate scheduler object
    n_epochs: int
        Number of optimization epochs to be performed
    device: str
        Device to be used for pytorch operations
    verbose: bool = True
        Set to True for printing the test loss at each epochs
    valid_dataloader: DataLoader, optional
        Pytorch dataloader object containing the validation set for early stopping. If None, early stopping is not performed.
    early_stopping: EarlyStopping, optional
        EarlyStopping object for early stopping. valid_dataloader must be provided if early_stopping is not None.

    Returns
    -------
    list[np.ndarray]
        list of numpy arrays corresponding to the training loss and the validation loss
    """
    loss_train = []
    loss_valid = []

    # Initiate
    if verbose:
        print("\nEpoch 0")
        print(
            "Learning rate   %s"
            % "   ".join(["%.2e" % param["lr"] for param in optimizer.param_groups])
        )
    model.to(device)
    loss_train.append(test(train_dataloader, model, loss_fct, device=device))
    if valid_dataloader is not None and early_stopping is not None:
        valid_loss = test(valid_dataloader, model, loss_fct, device=device)
        loss_valid.append(valid_loss)
        early_stopping(valid_loss, model)
    if verbose:
        print(f"Train Error: {loss_train[-1]:.8f}")
        if valid_dataloader is not None:
            print(f"Valid Error: {loss_valid[-1]:.8f}")

    # Train
    for epoch in range(n_epochs):
        if verbose:
            print(f"\nEpoch {epoch + 1}")
            print(
                "Learning rate   %s"
                % "   ".join(["%.2e" % param["lr"] for param in optimizer.param_groups])
            )
        loss_train.append(
            train(
                train_dataloader,
                model,
                loss_fct,
                optimizer,
                scheduler,
                device=device,
            )
        )
        loss_train.append(test(train_dataloader, model, loss_fct, device=device))
        if valid_dataloader is not None:
            valid_loss = test(valid_dataloader, model, loss_fct, device=device)
            loss_valid.append(valid_loss)
            if early_stopping is not None:
                early_stopping(valid_loss, model)
                if early_stopping.early_stop and verbose:
                    print("Early stopping")
                    break
        if verbose:
            print(f"Train Error: {loss_train[-1]:.8f}")
            if valid_dataloader is not None:
                print(f"Valid Error: {loss_valid[-1]:.8f}")

    if valid_dataloader is not None and early_stopping is not None:
        early_stopping.load_best_state_dict(model)
        loss_train.append(test(train_dataloader, model, loss_fct, device=device))
        loss_valid.append(early_stopping.val_loss_min)
    return [np.array(loss_train), np.array(loss_valid)]


def ladder_optimize(
    train_dataloader: DataLoader,
    model: eCE,
    loss_fct: nn.Module,
    list_optimizers: list[optim.Optimizer],
    list_schedulers: list[optim.lr_scheduler.LRScheduler],
    list_n_epochs: list[int],
    ladder_step_orbit_assignment: NDArray[np.int_],
    test_dataloader: DataLoader | list[DataLoader] | None = None,
    test_loss_fct: nn.Module | None = None,
    valid_dataloader: DataLoader | None = None,
    list_early_stopping: list[EarlyStopping] | None = None,
    device: str = "cpu",
    verbose: bool = True,
) -> list[dict]:
    """
    Optimization function.

    Parameters
    ----------
    train_dataloader: DataLoader
        Pytorch dataloader object containing the features and labels to train on
    model: nn.Module
        Pytorch Module object of the model to train
    loss_fct: nn.Module
        Pytorch Module object of the loss function to be minimized
    list_optimizers: list[optim.Optimizer]
        List of pytorch Optimizer objects with the optimization algorithm to use for each ladder step
    list_schedulers: list[optim.lr_scheduler]
        List of pytorch learning rate scheduler objects for each ladder step
    list_n_epochs: list[int]
        List of numbers of optimization epochs to be performed
    ladder_step_orbit_assignment: np.ndarray[int]
        Integer numpy array with the assignment (compact format) of each orbit as found in pyece.core.features.Features.orbit_tracker that are added in each ladder step
    test_dataloader: DataLoader or list[DataLoader], optional
        Pytorch dataloader object(s) which containing the features and labels to test on after each ladder step
    test_loss_function: nn.Module, optional
        Pytorch Module object of the loss function to use on the test set. If None is provided, the default is the same loss function as the train loss function.
    valid_dataloader: DataLoader, optional
        Pytorch dataloader object containing the validation set for early stopping. If None, early stopping is not performed.
    list_early_stopping: list[EarlyStopping], optional
        List of EarlyStopping objects for each ladder step. valid_dataloader must be provided if list_early_stopping is not None.
    device: str
        Device to be used for pytorch operations. (default: "cpu")
    verbose: bool
        Set to True for printing the test error at each epochs. (default: True)

    Returns
    -------
    list[dict]
        list of dictionaries which contain the losses of the training, validation and test losses at each ladder step.
        The dictionary keys are "train", "validation" and "test".
    """

    orbit_tracker = model.features.orbit_tracker()
    symmetrization_factors = deepcopy(model.features.symmetrization_factors)
    model.features.symmetrization_factors *= 0.0

    cluster_function_indexes = []
    list_losses = []
    start = 0
    for ladder_step, __ in enumerate(ladder_step_orbit_assignment):
        end = ladder_step_orbit_assignment[ladder_step]
        if verbose:
            print(
                "\nEntering ladder training step %d\n-------------------------------\nIncluded orbits:\n   - %s"
                % (
                    ladder_step,
                    "\n   - ".join(
                        list(orbit_tracker.keys())[index] for index in range(end)
                    ),
                )
            )

        # Select cluster functions to be included in the fit
        for index in range(start, end):
            cluster_function_indexes += orbit_tracker[list(orbit_tracker.keys())[index]]
        assert np.allclose(
            cluster_function_indexes, np.arange(len(cluster_function_indexes))
        ), "Assignment does not correspond to successive cluster functions."
        size = len(cluster_function_indexes)
        model.features.symmetrization_factors[:size] = symmetrization_factors[:size]

        # Parameterization
        loss_train, loss_valid = optimize(
            train_dataloader,
            model,
            loss_fct,
            list_optimizers[ladder_step],
            list_schedulers[ladder_step],
            list_n_epochs[ladder_step],
            device,
            verbose,
            valid_dataloader,
            (
                list_early_stopping[ladder_step]
                if list_early_stopping is not None
                else None
            ),
        )
        losses = {
            "train": loss_train[-1],
            "validation": loss_valid[-1] if len(loss_valid) > 0 else None,
        }
        test_losses = []
        if test_dataloader is not None:
            if test_loss_fct is None:
                test_loss_fct = loss_fct
            if isinstance(test_dataloader, DataLoader):
                test_dataloader = [test_dataloader]
            for dataloader in test_dataloader:
                test_losses.append(
                    test(dataloader, model, test_loss_fct, device=device)
                )
            losses["test"] = test_losses if len(test_losses) > 1 else test_losses[0]
        list_losses.append(losses)
        start = ladder_step_orbit_assignment[ladder_step]

    return list_losses
