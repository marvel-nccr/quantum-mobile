r"""
This module is meant to contain objects used to sample configurations :math:`\sigma` according to the probability distribution:

.. math::

    \mathbb{P}(\sigma) = \frac{1}{Z} \exp\big(-\beta \Omega(\sigma) \big) \quad \text{with} \quad Z = \sum_{\sigma} \exp\big(-\beta \Omega(\sigma) \big)

where :math:`\Omega(\sigma)` is the microscopic potential energy defining the thermodynamic ensemble, using Monte Carlo (MC) simulation techniques
"""

from __future__ import annotations

from typing import Callable

import numpy as np
import torch
from numpy.typing import NDArray
from tabulate import tabulate
from torch import (
    Tensor,
    no_grad,
)  # compile,from_numpy,set_float32_matmul_precision

from pyece.core.clex import eCE
from pyece.core.configurations import Config

torch.set_float32_matmul_precision("high")


class MCEnsemble:
    r"""
    Monte Carlo Ensemble object to perform MCMC simulations.

    The class is meant to sample configurations :math:`\sigma` according to the probability distribution:

    .. math::

        \mathbb{P}(\sigma) = \frac{1}{Z} \exp\big(-\beta \Omega(\sigma) \big) \quad \text{with} \quad Z = \sum_{\sigma} \exp\big(-\beta \Omega(\sigma) \big)

    where :math:`\Omega(\sigma)` is the microscopic potential energy defining the thermodynamic ensemble.

    Parameters
    ----------
    model: eCE
        eCE object of the embedded cluster expansion model
    config: Config
        Config object of the input structure and occupations for the Monte Carlo simulation. The composition is read from this input configuration.
    temperature: float, default: 1000
        Float value of the temperature
    frozen_wyckoff_sites: list[bool] | None, default: None
        List of boolean variables where the ith variable indicates whether all sites in the ith Wyckoff group of equivalent sites are to be considered as frozen, i.e., the chemical species cannot be changed.
        The default is None, which sets all boolean variables to False (not frozen).
    device: str = 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\')
    """

    kB = 8.617333262e-5  # eV/K

    def __init__(
        self,
        model: eCE,
        config: Config,
        temperature: float = 1000.0,
        frozen_wyckoff_sites: list[bool] | None = None,
        device: str = "cpu",
    ):
        model.to(device)
        model.prod()
        config.to(device)

        # SETTINGS
        # --------
        self.element_dictionary: dict = model.prim.get_element_dict()
        self.rng: np.random.Generator = np.random.default_rng()
        self.device: str = device

        # MC CONSTANTS
        # ------------
        self.wyckoff_dict: dict = model.prim.wyckoff_sites
        self.frozen_wyckoff_sites: NDArray[np.bool_] = (
            np.array(frozen_wyckoff_sites, dtype=bool)
            if frozen_wyckoff_sites is not None
            else np.zeros(len(model.prim.wyckoff_sites["site_index"]), dtype=bool)
        )
        self.unitcell_indexes: NDArray[np.int_] = config.get_unitcell_index_per_sites()
        self.N_species: int = len(model.prim.elements)
        self.wyckoff_site: NDArray[np.int_] = config.get_wyckoff_indexes(
            model.prim
        ).numpy(force=True)
        self.list_species_in: list[NDArray[np.int_]] = [
            species.numpy(force=True).astype(int)
            for species in model.sitebasis.list_species_in()
        ]
        self.neighboring_primcells: NDArray[np.int_] = (
            config.compute_primcells_in_neighborhoods(model.prim, False)
            .numpy(force=True)
            .astype(int)
        )
        if len(self.frozen_wyckoff_sites) != len(
            model.prim.wyckoff_sites["site_index"]
        ):
            raise ValueError(
                "%s\nThe length of the frozen Wyckoff sites in input (%d) is not equal to the number of Wyckoff groups in Prim (%d)"
                % (
                    str(model.prim),
                    len(self.frozen_wyckoff_sites),
                    len(model.prim.wyckoff_sites["site_index"]),
                )
            )
        self.variable_sites: NDArray[np.int_] = self.get_variable_sites(config=config)
        self.N_sites: int = len(
            self.variable_sites
        )  # config.N_variable_sites len(config.occupation)

        # MC VARIABLES
        # ------------
        self.occupation: NDArray[np.int_] = config.occupation.numpy(force=True).astype(
            int
        )
        self.primcell_energies: np.ndarray = model(
            config.get_neighborhood_occupations()
        ).numpy(force=True)
        self.set_temperature(temperature)
        self.set_composition()

        # EFFECTIVE HAMILTONIAN
        # ---------------------

        # try:

        #     @no_grad()
        #     @compile(fullgraph=True, mode="reduce-overhead")
        #     def effective_hamiltonian(
        #         occupation: Tensor, site_indexes: Tensor
        #     ) -> Tensor:
        #         return model(occupation[config.neighborhood_per_primcell[site_indexes]])

        # except:
        #     warn("Not able to compile the hamiltonian. Expect slow performances.")

        #     def effective_hamiltonian(
        #         occupation: Tensor, site_indexes: Tensor
        #     ) -> Tensor:
        #         return model(occupation[config.neighborhood_per_primcell[site_indexes]])

        # finally:
        #     self.effective_hamiltonian: Callable = (
        #         lambda occupation, site_indexes: effective_hamiltonian(
        #             from_numpy(occupation).to(self.device),
        #             from_numpy(site_indexes).to(self.device),
        #         ).numpy(force=True)
        #     )

        @no_grad()
        @torch.compile(fullgraph=True, mode="reduce-overhead")
        def effective_hamiltonian(occupation: Tensor, site_indexes: Tensor) -> Tensor:
            return model(occupation[config.neighborhood_per_primcell[site_indexes]])

        self.effective_hamiltonian: Callable = (
            lambda occupation, site_indexes: effective_hamiltonian(
                torch.from_numpy(occupation).to(self.device),
                torch.from_numpy(site_indexes).to(self.device),
            ).numpy(force=True)
        )

        # @no_grad()
        # @compile(fullgraph=True, mode="reduce-overhead")
        # def effective_hamiltonian_fn(occupation, site_indexes) -> np.ndarray:
        #     return model(
        #         from_numpy(occupation)[
        #             config.neighborhood_per_primcell[from_numpy(site_indexes)]
        #         ]
        #     ).numpy()

        # def effective_hamiltonian(occupation, site_indexes):
        #     with dvc(device):
        #         return effective_hamiltonian_fn(occupation, site_indexes)

        # self.effective_hamiltonian: Callable = effective_hamiltonian

        # MC DATA
        # -------
        self.fixed_variables: list[str] = [
            "temperature",
            "beta",
            "composition",
        ]
        self.fluctating_variables: list[str] = ["E"]
        self.initialize_data()
        return

    def __call__(
        self, N_samples: int, sampling_frequency: int | None = None, N_changes: int = 1
    ) -> None:
        """
        Runs the MC simulation

        Parameters
        ----------
        N_samples: int
            Number of samples to compute
        sampling_frequency: int | None, default: None
            Frequency to which samples should be read. If None, this number is set to the number of sites in the configuration divided by the number of swaps (N_changes) such that a change on every site is tried on average.
        N_changes: int, default: 1
            Number of swaps performed in the proposal occupation
        """
        if sampling_frequency is None:
            sampling_frequency = int(self.N_sites / N_changes)
        self.run(N_samples, sampling_frequency, N_changes)
        return

    def get_variable_sites(self, config):
        config_variable_sites = np.sort(config.variable_sites.numpy(force=True))
        return np.nonzero(
            np.logical_not(
                self.frozen_wyckoff_sites[self.wyckoff_site[config_variable_sites]]
            )
        )[0]

    def initialize_data(self) -> None:
        """
        Initialize the MC dictionary with stored data.
        """
        fixed_variables_data: dict = {
            variable: getattr(self, variable) for variable in self.fixed_variables
        }
        fluctuating_variables_data: dict = {
            variable: [] for variable in ["occupation"] + self.fluctating_variables
        }
        self.data: dict = fixed_variables_data | fluctuating_variables_data
        self.store_state()
        return

    def store_state(self) -> None:
        """
        Stores the fluctuating variables of the current state into the data dictionary.
        """
        self.data["occupation"].append(self.occupation.tolist())
        for variable in self.fluctating_variables:
            self.data[variable].append(getattr(self, "get_" + variable)())
        return

    def set_temperature(self, temperature: float) -> None:
        """Sets the temperature and computes the beta value.

        Parameters
        ----------
        temperature: float
            Float value of the temperature.
        """
        self.temperature: float = temperature
        self.beta: float = 1 / (self.kB * temperature)
        return

    def set_composition(self) -> None:
        """
        Sets the number of sites assigned to a given specie for all species.
        """
        self.composition: list = [
            int((self.occupation == specie).sum()) for specie in range(self.N_species)
        ]
        return

    def get_E(self) -> float:
        """
        Returns the average energy of the current state.

        Returns
        -------
        float
            Average energy of the current state.
        """
        return float(self.primcell_energies.mean())

    def run(self, N_samples: int, sampling_frequency: int, N_changes: int = 1) -> None:
        """
        Runs the MC simulation

        Parameters
        ----------
        N_samples: int
            Number of samples to compute
        sampling_frequency: int
            Frequency to which samples should be read
        N_changes: int
            Number of confiurational changes performed in the proposal occupation
        """
        raise NotImplementedError("This method is not implemented in MCEnsemble class.")

    def _get_string(self) -> str:
        """
        String representation of the :py:obj:`MCEnsemble` object that provides an overview of
        the configuration and thermodynamic properties.

        Returns
        -------
        txt: string
            Multi-line string representation of the :py:obj:`MCEnsemble` object.
        """
        self.set_composition()
        N_samples = len(self.data[self.fluctating_variables[0]][1:])

        tabs = []

        # General
        table = (
            [
                [
                    "Temperature (beta)",
                    ":",
                    "%.3f K (%.3f 1/eV)" % (self.temperature, self.beta),
                ],
                ["Total number of sites", ":", len(self.occupation)],
                ["Number of variable sites", ":", self.N_sites],
            ]
            + [
                [
                    "Wyckoff group index %d" % ind,
                    ":",
                    (
                        "Frozen"
                        if frozen
                        else " ".join(self.wyckoff_dict["allowed_elements"][ind])
                    ),
                ]
                for ind, frozen in enumerate(self.frozen_wyckoff_sites)
            ]
            + [
                [
                    "Number of samples generated",
                    ":",
                    N_samples,
                ],
            ]
        )
        tabs.append(
            [tabulate(table, headers=["General:\n--------", "", ""], tablefmt="plain")]
        )

        # Fixed variables
        table = [
            [variable, ":", getattr(self, variable)]
            for variable in self.fixed_variables
        ]
        tabs.append(
            [
                tabulate(
                    table,
                    headers=["Fixed Variables:\n----------------", "", ""],
                    tablefmt="plain",
                )
            ]
        )

        # Fluctuating variables
        table = [
            [
                variable,
                ":",
                "%.3e"
                % (np.mean(self.data[variable][1:]) if N_samples > 0 else np.nan),
                "±",
                "%.3e"
                % (
                    np.std(self.data[variable][1:], ddof=1) if N_samples > 0 else np.nan
                ),
            ]
            for variable in self.fluctating_variables
        ]
        tabs.append(
            [
                tabulate(
                    table,
                    headers=[
                        "Fluctuating Variables:\n----------------------",
                        "",
                        "",
                        "",
                        "",
                    ],
                    tablefmt="plain",
                )
            ]
        )

        # Current state
        table = [
            [
                "Composition",
                ":",
                tabulate(
                    [
                        list(self.element_dictionary.keys()),
                        self.composition,
                    ],
                    tablefmt="plain",
                    colalign=["right"] * self.N_species,
                ),
            ],
            ["Energy", ":", "%.6f eV/unitcell" % self.data["E"][-1]],
        ]
        tabs.append(
            [
                tabulate(
                    table,
                    headers=["Current State:\n--------------", "", ""],
                    tablefmt="plain",
                )
            ]
        )

        txt = tabulate(
            tabs,
            # tablefmt="mixed_outline",
            tablefmt="heavy_grid",
        )
        width = len(txt.split("\n")[0]) + 8
        txt = (
            "\n{s: ^{n}}\n".format(
                s="\033[1m MONTE CARLO ENSEMBLE \033[0m",
                n=width,
            )
            + txt
            + "\n"
        )

        return txt

    def __str__(self) -> str:
        """String representation."""
        return "\n" + self._get_string() + "\n"


class Canonical(MCEnsemble):
    r"""
    Canonical Monte Carlo Simulations.

    The fixed quantities are:

    * Temperature
    * Composition
    * Number of atoms

    In canonical ensemble, the microscopic potential energy :math:`\Omega(\sigma)` for a given configuration :math:`\sigma` corresponds to:

    .. math::

        \Omega(\sigma) = E(\sigma)

    where :math:`E` is the total energy of the system.

    Parameters
    ----------
    model: eCE
        eCE object of the embedded cluster expansion model
    config: Config
        Config object of the input structure and occupations for the Monte Carlo simulation. The composition is read from this input configuration.
    temperature: float
        Float value of the temperature
    frozen_wyckoff_sites: list[bool] | None, default: None
        List of boolean variables where the ith variable indicates whether all sites in the ith Wyckoff group of equivalent sites are to be considered as frozen, i.e., the chemical species cannot be changed.
        The default is None, which sets all boolean variables to False (not frozen).
    device: str = 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\')
    """

    def __init__(
        self,
        model: eCE,
        config: Config,
        temperature: float,
        frozen_wyckoff_sites: list[bool] | None = None,
        device: str = "cpu",
    ) -> None:
        super().__init__(model, config, temperature, frozen_wyckoff_sites, device)

        # MC CONSTANTS
        # ------------
        self.permitted_species: NDArray[np.bool_] = self.compute_permitted_species()

        # MC VARIABLES
        # ------------
        self.permitted_sites: NDArray[np.bool_] = self.permitted_species[
            self.occupation, self.wyckoff_site
        ].T
        self.frozen_species: NDArray[np.bool_] = np.all(
            np.logical_not(self.permitted_sites[:, self.variable_sites]), axis=-1
        )
        for species_index in np.nonzero(self.frozen_species)[0]:
            self.variable_sites = self.variable_sites[
                self.occupation[self.variable_sites] != species_index
            ]
        self.N_sites = len(self.variable_sites)
        self.frozen_wyckoff_sites[:] = True
        self.frozen_wyckoff_sites[np.unique(self.wyckoff_site[self.variable_sites])] = (
            False
        )

        return

    def compute_permitted_species(self) -> NDArray[np.bool_]:
        """
        Returns the permitted sites per the specie currently sitting (dimension 0) and per Wyckoff group of equivalent sites (dimension 1) .

        Returns
        -------
        permitted_species: np.ndarray[bool]
            Integer numpy array with the permitted species.
        """
        permitted_species = np.zeros(
            (self.N_species, len(self.list_species_in), self.N_species),
            dtype=bool,
        )
        for sitting_specie in range(self.N_species):
            for wyckoff_index, species_in in enumerate(self.list_species_in):
                if sitting_specie in species_in:
                    permitted_species[
                        sitting_specie,
                        wyckoff_index,
                        species_in,
                    ] = True
                    permitted_species[sitting_specie, wyckoff_index, sitting_specie] = (
                        False
                    )
        return permitted_species

    def initialize_random_variables(self, size: int, N_swaps: int = 1) -> tuple:
        """
        Initializes the random variables correponding to:
            - The acceptance of the proposal (float)
            - The first site index where to swap the species (int)
            - The second site index where to swap the species (float)

        Parameters
        ----------
        size: int
            Number of MC steps
        N_swaps: int
            Number of swaps performed in the proposal occupation

        Returns
        -------
        tuple
            Tuple containing three numpy arrays correponding the random variable described above.
        """
        random_accpetance = self.rng.random(size=size)
        random_sites_1 = self.variable_sites[
            self.rng.integers(low=0, high=self.N_sites, size=size * N_swaps)
        ]
        random_sites_2 = self.rng.random(size=size * N_swaps)
        return (
            random_accpetance,
            random_sites_1.reshape(size, N_swaps),
            random_sites_2.reshape(size, N_swaps),
        )

    def delta_thermodynamic_potential(self) -> float:
        """
        Computes the change in the thermodynamic potential.

        Returns
        -------
        float
            Float value of the change in the thermodynamic potential.
        """
        delta_U = (self.trial_primcell_energies - self.primcell_energies).sum()
        return delta_U

    def accept(
        self, swap_indexes: NDArray[np.int_], neighbor_indexes: NDArray[np.int_]
    ) -> None:
        """
        Performs the changes in the MC VARIABLES in the event of the acceptance of the proposal.

        Parameters
        ----------
        swap_indexes: np.ndarray[Any, int]
            Integer numpy array of the site indexes where to swap the species
        neighbor_indexes: np.ndarray[Any, int]
            Integer numpy array of the neighbor primcells whose primcell-energy is modified
        """
        species = self.trial_occupation[swap_indexes]
        self.occupation[swap_indexes] = species
        self.permitted_sites[:, swap_indexes] = self.permitted_species[
            species, self.wyckoff_site[swap_indexes]
        ].T
        self.primcell_energies[neighbor_indexes] = self.trial_primcell_energies[
            neighbor_indexes
        ]
        return

    def reject(
        self, swap_indexes: NDArray[np.int_], neighbor_indexes: NDArray[np.int_]
    ) -> None:
        """
        Performs the changes in the MC VARIABLES in the event of the rejection of the proposal.

        Parameters
        ----------
        swap_indexes: np.ndarray[Any, int]
            Integer numpy array of the site indexes where to flip the species
        neighbor_indexes: np.ndarray[Any, int]
            Integer numpy array of the neighbor primcells whose primcell-energy is modified
        """
        self.trial_occupation[swap_indexes] = self.occupation[swap_indexes]
        self.trial_primcell_energies[neighbor_indexes] = self.primcell_energies[
            neighbor_indexes
        ]
        return

    def step(
        self,
        site_1_indexes: NDArray[np.int_],
        site_2_randoms: NDArray[np.floating],
        acceptance: float,
    ) -> None:
        """
        Performed one MC step.

        Parameters
        ----------
        site_1_indexes: np.ndarray[Any, int]
            Integer numpy array of the first site indexes where to swap the species
        site_2_randoms: np.ndarray[Any, float]
            Numpy array of with random values to determine the second site indexes where to swap the species
        acceptance: float
            Float value of the acceptance probability
        """

        # OCCUPATION
        # ----------
        site_indexes = np.zeros([len(site_1_indexes), 2], dtype=int)
        for swap_index, (site_1, random_2) in enumerate(
            zip(site_1_indexes, site_2_randoms)
        ):
            specie_1 = self.trial_occupation[site_1]
            possible_swap_sites = np.nonzero(self.permitted_sites[specie_1])[0]
            site_2 = possible_swap_sites[
                np.floor(random_2 * len(possible_swap_sites)).astype(int)
            ]
            specie_2 = self.trial_occupation[site_2]
            self.trial_occupation[[site_1, site_2]] = [specie_2, specie_1]
            site_indexes[swap_index] = [site_1, site_2]
        site_indexes = site_indexes.reshape(-1)
        neighbor_indexes = self.neighboring_primcells[
            self.unitcell_indexes[site_indexes]
        ].flatten()

        # ENERGIES
        # --------
        self.trial_primcell_energies[neighbor_indexes] = self.effective_hamiltonian(
            self.trial_occupation, neighbor_indexes
        )

        # ACCEPTING
        # ---------
        delta_omega = self.delta_thermodynamic_potential()
        if (delta_omega <= 0) or (np.exp(-self.beta * delta_omega) >= acceptance):
            self.accept(site_indexes, neighbor_indexes)
        else:
            self.reject(site_indexes, neighbor_indexes)

        return

    def run(self, N_samples: int, sampling_frequency: int, N_swaps: int = 1) -> None:
        """
        Runs the MC simulation

        Parameters
        ----------
        N_samples: int
            Number of samples to compute
        sampling_frequency: int
            Frequency to which samples should be read
        N_swaps: int
            Number of swaps performed in the proposal occupation
        """

        # INITIALIZATION
        # --------------

        self.trial_occupation: NDArray[np.int_] = self.occupation.copy()
        self.trial_primcell_energies: np.ndarray = self.primcell_energies.copy()

        acceptance_probabilities, random_sites_1, random_sites_2 = (
            self.initialize_random_variables(N_samples * sampling_frequency, N_swaps)
        )

        # MONTE CARLO PROCESS
        # -------------------

        for mc_step in range(N_samples * sampling_frequency):
            self.step(
                random_sites_1[mc_step],
                random_sites_2[mc_step],
                acceptance_probabilities[mc_step],
            )

            # Store state
            if (mc_step + 1) % sampling_frequency == 0:
                self.store_state()

        return


class SemiGrandCanonical(MCEnsemble):
    r"""
    Semi-Grand Canonical Monte Carlo Simulations.

    The fixed quantities are:

    * Temperature
    * Tilde chemical potenials
    * Number of atoms

    In grand canonical ensemble, the microscopic potential energy :math:`\Omega(\sigma)` for a given configuration :math:`\sigma` corresponds to:

    .. math::

        \Omega(\sigma) = E(\sigma) - \vec{\mu}^T \cdot \vec{N}(\sigma)

    where :math:`E` is the total energy of the system, 
    :math:`\vec{\mu}` is the vector of the chemcial potential for each specie, and
    :math:`\vec{N}` the vector of the number of atoms for each specie.

    In semi-grand canonical ensemble, the number of lattice sites is fixed and the the microscopic potential energy :math:`\tilde{\Omega}(\sigma)` becomes:

    .. math::

        \tilde{\Omega}(\sigma) = E(\sigma) - \vec{\tilde{\mu}}^T \cdot T \cdot \vec{N}(\sigma)

    with :math:`T` being the chemical transformation matrix of size (n-1)xn (with n being the number of elements).
    
    The modified chemcial potentials :math:`\vec{\tilde{\mu}}` satisfies the following relation:
    
    .. math::

        \begin{bmatrix} \vec{\tilde{\mu}}\\ \mu^* \end{bmatrix} = \begin{bmatrix} T \\ \vec{1}^T \end{bmatrix}^{-T} \cdot \vec{\mu}
    
    with :math:`\mu^*` being the background chemical potential. 
    The addition of the row of 1 to the chemcial transformation matrix corresponds to the constraint that the total number of atoms (the sum of all Ns) is constant.
    It turns out that: 
    
    .. math::

        \tilde{\Omega}(\sigma) = E(\sigma) - \vec{\tilde{\mu}}^T \cdot T \cdot \vec{N}(\sigma)
        
    Example
    -------
    Let's consider a ternary alloy composed of species A, B, and C, and choosing the specie C as background, the chemical transformation matrix :math:`T` reads as:
    
    .. math:: 
    
        T = \begin{bmatrix} 
            1 & 0 & 0 \\
            0 & 1 & 0  
            \end{bmatrix}
    
    and the modified chemical potnetials:
    
    .. math::

        \begin{bmatrix} \tilde{\mu}_1 \\ \tilde{\mu}_2 \\ \mu^* \end{bmatrix} = \begin{bmatrix} 1 & 0 & -1 \\ 0 & 1 & -1 \\ 0 & 0 & 1 \end{bmatrix} \vec{\mu} = \begin{bmatrix} \mu_A - \mu_C \\ \mu_B - \mu_C \\ \mu_C  \end{bmatrix}

    Parameters
    ----------
    model: eCE
        eCE object of the embedded cluster expansion model
    config: Config
        Config object of the input structure and occupations for the Monte Carlo simulation
    temperature: float
        Float value of the temperature
    mu_tilde: np.ndarray
        Numpy array with the tilde chemical potentials set for the Monte Carlo simulation.
        The array is expected to contain n-1 values (with n being the number of elements) as there are only
        n-1 independent compositions. The tilda chemical potential corresponds to the true chemical potential
        transformed by the inverse transform of the chemical_transformation (completed with a column of ones).
    chemical_transformation: np.ndarray
        Numpy array with the transformation matrix (T) that transforms the true chemical composition to the
        tilda_composition (conjugate variable of the mu_tilde).
        The matrix is expected to be of dimension (n-1)xn (with n being the number of elements) as there are
        only n-1 independent compositions, the total number od site (N_sites) being inplicitly assumed.
    frozen_wyckoff_sites: list[bool] | None, default: None
        List of boolean variables where the ith variable indicates whether all sites in the ith Wyckoff group of equivalent sites are to be considered as frozen, i.e., the chemical species cannot be changed.
        The default is None, which sets all boolean variables to False (not frozen).
    device: str, default: 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\')
    """

    kB = 8.617333262e-5

    def __init__(
        self,
        model: eCE,
        config: Config,
        temperature: float,
        mu_tilde: np.ndarray,
        chemical_transformation: np.ndarray,
        frozen_wyckoff_sites: list[bool] | None = None,
        device: str = "cpu",
    ) -> None:
        super().__init__(model, config, temperature, frozen_wyckoff_sites, device)

        # SETTINGS
        # --------
        self.set_mu_tilde(mu_tilde)
        self.chemical_transformation: np.ndarray = chemical_transformation

        # MC CONSTANTS
        # ------------
        self.number_permitted_species: NDArray[np.int_] = np.array(
            [len(species) for species in self.list_species_in], dtype=int
        )
        self.permitted_species: NDArray[np.int_] = self.compute_permitted_species()

        # MC DATA
        # -------
        self.fixed_variables: list[str] = ["temperature", "beta", "mu_tilde", "N_sites"]
        self.fluctating_variables: list[str] = ["E"] + [
            "N_%s" % elem for elem in self.element_dictionary
        ]
        for elem in self.element_dictionary:
            self.__N_elem_method(elem)
        self.initialize_data()

        return

    def __N_elem_method(self, elem):
        """
        Creates the N_elem methods

        Parameters
        ----------
        elem: str
            Name of th specie
        """

        def new_method():
            self.set_composition()
            return self.composition[self.element_dictionary[elem]] / len(
                self.neighboring_primcells
            )

        setattr(self, "get_N_" + elem, new_method)
        return

    def compute_permitted_species(self) -> NDArray[np.int_]:
        """
        Returns the permitted species per Wyckoff group of equivalent sites (dimension 0) and per the specie currently sitting (dimension 1).

        Returns
        -------
        permitted_species: np.ndarray[int]
            Integer numpy array with the permitted species.
        """
        permitted_species = np.full(
            (len(self.list_species_in), self.N_species, self.N_species - 1),
            fill_value=-1,
            dtype=int,
        )
        for wyckoff_index, species_in in enumerate(self.list_species_in):
            N = len(species_in)
            for index, specie in enumerate(species_in):
                mask = np.ones(N, dtype=bool)
                mask[index] = False
                permitted_species[wyckoff_index, specie, : N - 1] = species_in[mask]
        return permitted_species

    def get_chemical_potential_transformation(self) -> NDArray[np.int_]:
        r"""
        Returns the chemical potential transformation :math:`\tilde{T}`, including the fixed-number-of-sites constraint.
        The transformation :math:`\tilde{T}` is defined as.

        .. math::

            \tilde{T} = \begin{bmatrix} T \\ \vec{1}^T \end{bmatrix}^{-T}
            \begin{bmatrix} \vec{\tilde{\mu}}\\ \mu^* \end{bmatrix} = \tilde{T} \cdot \vec{\mu}

        Returns
        -------
        np.ndarray
            Numpy array of a squared matrix corresponding to the chemical potential transformation matrix.
            
        Example
        -------
        Let's consider a ternary alloy composed of species A, B, and C, and choosing the specie C as background, the chemical transformation matrix :math:`T` reads as:
        
        .. math:: 
        
            T = \begin{bmatrix} 
                1 & 0 & 0 \\
                0 & 1 & 0  
                \end{bmatrix}
        
        and chemical potential transformation matrix:
        
        .. math::

            \tilde{T} = \begin{bmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 1 & 1 & 1 \end{bmatrix}^{-T} = \begin{bmatrix} 1 & 0 & -1 \\ 0 & 1 & -1 \\ 0 & 0 & 1 \end{bmatrix}
        """
        return np.vstack(
            [self.chemical_transformation.astype(float), np.ones((1, self.N_species))]
        )

    def set_mu_tilde(self, mu_tilde: np.ndarray | list):
        """Sets the modified chemcial potentials (mu_tilde).

        Parameters
        ----------
        mu_tilde: np.ndarray | list
            Array of size n-1 (with n being the number of species) with the values of modified chemcial potentials (mu_tilde).
        """
        self.mu_tilde: list = [float(mu) for mu in mu_tilde]
        return

    def initialize_random_variables(self, size: int, N_flips: int = 1) -> tuple:
        """
        Initializes the random variables correponding to:
            - The acceptance of the proposal (float)
            - The site index where to flip the species (int)
            - The specie index of the trial specie within the list of permitted species (int)

        Parameters
        ----------
        size: int
            Number of MC steps
        N_flips: int
            Number of flips performed in the proposal occupation

        Returns
        -------
        tuple
            Tuple containing three numpy arrays correponding the random variable described above.
        """
        random_accpetance = self.rng.random(size=size)
        random_sites = self.variable_sites[
            self.rng.integers(low=0, high=self.N_sites, size=size * N_flips)
        ]
        random_uniform = self.rng.random(size=size * N_flips)
        random_specie_indexes = np.floor(
            random_uniform
            * (self.number_permitted_species[self.wyckoff_site[random_sites]] - 1)
        ).astype(int)
        return (
            random_accpetance,
            random_sites.reshape(size, N_flips),
            random_specie_indexes.reshape(size, N_flips),
        )

    def delta_thermodynamic_potential(self) -> float:
        """
        Computes the change in the thermodynamic potential.

        Returns
        -------
        float
            Float value of the change in the thermodynamic potential.
        """
        delta_U = (self.trial_primcell_energies - self.primcell_energies).sum()
        delta_chemical = np.inner(
            self.mu_tilde,
            self.chemical_transformation @ self.trial_delta_N,
        )
        return delta_U - delta_chemical

    def accept(
        self, swap_indexes: NDArray[np.int_], neighbor_indexes: NDArray[np.int_]
    ) -> None:
        """
        Performs the changes in the MC VARIABLES in the event of the acceptance of the proposal.

        Parameters
        ----------
        swap_indexes: np.ndarray[Any, int]
            Integer numpy array of the site indexes where to flip the species
        neighbor_indexes: np.ndarray[Any, int]
            Integer numpy array of the neighbor primcells whose primcell-energy is modified
        """
        self.occupation[swap_indexes] = self.trial_occupation[swap_indexes]
        self.primcell_energies[neighbor_indexes] = self.trial_primcell_energies[
            neighbor_indexes
        ]
        self.trial_delta_N[:] = 0
        return

    def reject(
        self, swap_indexes: NDArray[np.int_], neighbor_indexes: NDArray[np.int_]
    ) -> None:
        """
        Performs the changes in the MC VARIABLES in the event of the rejection of the proposal.

        Parameters
        ----------
        swap_indexes: np.ndarray[Any, int]
            Integer numpy array of the site indexes where to flip the species
        neighbor_indexes: np.ndarray[Any, int]
            Integer numpy array of the neighbor primcells whose primcell-energy is modified
        """
        self.trial_occupation[swap_indexes] = self.occupation[swap_indexes]
        self.trial_primcell_energies[neighbor_indexes] = self.primcell_energies[
            neighbor_indexes
        ]
        self.trial_delta_N[:] = 0
        return

    def step(
        self,
        site_indexes: NDArray[np.int_],
        specie_indexes: NDArray[np.int_],
        acceptance: float,
    ) -> None:
        """
        Performed one MC step.

        Parameters
        ----------
        swap_indexes: np.ndarray[Any, int]
            Integer numpy array of the site indexes where to flip the species
        specie_indexes: np.ndarray[Any, int]
            Integer numpy array of the specie indexes of the trial speciees within the list of permitted species
        acceptance: float
            Float value of the acceptance probability
        """

        # OCCUPATION
        # ----------
        for site, index in zip(site_indexes, specie_indexes):
            current_species = self.trial_occupation[site]
            trial_specie = self.permitted_species[
                self.wyckoff_site[site], self.trial_occupation[site], index
            ]
            self.trial_occupation[site] = trial_specie
            self.trial_delta_N[current_species] -= 1
            self.trial_delta_N[trial_specie] += 1
        neighbor_indexes = self.neighboring_primcells[
            self.unitcell_indexes[site_indexes]
        ].flatten()

        # ENERGIES
        # --------
        self.trial_primcell_energies[neighbor_indexes] = self.effective_hamiltonian(
            self.trial_occupation, neighbor_indexes
        )

        # ACCEPTING
        # ---------
        delta_omega = self.delta_thermodynamic_potential()
        if (delta_omega <= 0) or (np.exp(-self.beta * delta_omega) >= acceptance):
            self.accept(site_indexes, neighbor_indexes)
        else:
            self.reject(site_indexes, neighbor_indexes)

        return

    def run(self, N_samples: int, sampling_frequency: int, N_flips: int = 1) -> None:
        """
        Runs the MC simulation

        Parameters
        ----------
        N_samples: int
            Number of samples to compute
        sampling_frequency: int
            Frequency to which samples should be read
        N_flips: int
            Number of flips performed in the proposal occupation
        """

        # INITIALIZATION
        # --------------

        self.trial_occupation: NDArray[np.int_] = self.occupation.copy()
        self.trial_primcell_energies: np.ndarray = self.primcell_energies.copy()
        self.trial_delta_N: NDArray[np.int_] = np.zeros(self.N_species, dtype=int)

        acceptance_probabilities, random_sites, random_specie_indexes = (
            self.initialize_random_variables(N_samples * sampling_frequency, N_flips)
        )

        # MONTE CARLO PROCESS
        # -------------------

        for mc_step in range(N_samples * sampling_frequency):
            self.step(
                random_sites[mc_step],
                random_specie_indexes[mc_step],
                acceptance_probabilities[mc_step],
            )

            # Store state
            if (mc_step + 1) % sampling_frequency == 0:
                self.store_state()

        return
