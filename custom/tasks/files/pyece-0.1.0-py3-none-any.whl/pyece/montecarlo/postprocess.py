import numpy as np
from scipy.integrate import cumulative_simpson


def ideal_entropy(composition: np.ndarray) -> float:
    r"""Computes the ideal entropy :math:`S` (eV/f.u.), given a composition :math:`\vec{x}` as:

    .. math:: S = -k_B \sum_i x_i \ln(x_i) \quad \text{with} \quad x_i \in [0,1]\, ; \; \sum_i x_i = 1

    Parameters
    ----------
    composition: np.ndarray
        Numpy array with the composition.

    Returns
    -------
    float
        Ideal entropy per atom
    """
    kB = 8.617333262e-5
    return -kB * (
        composition
        * np.log(composition, out=np.zeros_like(composition), where=composition > 0)
    ).sum(axis=-1)


def Gibbs_free_energy(
    enthalpy: float | np.ndarray,
    entropy: float | np.ndarray,
    temperatures: float | np.ndarray,
) -> float | np.ndarray:
    """Computes the Gibbs free energy (G):
    .. math:: G = H - TS = U + PV -TS

    Parameters
    ----------
    enthalpy: float | np.ndarray
        Enthalpy (H).
    entropy: float | np.ndarray
        Entropy (S).
    temperatures: float | np.ndarray
        Temperature (T).

    Returns
    -------
    float | np.ndarray
        Gibbs free energy
    """
    return enthalpy - temperatures * entropy


# def Gibbs_fixed_composition(
#     temperatures: np.ndarray,
#     energy: np.ndarray,
#     composition: np.ndarray,
# ) -> np.ndarray:
#     r"""Computes the Gibbs free energy per atom (eV/atom) using the von Helmholtz equation:

#     .. math:: G(T, \vec{x}) = \frac{T}{T_0}G(T_0, \vec{x}) + T \int_{T_0}^{T} - \frac{E(\tau, \vec{x})}{\tau^2} d\tau

#     Info
#     ----
#     The function assumes the inputs come from a cooling run simulation in the Canonical ensemble (fixed temperature, composition, and pressure)

#     Parameters
#     ----------
#     temperatures: np.ndarray,
#         Numpy array with the temperatures.
#     energy: np.ndarray,
#         Numpy array with the averaged internal energies per atom evaluated at the correponding `temperatures`.
#     composition: np.ndarray
#         Numpy array with the composition.

#     Returns
#     -------
#     np.ndarray
#         Numpy array with the computed Gibbs free energy.
#     """
#     G_0 = Gibbs_free_energy(energy[0], ideal_entropy(composition), temperatures[0])
#     helmholtz_function = energy / temperatures**2
#     integration = (
#         cumulative_simpson(y=helmholtz_function, x=-temperatures, initial=0)
#         + G_0 / temperatures[0]
#     )
#     return integration * temperatures


def thermodynamic_temperature_integration(
    betas: np.ndarray,
    potential: np.ndarray,
    phi_0: float,
) -> np.ndarray:
    r"""Computes the thermodynamic potential energy :math:`\Phi` using the von Helmholtz equation.

    Let's :math:`Z` be the partition function corresponding to the ensemble of interest:

    .. math:: Z = \sum_\sigma \exp^{-\beta \Omega(\sigma)}

    where :math:`\beta = (k_B T)^{-1}` and :math:`\Omega(\sigma)` is the microscopic potential energy corresponding to the ensemble (e.g., :math:`\Omega(\sigma) = E(\sigma)` for the canonical ensemble and :math:`\Omega(\sigma) = E(\sigma) - \sum_i \mu_i N_i(\sigma)` for the grand canonical ensemble).
    The thermodynamic potential :math:`\Phi = \langle\Omega\rangle - TS = - 1/\beta \ln(Z)` satisfies the differential equation:

    .. math::

        \frac{\partial (\beta \Phi)}{\partial \beta} &= \Phi + \beta \frac{\partial \Phi}{\partial \beta} \\
        &= \Phi + \beta \frac{\partial \Phi}{\partial \beta} \\
        &= \Phi + \frac{1}{k_B \beta} S \\
        &= \langle\Omega\rangle

    where the :math:`\langle\cdot\rangle` denotes the ensemble average.
    The thermodynamic potential is recovered by integrating the differential equation with respect to :math:`\beta`:

    .. math::

        \Phi(\beta, \vec{x}) = \frac{\beta_0}{\beta}\Phi(\beta_0, \vec{x}) + \frac{1}{\beta} \int_{\beta_0} ^ \beta \langle\Omega(b, \vec{x})\rangle db

    Parameters
    ----------
    betas: np.ndarray,
        Numpy array with the beta values.
    potential: np.ndarray,
        Numpy array with the ensemble averaged microscopical potential energy evaluated at the correponding beta (`temperatures`).
    phi_0: float
        Initial value of the thermodynamic potential energy.

    Returns
    -------
    np.ndarray
        Numpy array with the computed thermodynamic potential energy.
    """
    if betas[0] > betas[-1]:
        direction = -1.0  # Heating
    else:
        direction = 1.0  # Cooling
    integration = (
        cumulative_simpson(y=direction * potential, x=direction * betas, initial=0)
        + phi_0 * betas[0]
    )
    # integration = (
    #     cumulative_trapezoid(y=helmholtz_function, x=temperatures, initial=0)
    #     + G_0 / temperatures[0]
    # )
    return integration / betas
