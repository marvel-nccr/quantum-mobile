from __future__ import annotations

from typing import Callable

import numpy as np
import torch
from numpy.typing import NDArray
from pymatgen.core import Structure
from torch import Tensor, no_grad

from pyece.analysis import cluster, lrop, plasticity, srop
from pyece.core.clex import eCE
from pyece.core.configurations import Config
from pyece.core.prim import Prim


class SublatticeOccupation:
    """
    Class to create the Sublattice object to investigate sublattice occupations of a supercell structure constructed from the :py:obj:`~.pyece.core.prim.Prim` object.

    Parameters
    ----------
    supercell_transformation: list
        Integer transformation matrix to build the supercell from the :py:obj:`~.pyece.core.prim.Prim` object.
    remove_absent: bool, default: False
        Set to True to remove the sublattice occupation quantities for species absent of the throughout the simulation.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each sublattice composition among all occupations
    """

    def __init__(
        self,
        supercell_transformation: list,
        remove_absent: bool = False,
        reduce: bool = False,
    ):
        self.supercell_transformation: NDArray[np.int_] = np.array(
            supercell_transformation, dtype=int
        )
        self.remove_absent: bool = remove_absent
        self.reduce: bool = reduce
        return

    def set_calculator(self, prim: Prim, reference_structure: Structure) -> None:
        """
        Creates the Sublattice object to investigate sublattice occupations of a supercell structure constructed from the :py:obj:`~.pyece.core.prim.Prim` object.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        reference_structure: Structure
            Pymatgen structure to compute the sublattice composition from.
        """
        self.calculator: lrop.Sublattice = lrop.Sublattice(
            prim,
            reference_structure,
            self.supercell_transformation,
            self.reduce,
        )
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the sublattice composition.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        output_dct: dict
            Dictionary with the sublattice compositions.
        """
        occupation = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupation))
        else:
            sel = select

        output_dct = self.calculator(occupation[sel])

        if self.remove_absent:
            list_keys = list(output_dct.keys())
            species, inverse = np.unique(
                [key.split("_")[0] for key in list_keys],
                return_inverse=True,
            )
            size = self.calculator.config.occupation.numpy(force=True).size
            remaining_keys = []
            for specie_index in range(len(species)):
                specie_occ = []
                list_key_indexes = np.nonzero(inverse == specie_index)[0]
                for key_index in list_key_indexes:
                    specie_occ += output_dct[list_keys[key_index]]
                if np.any(np.array(specie_occ) >= 0.9 / size):
                    remaining_keys += [
                        list_keys[key_index] for key_index in list_key_indexes
                    ]
            output_dct = {
                "SublatticeOccupation_" + key: output_dct[key] for key in remaining_keys
            }
        else:
            output_dct = {
                "SublatticeOccupation_" + key: output_dct[key]
                for key in list(output_dct.keys())
            }

        return output_dct


class ClusterOccupation:
    """
    Class that creates an object to investigate cluster densities of occupations, i.e. the number of times a cluster with a given decoration appears in the structure.

    Parameters
    ----------
    cutoffs: list[float], default: [0, 0, 4]
        List with the nth value corresponds to the cutoff radius for clusters of nth body-order.
    density: bool, default: True
        Set to True to return a probability for a given cluster to appear.
    remove_absent: bool, default: False
        Set to True to remove data for which no SRO can be computed (no presence of the pair cluster), which would result in NaN otherwise.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each SRO among all occupations
    """

    def __init__(
        self,
        cutoffs: list[float] = [0.0, 0.0, 4.0],
        density: bool = True,
        remove_absent: bool = False,
        reduce: bool = False,
    ):
        self.cutoffs: list[float] = cutoffs
        self.density: bool = density
        self.remove_absent: bool = remove_absent
        self.reduce: bool = reduce
        return

    def set_calculator(self, prim: Prim, reference_structure: Structure) -> None:
        """
        Creates a function that computes the cluster densities of occupations.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        reference_structure: Structure
            Pymatgen structure to compute the cluster occupation from.
        """
        self.calculator: cluster.Cluster = cluster.Cluster(
            prim=prim,
            structure=reference_structure,
            cutoffs=self.cutoffs,
            density=self.density,
            reduce=self.reduce,
        )
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the cluster densities of occupations.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        dict
            Dictionary with the cluster densities of occupations.
        """

        occupation = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupation))
        else:
            sel = select
        output_dct = self.calculator(occupation[sel])

        cleaned_output = {}
        for key, values in output_dct.items():
            arr = np.asarray(values)

            if self.remove_absent:
                arr = arr[~np.isnan(arr)]

            cleaned_output[f"ClusterOccupation_{key}"] = arr.tolist()

        output_dct = cleaned_output

        return output_dct


class SRO:
    """
    Class that creates an object to investigate Warren-Cowley short-range order (SRO) parameters.

    Parameters
    ----------
    cutoffs: list[float], default: [0, 0, 4]
        List with the nth value corresponds to the cutoff radius for clusters of nth body-order.
    remove_absent: bool, default: False
        Set to True to remove data for which no SRO can be computed (no presence of the pair cluster), which would result in NaN otherwise.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each SRO among all occupations
    """

    def __init__(
        self,
        cutoffs: list[float] = [0.0, 0.0, 4.0],
        remove_absent: bool = False,
        reduce: bool = False,
    ):
        self.cutoffs: list[float] = cutoffs
        self.remove_absent: bool = remove_absent
        self.reduce: bool = reduce
        return

    def set_calculator(self, prim: Prim, reference_structure: Structure) -> None:
        """
        Creates a function that computes the Warren-Cowley short-range order (SRO) parameters.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        reference_structure: Structure
            Pymatgen structure to compute the SRO from.
        """
        cluster_obj = cluster.Cluster(
            prim=prim,
            structure=reference_structure,
            cutoffs=self.cutoffs,
            density=True,
            reduce=self.reduce,
        )
        self.calculator: Callable = lambda occupation: cluster_obj.Warren_Cowley_SRO(
            occupation
        )
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the Warren-Cowley short-range order (SRO) parameters.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        dict
            Dictionary with the Warren-Cowley short-range order (SRO).
        """

        occupation = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupation))
        else:
            sel = select
        output_dct = self.calculator(occupation[sel])

        cleaned_output = {}
        for key, values in output_dct.items():
            arr = np.asarray(values)

            if self.remove_absent:
                arr = arr[~np.isnan(arr)]

            cleaned_output[f"SRO_{key}"] = arr.tolist()

        output_dct = cleaned_output

        return output_dct


class SRO_pair:
    """
    Class to create the SRO object to investigate the short range order (SRO) parameters.

    Parameters
    ----------
    cutoff: float, default: 4.0
        Cutoff radius of the pair clusters.
    remove_absent: bool, default: False
        Set to True to remove data for which no SRO can be computed (no presence of the pair cluster), which would result in NaN otherwise.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each SRO among all occupations
    """

    def __init__(
        self, cutoff: float = 4.0, remove_absent: bool = False, reduce: bool = False
    ):
        self.cutoff: float = cutoff
        self.remove_absent: bool = remove_absent
        self.reduce: bool = reduce
        return

    def set_calculator(self, prim: Prim, reference_structure: Structure) -> None:
        """
        Creates the SRO object to to investigate the short range order (SRO) parameters.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        reference_structure: Structure
            Pymatgen structure to compute the SRO from.

        Returns
        -------
        srop.SRO
            SRO object.
        """
        self.calculator: srop.SRO = srop.SRO(
            prim, reference_structure, self.cutoff, self.reduce
        )
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the SRO.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        dict
            Dictionary with the SRO.
        """
        occupation = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupation))
        else:
            sel = select
        output_dct = self.calculator(occupation[sel])

        cleaned_output = {}
        for key, values in output_dct.items():
            arr = np.asarray(values)

            if self.remove_absent:
                arr = arr[~np.isnan(arr)]

            cleaned_output[f"SRO_pair_{key}"] = arr.tolist()

        output_dct = cleaned_output

        return output_dct


class Prob_pair:
    """
    Class that creates an object to investigate pair joint probabilities.

    Parameters
    ----------
    cutoff: float, default: 4.0
        Cutoff radius of the pair clusters.
    remove_absent: bool, default: False
        Set to True to remove data for which no joint probability can be computed (no presence of the pair cluster), which would result in NaN otherwise.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each probability among all occupations
    """

    def __init__(
        self, cutoff: float = 4.0, remove_absent: bool = False, reduce: bool = False
    ):
        self.cutoff: float = cutoff
        self.remove_absent: bool = remove_absent
        self.reduce: bool = reduce
        return

    def set_calculator(self, prim: Prim, reference_structure: Structure) -> None:
        """
        Creates a function that computes the pair joint probabilities.

        Parameters
        ----------
        prim: Prim
            Prim object containing all references to the lattice.
        reference_structure: Structure
            Pymatgen structure to compute the pair probabilities from.
        """
        sro_obj = srop.SRO(prim, reference_structure, self.cutoff, self.reduce)
        self.calculator: Callable = lambda occupation: sro_obj.get_prob(occupation)
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the pair joint probabilities.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        dict
            Dictionary with the pair joint probabilities.
        """

        occupation = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupation))
        else:
            sel = select
        output_dct = self.calculator(occupation[sel])

        cleaned_output = {}
        for key, values in output_dct.items():
            arr = np.asarray(values)

            if self.remove_absent:
                arr = arr[~np.isnan(arr)]

            cleaned_output[f"Prob_pair_{key}"] = arr.tolist()

        output_dct = cleaned_output

        return output_dct


class Corr:
    """
    Class that creates an object to investigate the projected correlation functions of the model.

    Parameters
    ----------
    path_to_model: str
        Path to the eCE model to be used to compute the correlation functions.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each correlation function among all occupations.
    device: str = 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\').
    """

    def __init__(self, path_to_model: str, reduce: bool = False, device: str = "cpu"):
        self.model: eCE = eCE.load(path_to_model)
        self.model.prod()
        self.model.to(device)
        self.reduce: bool = reduce
        self.device: str = device
        return

    def set_calculator(self, reference_structure: Structure, **args) -> None:
        """
        Creates a function that computes the correlation functions.

        Parameters
        ----------
        reference_structure: Structure
            Pymatgen structure to compute the correlation functions from.
        """
        self.config = Config.from_structure(reference_structure, self.model.prim)

        @no_grad()
        @torch.compile(fullgraph=True, mode="reduce-overhead")
        def effective_phi(occupation: Tensor) -> Tensor:
            return self.model.get_averaged_correlations(
                occupation[self.config.neighborhood_per_primcell]
            )

        self.calculator: Callable = lambda occupation: effective_phi(
            torch.from_numpy(occupation).to(self.device),
        ).numpy(force=True)
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the correlation functions.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        phi_dict
            Dictionary with the evaluated correlation functions.
        """
        occupations = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupations))
        else:
            sel = select

        if occupations is None:
            occupations = self.config.occupation.reshape(1, -1).numpy(force=True)
        elif len(occupations.shape) == 1:
            occupations = occupations.reshape(1, -1)
        else:
            occupations = occupations[sel]

        phi_list = []
        for occup in occupations:
            phi_list.append(self.calculator(occup))
        phi = np.array(phi_list)
        if self.reduce and (occupations is not None) and (len(occupations.shape) > 1):
            mean = (phi.mean(axis=0),)
            std = (phi.std(axis=0, ddof=1),)
            phi_dict = {
                "Corr_%d" % i: [mean[i], std[i]]
                for i in range(self.model.features.N_features)
            }
        else:
            phi_dict = {
                "Corr_%d" % i: phi[:, i].tolist()
                for i in range(self.model.features.N_features)
            }

        return phi_dict


class SRO_excess_surface_energy:
    """
    Class that creates an object to evaluate the SRO excess surface energy during a dislocation slip, as described in <https://doi.org/10.1016/j.actamat.2023.119472>`_.
    The slip plane must be (001) with a slip direction along [100].

    Parameters
    ----------
    path_to_model: str
        Path to the eCE model to be used to compute the correlation functions.
    slip_vector: list[float],
        Vector of the dislocation slip in fractional coordinate within the (001) plane.
    slip_block_size: float, default: 0.5
        Fractional z-coordinate such that all atoms with fractional z-ccordinate greater or equal to 0.5 belong to the slip block.
    reduce: bool, default: False
        Set to True to compute the mean and standard deviation of each correlation function among all occupations.
    device: str = 'cpu'
        Device to be used for pytorch operations (Optional: default = \'cpu\').
    """

    def __init__(
        self,
        path_to_model: str,
        slip_vector: list[float],
        slip_block_size: float = 0.5,
        reduce: bool = False,
        device: str = "cpu",
    ):
        self.model: eCE = eCE.load(path_to_model)
        self.model.prod()
        self.model.to(device)
        self.slip_vector: list[float] = slip_vector
        self.slip_block_size: float = slip_block_size
        self.reduce: bool = reduce
        self.device: str = device
        return

    def set_calculator(self, reference_structure: Structure, **args) -> None:
        """
        Creates a function that computes the SRO excess surface energies.

        Parameters
        ----------
        reference_structure: Structure
            Pymatgen structure to compute the SRO excess energy from.
        """
        self.calculator: plasticity.SRO_excess_surface_energy = (
            plasticity.SRO_excess_surface_energy(
                model=self.model,
                reference_structure=reference_structure,
                slip_vector=self.slip_vector,
                slip_block_size=self.slip_block_size,
                reduce=False,
                device=self.device,
            )
        )
        return

    def __call__(self, data: dict, select: NDArray[np.int_] | None = None) -> dict:
        """
        Computes the SRO excess surface energies.

        Parameters
        ----------
        data: dict
            Dictionary with the different data resulting from an Monte-Carlo simulation. The dictionary must contain the \'occupation\' field.
        select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)

        Returns
        -------
        gamma_dict
            Dictionary with the evaluated SRO excess surface energies.
        """
        occupations = np.array(data["occupation"], dtype=int)
        sel: NDArray[np.int_] | slice
        if select is None:
            sel = slice(len(occupations))
        else:
            sel = select

        if occupations is None:
            occupations = self.config.occupation.reshape(1, -1).numpy(force=True)
        elif len(occupations.shape) == 1:
            occupations = occupations.reshape(1, -1)
        else:
            occupations = occupations[sel]

        gamma = self.calculator(occupations)
        if self.reduce:
            mean = gamma.mean()
            std = gamma.std(ddof=1)
            gamma_dict = {"SRO_excess_surface_energy": [mean, std]}
        else:
            gamma_dict = {"SRO_excess_surface_energy": gamma.tolist()}

        return gamma_dict
