from __future__ import annotations

import json
import tarfile
from os import remove
from os.path import basename, dirname, join
from time import time
from typing import Callable
from warnings import warn

import numpy as np
from numpy.typing import NDArray

from pyece.montecarlo import timeseries
from pyece.montecarlo.mcmc import MCEnsemble


def compute_variable_confidence_interval(
    data: np.ndarray,
    variable_name: list[str],
    confidence: float = 0.95,
) -> dict:
    """
    Run a series of MC simulations along a temperature path.

    Parameters
    ----------
    data: np.ndarray
        Numpy array with the results of a MCMC simulation.
    variable_name: list[str]
        List with the name of the property for each row in the datra.
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)

    Returns
    -------
    data: dict
        Dictionary with the means and covariances for each variable as well as the respective confidence intervals.
    """

    variable_dict = {}
    mean_vector, covariance_matrix = timeseries.compute_estimators_uncorrelated(
        data, confidence=confidence
    )

    # Mean
    for index_1, var_name_1 in enumerate(variable_name):
        variable_dict["<%s>" % var_name_1] = {
            "mean": mean_vector[index_1, 1],
            "interval": [mean_vector[index_1, 0], mean_vector[index_1, 2]],
        }

    # Covariance
    for index_1, var_name_1 in enumerate(variable_name):
        for index_2, var_name_2 in enumerate(variable_name):
            if index_2 < index_1:
                continue
            variable_dict[
                "<%s %s>-<%s><%s>" % (var_name_1, var_name_2, var_name_1, var_name_2)
            ] = {
                "mean": covariance_matrix[index_1, index_2, 1],
                "interval": [
                    covariance_matrix[index_1, index_2, 0],
                    covariance_matrix[index_1, index_2, 2],
                ],
            }

    return variable_dict


def compute_properties_confidence_interval(
    data: dict,
    list_properties: list[Callable] = [],
    select: NDArray[np.int_] | None = None,
    confidence: float = 0.95,
) -> dict:
    """
    Run a series of MC simulations along a temperature path.

    Parameters
    ----------
    data: dict
        Dictionary with the :py:obj:`~.pyece.montecarlo.mcmc.MCEnsemble` output data.
    list_properties: list[Callable], default: []
        List of functions that depend on the :py:obj:`~.pyece.montecarlo.mcmc.MCEnsemble` output data dictionary.
    select: np.ndarray[Any, int] | None, default: None
            Numpy array with the indexes of the data to be used (if None, all data are used)
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)

    Returns
    -------
    data: dict
        Dictionary with the mean and confidence interval for each property.
    """

    properties_dict = {}
    for prop in list_properties:
        prop_dct = prop(data=data, select=select)
        for key in list(prop_dct.keys()):
            series = np.array(prop_dct[key])
            if series.size == 0:
                continue
            mean = timeseries.compute_average(series, confidence=confidence)
            properties_dict[key] = {
                "mean": mean[1],
                "interval": [mean[0], mean[2]],
            }

    return properties_dict


def fixed_state(
    mc: MCEnsemble,
    precision: dict = {},
    list_properties: list[Callable] = [],
    N_uncorrelated_samples: int = 50,
    sampling_frequency: int | None = None,
    N_changes: int = 1,
    min_samples: int = 500,
    max_samples: int = 1000,
    confidence: float = 0.95,
    verbose: bool = True,
) -> tuple:
    """
    Run a series of MC simulations at fixed thermodynamic state.

    Parameters
    ----------
    mc: MCEnsemble
        MonteCarlo ensemble object describing the thermodynamic ensemble characterizing the system.
    precision: dict, default: {}
        Dictionary with the name of the quantity and the desired convergence precision (size of the confidence interval) (e.g., {'quantity': precision}).
    list_properties: list[Callable], default: []
        List of functions that depend on the :py:obj:`~.pyece.montecarlo.mcmc.MCEnsemble` output data dictionary.

        Example
        -------
        Pre-built functions are available in the :py:mod:`~.pyece.montecarlo.properties` modules (e.g., :py:obj:`~.pyece.montecarlo.properties.SublatticeOccupation` and :py:obj:`~.pyece.montecarlo.properties.SRO`).
        Here is an example of the construction of a function (`property_fct`) that computes the short range order parameter of any configuration::

            from pyece.core.clex import eCE
            from pyece.core.configurations import Config
            from pyece.montecarlo.properties import SRO

            property_fct = SRO(3.0)
            property_fct.set_calculator(eCE_model.prim, config.get_structure())

    N_uncorrelated_samples: int, default: 50
        Minimum number of uncorrelated samples
    sampling_frequency: int | None, default: None
        Frequency to which samples should be read. If None, this number is set to the number of sites in the configuration divided by the number of changes (N_changes) such that a change on evry site is tried on average.
    N_changes: int, default: 1
        Number of trial changes performed in the proposal occupation at each MC step
    min_samples: int, default: 0
        Minimum number of samples to be computed
    max_samples: int, default: 1000
        Maximum number of samples to be computed
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)
    verbose: bool, default : True
        Set to True to print information about the MCMC simulation.

    Returns
    -------
    output_data: dict
        Dictionary with the output processed data.
    timeseries_data: dict
        Dictionary with the uncorrelated timeseries of the fluctuating variables.
    """
    state_data = {variable: mc.data[variable] for variable in mc.fixed_variables}
    processed_data = {}

    if sampling_frequency is None:
        sampling_frequency = int(mc.N_sites / N_changes)

    # Produce data until convergence
    N_to_compute = max(N_uncorrelated_samples, min_samples, 1)
    N_samples = 0
    complete = False
    while (not complete) and (N_samples < max_samples):
        # MCMC run
        t = time()
        mc(N_to_compute, sampling_frequency, N_changes)
        t = time() - t
        time_per_step = t / sampling_frequency / N_to_compute
        N_samples += N_to_compute

        fluctuating_variables = np.array(
            [mc.data[variable] for variable in mc.fluctating_variables]
        )
        eq_time = timeseries.equilibration_time_ACF(fluctuating_variables[:, 1:]) + 1
        uncorrelated_indexes = (
            timeseries.get_uncorrelated_indexes(fluctuating_variables[:, eq_time:])
            + eq_time
        )
        Neff = uncorrelated_indexes.size

        if Neff > 0:
            # Compute timeseries averages
            fluctuating_variables = fluctuating_variables[:, uncorrelated_indexes]
            processed_data = compute_variable_confidence_interval(
                fluctuating_variables, mc.fluctating_variables, confidence
            )
            processed_data |= compute_properties_confidence_interval(
                mc.data, list_properties, uncorrelated_indexes, confidence
            )

            # Determine convergence
            interval_size_dct = {}
            precision_ratio = 0
            for quantity in list(precision.keys()):
                if quantity not in list(processed_data.keys()):
                    warn(
                        "The quantity '%s' is not computed and thus not treated.\nAvailable quantities are:\n - "
                        % quantity
                        + "\n - ".join(list(processed_data.keys()))
                        + "\n"
                    )
                    continue
                interval_size = np.abs(
                    processed_data[quantity]["interval"][1]
                    - processed_data[quantity]["interval"][0]
                )
                interval_size_dct[quantity] = interval_size
                precision_ratio = max(
                    precision_ratio, interval_size / precision[quantity]
                )
            complete = (Neff >= N_uncorrelated_samples) and (precision_ratio < 1)

            # Determine number of samples to compute
            N_to_compute = int(
                max(
                    min(
                        max(
                            (precision_ratio**2 - 1)
                            * (N_samples - eq_time),  # to achieve precision
                            (N_uncorrelated_samples - Neff)
                            * (N_samples - eq_time)
                            / Neff,  # to achieve uncorrelated samples
                        ),
                        max_samples - N_samples,  # limited to maximum samples
                    ),
                    1,
                )
            )
        else:
            N_to_compute = int(
                max(min(N_uncorrelated_samples, max_samples - N_samples), 1)
            )
            interval_size_dct = {}
            for quantity in list(precision.keys()):
                interval_size_dct[quantity] = np.nan

        if verbose:
            print(
                "%d uncorrelated samples out of %d samples with equilibration time %d (Time per MC step: %.3e) ===> Status: %s\n"
                % (
                    Neff,
                    N_samples - eq_time + 1,
                    eq_time,
                    time_per_step,
                    "complete" if complete else "incomplete",
                )
                + "\n".join(
                    [
                        " - Convergence %s : %.6e" % (key, interval_size_dct[key])
                        for key in list(interval_size_dct.keys())
                    ]
                )
            )

    output_data = (
        state_data
        | processed_data
        | {
            "metadata": {
                "total_samples": N_samples,
                "equilibrium": int(eq_time),
                "N_eff": Neff,
                "complete": bool(complete),
            }
        }
    )
    timeseries_data = (
        state_data
        | {
            name: series.tolist()
            for series, name in zip(fluctuating_variables, mc.fluctating_variables)
        }
        | {
            "occupation": np.array(mc.data["occupation"], dtype=int)[
                uncorrelated_indexes
            ].tolist()
        }
    )

    return output_data, timeseries_data


def cooling(
    mc: MCEnsemble,
    temperatures: list | np.ndarray,
    precision: dict = {},
    list_properties: list[Callable] = [],
    N_uncorrelated_samples: int = 50,
    sampling_frequency: int | None = None,
    N_changes: int = 1,
    min_samples: int = 500,
    max_samples: int = 1000,
    confidence: float = 0.95,
    path_to_result_data: str | None = None,
    path_to_raw_data: str | None = None,
    path_to_last_config: str | None = None,
    verbose: bool = True,
) -> dict:
    """
    Run a series of MC simulations at fixed thermodynamic state.

    Parameters
    ----------
    mc: MCEnsemble
        MonteCarlo ensemble object describing the thermodynamic ensemble characterizing the system.
    temperatures: list | np.ndarray
        Array with the sequence of temperature to run the simulations at.
    precision: dict, default: {}
        Dictionary with the name of the quantity and the desired convergence precision (size of the confidence interval) (e.g., {'quantity': precision}).
    list_properties: list[Callable], default: []
        List of functions that depend on the :py:obj:`~.pyece.montecarlo.mcmc.MCEnsemble` output data dictionary.

        Example
        -------
        Pre-built functions are available in the :py:mod:`~.pyece.montecarlo.properties` modules (e.g., :py:obj:`~.pyece.montecarlo.properties.SublatticeOccupation` and :py:obj:`~.pyece.montecarlo.properties.SRO`).
        Here is an example of the construction of a function (`property_fct`) that computes the short range order parameter of any configuration::

            from pyece.core.clex import eCE
            from pyece.core.configurations import Config
            from pyece.montecarlo.properties import SRO

            property_fct = SRO(3.0)
            property_fct.set_calculator(eCE_model.prim, config.get_structure())

    N_uncorrelated_samples: int, default: 50
        Minimum number of uncorrelated samples
    sampling_frequency: int | None, default: None
        Frequency to which samples should be read. If None, this number is set to the number of sites in the configuration divided by the number of changes (N_changes) such that a change on evry site is tried on average.
    N_changes: int, default: 1
        Number of trial changes performed in the proposal occupation at each MC step
    min_samples: int, default: 0
        Minimum number of samples to be computed
    max_samples: int, default: 1000
        Maximum number of samples to be computed
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)
    path_to_result_data: str | None, deafult: None
        Path to save the results of the MC cooling run in the JSON format. If None, the results are not saved in a JSON file but only returned as a dict object once the simulation is completed.
    path_to_raw_data: str | None, deafult: None
        Path to save the raw data of the MC cooling run in gz tar-file format. If None, the raw data are not saved.
    path_to_last_config: str | None, deafult: None
        Path to save the occupation bit-string of the last configurations. If None, the last configurations are not saved.
    verbose: bool, default : True
        Set to True to print information about the MCMC simulation.

    Returns
    -------
    dict
        Dictionary with the output processed data computed at each temperature.
    """
    data: dict = {}
    if path_to_raw_data is not None:
        tar = tarfile.open(path_to_raw_data, "w:gz")
    if path_to_last_config is not None:
        last_occupations = {}

    def merge_dict(dct: dict) -> None:
        data.update(
            {key: data[key] + [dct[key]] if key in data else [dct[key]] for key in dct}
        )
        return

    def save_dict(data: dict, filename: str):
        with open(filename, "w") as f:
            json.dump(data, f)
            f.close()
        tar.add(filename, arcname=basename(filename))
        remove(filename)
        return

    for run_index, temp in enumerate(temperatures):
        if verbose:
            print("\nMC simulation at temperature: %.1f" % temp)
        # Set temperature
        mc.set_temperature(temp)
        mc.initialize_data()

        # Run MCMC at fixed state
        processed_data, timeseries_data = fixed_state(
            mc=mc,
            precision=precision,
            list_properties=list_properties,
            N_uncorrelated_samples=N_uncorrelated_samples,
            sampling_frequency=sampling_frequency,
            N_changes=N_changes,
            min_samples=min_samples,
            max_samples=max_samples,
            confidence=confidence,
            verbose=verbose,
        )

        # Data
        merge_dict(processed_data)
        if "composition" in list(data.keys()):
            data["composition"] = [data["composition"][0]]
        if path_to_result_data is not None:
            with open(path_to_result_data, "w") as f:
                json.dump(data, f, indent=3)
                f.close()
        if path_to_raw_data is not None:
            save_dict(
                timeseries_data,
                join(dirname(path_to_raw_data), "mcmc_cooling_%.1f.json" % temp),
            )
        if path_to_last_config is not None:
            last_occupations["%.1f" % temp] = timeseries_data["occupation"][-1]

    if path_to_raw_data is not None:
        tar.close()
    if path_to_last_config is not None:
        with open(path_to_last_config, "w") as f:
            json.dump(last_occupations, f)
            f.close()
    return data
