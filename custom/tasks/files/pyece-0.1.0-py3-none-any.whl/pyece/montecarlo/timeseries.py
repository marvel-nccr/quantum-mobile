import numpy as np
import statsmodels.api as sm
from numpy.typing import NDArray
from scipy.stats import chi2, kstat, kstatvar, t
from statsmodels.tsa.stattools import acf


def confidence_interval(
    confidence: float, df: int, loc: float, scale: float
) -> list[float]:
    """Compute the confidence interval using the t-statistics (using scipy.stats.t function)

    Parameters
    ----------
    confidence: float
        Degree of confidence
    df: int
        Degree of freedom
    loc: float
        Mean value
    scale: float
        Standard error

    Returns
    -------
    interval: list[float]
        List with the lower and upper limits of the confidence interval
    """
    if abs(scale) < 1e-10:
        interval = [float(0), float(0)]
    else:
        interval = [
            float(lim)
            for lim in t.interval(confidence=confidence, df=df, loc=loc, scale=scale)
        ]
    return interval


def fit_autoregressive_model(
    timeseries: np.ndarray, order: int = 1, maxiter: int = 10
) -> tuple[float, np.ndarray]:
    r"""Returns the parameters of an autoregressive model of order p (AR(p)) defined as:

    .. math:: X_t = \mu + \sum_{q=1}^p \rho_q (X_{t-q} - \mu) + \varepsilon_t \quad \text{with} \quad \varepsilon_i \underset{\mathrm{iid}}{\sim} N(0,\sigma^2)

    where :math:`\mu` is the estimated expected value of the timeseries and the :math:`\rho_q` are the autoregressive parameters. The fit is performed using the Yule-Walker method as implemented in `Statsmodel GLSAR <https://www.statsmodels.org/dev/generated/statsmodels.regression.linear_model.GLSAR.html>`_.

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.
    order: int, default: 1
        Autoregressive order p of the model
    maxiter: int, default: 10
        Maximum number of iterations of the Yule-walker method.

    Returns
    -------
    float
        Estimated expected value
    np.ndarray
        Numpy array with the autoregressive parameters
    """
    T = timeseries.size
    model = sm.GLSAR(timeseries, np.ones([T, 1]), rho=order)
    results = model.iterative_fit(maxiter=maxiter)
    return results.params[0], model.rho


def compute_inefficiency_ACF(
    timeseries: np.ndarray, min_lags: int = 3, fft: bool = True
) -> float:
    r"""Compute the inefficiency factor of a timeseries by computing the autocorrelation function. The inefficiency measures the number of samples that are needed to compute to produce a sample uncorrelated from the first one.

    The inefficiency is computed as:

    .. math:: g_\tau = \sum_{i,j = 1}^T C_{|i-j|} = 1 + \sum_n^{T-1} \Big(1-\frac{n}{T}\Big) C_n \quad \text{(if stationary)}

    where :math:`C_{|i-j|}` denotes the (auto-)correlation between samples with lag :math:`|i-j| = n`. In practice, the sum is broken as soon as the correlations are negative (statistical noise around 0). The autocorrelation function is computed in `Statsmodel acf <https://www.statsmodels.org/stable/generated/statsmodels.tsa.stattools.acf.html>`_.

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.
    min_lags: int, default: 3
        Mininum lags to be considered when computing the inefficiency even if the C_n are smaller than 0.
    fft: bool, default: True
        Set to True to compute the autocorrelation function :math:`C_n` with the Fast-Fourier-Transform algorithm.

    Returns
    -------
    float
        Inefficiency factor.
    """
    T = timeseries.size

    if np.var(timeseries) < 1e-10:
        C_t = np.full(T, np.nan)
    else:
        C_t = acf(timeseries, adjusted=True, nlags=T, fft=fft)

    try:
        max_time = np.max([np.min(np.nonzero(C_t <= 0)[0]), min_lags])
    except Exception:
        max_time = 1

    return max(1 + 2 * ((1 - np.arange(1, max_time) / T) * C_t[1:max_time]).sum(), 1)


def compute_inefficiency_AR1(timeseries: np.ndarray) -> float:
    r"""Compute the inefficiency factor of a timeseries by estimating the autoregressive parameter of order 1. The inefficiency measures the number of samples that are needed to compute to produce a sample uncorrelated from the first one.

    The inefficiency is computed as:

    .. math:: g_\tau = \sum_{i,j = 1}^T C_{|i-j|} = \frac{1+\rho}{1-\rho}

    where :math:`C_{|i-j|}` denotes the (auto-)correlation between samples with lag :math:`|i-j|` and :math:`\rho` is the autoregressive parameter of order 1. The fit is performed using the Yule-Walker method as implemented in `Statsmodel GLSAR <https://www.statsmodels.org/dev/generated/statsmodels.regression.linear_model.GLSAR.html>`_.
    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.

    Returns
    -------
    float
        Inefficiency factor.
    """
    _, rho = fit_autoregressive_model(timeseries, order=1)
    return max((1 + rho[0]) / (1 - rho[0]), 1)


def equilibration_time_mean_difference(
    timeseries: np.ndarray, precision: float, mintime: int = 0, step: int = 1
) -> int:
    r"""Determine the time (index) at which a timeseries can be assumed as equilibrated to some precision (see `Self-driven lattice-model Monte Carlo simulations of alloy thermodynamic properties and phase diagrams <https://iopscience.iop.org/article/10.1088/0965-0393/10/5/304>`_).

    Equilibration with respect to a property :math:`Q` is assumed at time :math:`\tau` when the following inequality is satisfied:

    .. math:: \Delta \bar{Q}(\tau) = | \bar{Q}_{[\tau, (T-\tau)/2]} - \bar{Q}_{[(T-\tau)/2, T]} | \leq p


    where :math:`\bar{Q}_{[t_1, t_2]}` denotes the average of :math:`Q_t` for :math:`t \in [t_1, t_2]` and :math:`p` is the desired precision. Thus, the equilibration time :math:`\tilde{t}` is determined as:

    .. math:: \tilde{t} = \underset{\tau}{\mathrm{argmin}} \Delta \bar{Q}(\tau) \quad \text{that satisfies} \quad \Delta \bar{Q}(\tau) \leq p

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.
    precision: float | list[float]
        Precision to which the timeseries can be considered as equilibrated.
    mintime: int, default: 0
        Minimum time (index) to be considered for equilibration
    step: int, default: 1
        Time step between every evaluation

    Returns
    -------
    time: int
        Time (index) at which the timeseries can be considered as equilibrated.
    """

    if len(timeseries.shape) == 1:
        timeseries = timeseries.reshape(1, -1)

    list_times = []
    for series in timeseries:
        T = series.size
        for time in range(mintime, T, step):
            split_time = np.ceil((T - time) / 2).astype(int) + time
            mean1 = series[time:split_time].mean()
            mean2 = series[split_time:].mean()
            if np.abs(mean1 - mean2) <= precision:
                break
        list_times.append(time)

    time = max(list_times)
    return time


def equilibration_time_ACF(
    timeseries: np.ndarray,
    mintime: int = 0,
    step: int = 1,
    min_lags: int = 3,
    acf: bool = True,
) -> int:
    r"""Determine the time (index) at which a timeseries can be assumed as equilibrated by maximizing the number of effective sample (see `A Simple Method for Automated Equilibration Detection in Molecular Simulations <https://doi.org/10.1021/acs.jctc.5b00784>`_).

    The number of effective uncorrelated samples :math:`N_{eff}` from time :math:`\tau` with respect to a property :math:`Q` is reads as:

    .. math:: N_{eff}(\tau) = \frac{T-\tau}{g_\tau} \quad \text{with} \quad g_\tau = \sum_{i,j = 1}^T C_{|i-j|}

    where :math:`C_{|i-j|}` denotes the correlation between samples with lag :math:`|i-j|`. The so-called inefficiency :math:`g_t` is small only when the timeseries is stationary (equilibrated). Thus, the equilibration time :math:`\tilde{t}` is determined as:

    .. math:: \tilde{t} = \underset{\tau}{\mathrm{argmax}} N_{eff}(\tau)

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.
    mintime: int, default: 0
        Minimum time (index) to be considered for equilibration
    step: int, default: 1
        Time step between every evaluation
    min_lags: int, default: 3
        Mininum lags to be considered when computing the inefficiency even if the C_n are smaller than 0.
    acf: bool, default: True
        Set it to True to compute the inefficiency by computing the autocorrelation function, in opposition to fitting an first-order autoregressive model first and then estimating the inefficiency.

    Returns
    -------
    time: int
        Time (index) at which the timeseries can be considered as equilibrated.
    """

    if len(timeseries.shape) == 1:
        timeseries = timeseries.reshape(1, -1)

    list_times: list[int] = []
    for series in timeseries:
        T = series.size
        Neff = np.zeros(int(np.floor((T - mintime) / step)))
        for time in range(mintime, T - 1, step):
            if acf:
                g = compute_inefficiency_ACF(series[time:], min_lags=min_lags, fft=True)
            else:
                g = compute_inefficiency_AR1(series[time:])
            Neff[time] = (T - time) / np.max([g, 1])
        list_times.append(int(np.argmax(Neff)))

    time = max(list_times)
    return time


def compute_average(
    timeseries: np.ndarray,
    confidence: float = 0.95,
    acf: bool = True,
    min_lags: int = 3,
) -> np.ndarray:
    r"""Returns the mean estimator with confidence interval of a timeseries.

    Given a timeseries :math:`{\hat{X}}` of size :math:`T` with correlated data, the standard error :math:`\hat{\sigma}` reads as:

    .. math:: \hat{\sigma}^2 = \frac{g}{T} \mathbb{Var}[X]

    where :math:`g` is the statistical inefficiency. T-statistics is used to estimate the confidence interval.

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the (stationary) timeseries (it must be a 1D-array)
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)
    acf: bool, default: True
        Set it to True to compute the inefficiency by computing the autocorrelation function, in opposition to fitting an first-order autoregressive model first and then estimating the inefficiency.
    min_lags: int, default: 3
        Mininum lags to be considered when computing the inefficiency even if the C_n are smaller than 0 (if acf is set to True).

    Returns
    -------
    np.ndarray
        Numpy array with 3 entries that are the lower limit of the confidence interval, the average value, and the upper limit of the confidence interval of the mean estimator of the timeseries.
    """

    # Statistical inefficiency
    if acf:
        g = compute_inefficiency_ACF(timeseries, min_lags=min_lags, fft=True)
    else:
        g = compute_inefficiency_AR1(timeseries)

    # Mean estimator
    mean = timeseries.mean()

    # Squared standard error
    standard_error = np.sqrt(timeseries.var(ddof=1) * g / timeseries.size)

    # Confidence interval
    interval = confidence_interval(
        confidence=confidence, df=timeseries.size - 1, loc=mean, scale=standard_error
    )

    return np.array([interval[0], mean, interval[1]])


def get_uncorrelated_indexes(
    timeseries: np.ndarray,
    acf: bool = True,
    min_lags: int = 3,
) -> NDArray[np.int_]:
    r"""Returns the indexes of uncorrelated samples of the timeseries.

    Given a timeseries with :math:`T` samples, the number of uncorrelated samples (effective samples) is given by :math:`T/g` where :math:`g` is the inefficiency.

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the (stationary) timeseries. If the time series is a 2D-array, considers the row with the largest inefficiency
    acf: bool, default: True
        Set it to True to compute the inefficiency by computing the autocorrelation function, in opposition to fitting an first-order autoregressive model first and then estimating the inefficiency.
    min_lags: int, default: 3
        Mininum lags to be considered when computing the inefficiency even if the C_n are smaller than 0 (if acf is set to True).

    Returns
    -------
    indexes: np.ndarray[Any, int]
        Time (index) at which the timeseries can be considered as equilibrated.
    """

    # Statistical inefficiency
    if len(timeseries.shape) == 1:
        T = timeseries.size
        if acf:
            g = compute_inefficiency_ACF(timeseries, min_lags=min_lags, fft=True)
        else:
            g = compute_inefficiency_AR1(timeseries)
    else:
        T = timeseries.shape[-1]
        g_values: list[float] = []
        for series in timeseries:
            if acf:
                g_values.append(
                    compute_inefficiency_ACF(series, min_lags=min_lags, fft=True)
                )
            else:
                g_values.append(compute_inefficiency_AR1(series))
        g = float(np.max(g_values))
    g = float(np.max([g, 1]))

    # Subsampling
    Neff = int(np.floor(T / g)) + 1
    indexes = np.rint(g * np.arange(Neff)).astype(int)
    indexes = indexes[indexes < T]
    indexes += T - 1 - indexes[-1]

    return indexes


def compute_estimators_uncorrelated(
    timeseries: np.ndarray,
    confidence: float = 0.95,
) -> tuple:
    r"""Compute the mean and covariance estimators with confidence intervals, assuming uncorrelated data.

    The mean and the covariance estimators, as well as their confidence intervals, are estimated using the t-statistics (means and covariances) and chi2-statistics (variances).

    Parameters
    ----------
    timeseries: np.ndarray
        Numpy array with the timeseries.
    confidence: float, default: 0.95
        Level of confidence (i.e., a confidence of 0.95 means that there is a statistical probability of 95% that the true value lies within the confidence interval)

    Returns
    -------
    mean_vector: np.ndarray
        2D-numpy array where the first dimension corresponds a vector of mean estimators (one for each series in the timeseries), the last dimension is composed of 3 entries that are the lower limit of the confidence interval, the average value, and the upper limit of the confidence interval of the estimator.
    covariance_matrix: np.ndarray
        3D-numpy array where the first two dimensions correspond to the covariance matrix, the last dimension is composed of 3 entries that are the lower limit of the confidence interval, the average value, and the upper limit of the confidence interval of the estimator.
    """
    dim = len(timeseries.shape)
    if dim == 1:
        timeseries = timeseries.reshape(1, -1)
    M = timeseries.shape[0]
    N = timeseries.shape[1]

    mean_vector = np.zeros([M, 3])
    covariance_matrix = np.zeros([M, M, 3])
    covariance = np.cov(timeseries, ddof=1)
    for ind_i, series in enumerate(timeseries):
        mean = kstat(series, n=1)
        variance = kstat(series, n=2)
        mean_standard_error = float(np.sqrt(kstatvar(series, n=1)))
        # variance_standard_error = np.sqrt(kstatvar(series, n=2))

        # Mean
        interval = confidence_interval(
            confidence=confidence, df=N - 1, loc=mean, scale=mean_standard_error
        )
        mean_vector[ind_i] = [interval[0], mean, interval[1]]

        # Variance
        a = chi2.ppf((1 - confidence) / 2, df=N - 1)
        b = chi2.ppf(1 - (1 - confidence) / 2, df=N - 1)
        interval = [(N - 1) * variance / b, (N - 1) * variance / a]
        covariance_matrix[ind_i, ind_i] = [interval[0], variance, interval[1]]

        # Covariances
        for ind_j in np.arange(ind_i + 1, M):
            X = (series - mean) * (timeseries[ind_j] - timeseries[ind_j].mean())
            interval = confidence_interval(
                confidence=confidence,
                df=N - 2,
                loc=covariance[ind_i, ind_j],
                scale=np.sqrt(
                    ((X - covariance[ind_i, ind_j]) ** 2).sum() / (N - 2) / N
                ),
            )
            if ind_i != ind_j:
                covariance_matrix[ind_i, ind_j] = [
                    interval[0],
                    covariance[ind_i, ind_j],
                    interval[1],
                ]
                covariance_matrix[ind_j, ind_i] = [
                    interval[0],
                    covariance[ind_j, ind_i],
                    interval[1],
                ]

    return mean_vector, covariance_matrix
