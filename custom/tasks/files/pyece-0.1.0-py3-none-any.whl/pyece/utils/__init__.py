"""Utility functions for coordinate transforms, structure mapping, and symmetry."""
