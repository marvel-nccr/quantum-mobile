r"""
This module serves as tool to convert arrays from one type of coordinates to another.

There are basically 4 different types of coordinates (See :doc:`description`):
 - ``Cartesian``: Coordinate representation in a Euclidean space formed by orthonormal vectors. The coordinate system is independent of the lattice/unitcell. No conversion function from cartesian to fractional coordinates is implemented in this module. However, it is handled in the :obj:`Lattice` object from Pymatgen (see `get_fractional_coords <https://pymatgen.org/pymatgen.core.html#pymatgen.core.lattice.Lattice.get_fractional_coords>`_ and `get_cartesian_coords <https://pymatgen.org/pymatgen.core.html#pymatgen.core.lattice.Lattice.get_cartesian_coords>`_)
 - ``Fractional``: Coordinate representation in a space formed by the lattice vectors. Given the lattice matrix formed by the lattice vectors :math:`L=[\vec{a} \; \vec{b} \; \vec{c}]` and the cartesian coordiantes :math:`\vec{x}`, the fractional coordiantes :math:`\vec{f}` are defined as :math:`\vec{x} = L \vec{f}`. Hence fractional coordinates comprised between 0 and 1 correspond to a point within the unitcell.
 - ``Unitcell``: On-lattice coordinate representation that is defined by the cell coordinates and the basis index. Knowing that a point :math:`\vec{f}` corresponds to a lattice site, it is sufficient to know the coordinates of the cell :math:`\vec{n}`, which is defined by a integer vector in fractional coordiantes, and the corresponding `i`'th basis site with fractional coordinates :math:`\vec{b}_i` relative to this cell, such that :math:`\vec{f} = \vec{n} + \vec{b}_i`. The first 3 coordinates correspond to the cell coordinates, while the last coordinate refers to the index of the basis.
 - ``Affine``: Coordinate representation to incorporate translation transformation in addition to unual rotation transformations. It basically consists in adding a `1` to the space coordinates. Refer to the `Wikipedia` page `Affine transformation <https://wikipedia.org/wiki/Affine_transformation>`_.

Warning
-------
All arrays respect the row-wise convention.
"""

import numpy as np
from numpy.typing import NDArray

from pyece.utils import toolbox


def unitcell_to_fractional(
    unitcell_array: NDArray[np.int_],
    fractional_basis: np.ndarray,
) -> np.ndarray:
    """
    Converts an array of unitcell coordinates into an array of fractional coordinates

    Parameters
    ----------
    unitcell_array: np.ndarray[int]
        Numpy array of unitcell coordinates to be converted

        Warning
        -------
        The array's innermost dimension is expected to be 4 (3 dimensional space + 1 basis index).

    fractional_basis: np.ndarray
        Numpy array of fractional coordinates of the basis positions within the unitcell.

        Warning
        -------
        The array's innermost dimension is expected to be 3 (3 dimensional space).

        Tip
        ---
        This parameter typically corresponds to the :py:attr:`~.pyece.core.prim.Prim.basis` attribute of :py:obj:`~.pyece.core.prim.Prim` objects.

    Returns
    -------
    fractional_array: np.ndarray
        Numpy array of fractional coordinates

        Note
        -------
        The array's innermost dimension is 3 (3 dimensional space).

    Example
    -------
    The following snippets illustrate several common systems::

        >>> import numpy as np
        >>> from pyece.utils.coordinates import unitcell_to_fractional

        >>> # BCC lattice
        >>> basis = np.array([[0, 0, 0]])
        >>> array = np.array([[[1, 0, 0, 0],
        ...                    [0, 1, 0, 0]],
        ...                   [[0, 0, 1, 0],
        ...                    [0, 1, 2, 0]]])
        >>> unitcell_to_fractional(array, basis)
        np.array([[[1, 0, 0],
                   [0, 1, 0]],
                  [[0, 0, 1],
                   [0, 1, 2]]])

        >>> # Omega lattice
        >>> basis = np.array([[0.000, 0.000, 0.000],
        ...                   [0.333, 0.333, 0.500],
        ...                   [0.667, 0.667, 0.500]])
        >>> cell_coords = np.array([[ 0,  2,  0],
        ...                         [ 1,  0,  1],
        ...                         [ 0,  2, -1],
        ...                         [-1, -1,  1]])
        >>> basis_indexes = np.array([1, 0, 2, 1])
        >>> array = np.hstack([cell_coords, basis_index.reshape(-1, 1)])
        >>> array
        np.array([[[ 0,  2,  0,  1],
                   [ 1,  0,  1,  0],
                   [ 0,  2, -1,  2],
                   [-1, -1,  1,  1]])
        >>> unitcell_to_fractional(array, basis)
        np.array([[ 0.333,  2.333,  0.500],
                  [ 1.000,  0.000,  1.000],
                  [ 0.667,  2.667, -0.500],
                  [-0.667, -0.667,  1.500]])
    """

    assert (
        unitcell_array.shape[-1] == 4
    ), "The unitcell_array is in unitcell coordinates and is required to have a last dimension of size 4."

    # Shape of the fractional array
    shape = list(unitcell_array.shape)
    shape[-1] = 3

    # fractional array
    fractional_array = (
        np.take(unitcell_array, [0, 1, 2], axis=-1)
        + fractional_basis[np.take(unitcell_array, 3, axis=-1)]
    )

    return fractional_array


def fractional_to_unitcell(
    fractional_array: np.ndarray,
    fractional_basis: np.ndarray,
    decimals: int = 6,
) -> NDArray[np.int_]:
    """
    Converts an array of fractional coordinates into an array of unitcell coordinates

    Parameters
    ----------
    fractional_array: np.ndarray
        Numpy array of fractional coordinates to be converted

        Warning
        -------
        The array's innermost dimension is expected to be 3 (3 dimensional space).

    fractional_basis: np.ndarray
        Numpy array of fractional coordinates of the basis positions within the unitcell.

        Warning
        -------
        The array's innermost dimension is expected to be 3 (3 dimensional space).

        Tip
        ---
        This parameter typically corresponds to the :py:attr:`~.pyece.core.prim.Prim.basis` attribute of :py:obj:`~.pyece.core.prim.Prim` objects.

    decimals: int, default: 6
        Number of decimals to be round off

    Returns
    -------
    unitcell_array: np.ndarray[int]
        Numpy array of unitcell coordinates

        Note
        ----
        The array's innermost dimension is 4 (3 dimensional space + 1 basis index).

    Example
    -------
    The following snippets illustrate several common systems::

        >>> import numpy as np
        >>> from pyece.utils.coordinates import fractional_to_unitcell

        >>> # BCC lattice
        >>> basis = np.array([[0, 0, 0]])
        >>> array = np.array([[[1, 0, 0],
        ...                    [0, 1, 0]],
        ...                   [[0, 0, 1],
        ...                    [0, 1, 2]]])
        >>> fractional_to_unitcell(array, basis)
        np.array([[[1, 0, 0, 0],
                   [0, 1, 0, 0]],
                  [[0, 0, 1, 0],
                   [0, 1, 2, 0]]])

        >>> # Omega lattice
        >>> basis = np.array([[0.000, 0.000, 0.000],
        ...                   [0.333, 0.333, 0.500],
        ...                   [0.667, 0.667, 0.500]])
        >>> cell_coords = np.array([[ 0,  2,  0],
        ...                         [ 1,  0,  1],
        ...                         [ 0,  2, -1],
        ...                         [-1, -1,  1]])
        >>> basis_indexes = np.array([1, 0, 2, 1])
        >>> array = cell_coords + np.take(basis, basis_index, axis=0)
        >>> array
        np.array([[ 0.333,  2.333,  0.500],
                  [ 1.000,  0.000,  1.000],
                  [ 0.667,  2.667, -0.500],
                  [-0.667, -0.667,  1.500]])
        >>> fractional_to_unitcell(array, basis)
        np.array([[[ 0,  2,  0,  1],
                   [ 1,  0,  1,  0],
                   [ 0,  2, -1,  2],
                   [-1, -1,  1,  1]])
    """

    def check_conversion(
        fractional_array: np.ndarray,
        unitcell_array: np.ndarray,
        fractional_basis: np.ndarray,
        tol: float,
    ) -> None:
        """
        Check fractional coordinates
        """
        new_fractional_array = unitcell_to_fractional(unitcell_array, fractional_basis)
        comparison = np.allclose(fractional_array, new_fractional_array, atol=tol)
        if not comparison:
            print(fractional_array)
            print(new_fractional_array)
            raise ValueError(
                "Conversion from fractional to unitcell coordinates do NOT yield consistant results"
            )
        return

    assert (
        fractional_array.shape[-1] == 3
    ), "The fractional_array is in fractional coordinates and is required to have a last dimension of size 3."

    # Shape of the unitcell array
    shape = list(fractional_array.shape)
    shape[-1] = 4

    # Determine basis and translations
    centered_array = toolbox.within(fractional_array, decimals)
    translation = np.around(fractional_array - centered_array, decimals).astype(int)
    basis = np.repeat(
        np.expand_dims(centered_array, axis=-2), repeats=len(fractional_basis), axis=-2
    )
    indexes = np.nonzero(
        np.linalg.norm(basis - fractional_basis, axis=-1) < 10**-decimals
    )[-1]
    if len(indexes) != np.prod(shape[:-1]):
        raise RuntimeError(
            "Impossible to match fractional coordinates with the basis coordiantes. Try to increase the tolerence by decreasing the number of decimals."
        )

    # unitcell array
    unitcell_array = np.hstack(
        [translation.reshape(-1, 3), indexes.reshape(-1, 1)], dtype=int
    ).reshape(shape)

    # check conversion
    check_conversion(fractional_array, unitcell_array, fractional_basis, 10**-decimals)

    return unitcell_array


def to_affine(array: np.ndarray) -> np.ndarray:
    """
    Transform an array to affine by adding a column of 1

    Parameters
    ----------
    array: np.ndarray
        Numpy array to be transformed. The coordinates can be of cartesian or fractional type.

    Returns
    -------
    affine_array: np.ndarray
        Numpy array

    Example
    -------
    Example of an array of coordinates converted to affine::

        >>> import numpy as np
        >>> from pyece.utils.coordinates import to_affine

        >>> array = np.array([[[  0.000,  0.000,  0.000],
        ...                    [  0.333, -0.200, -0.700]],
        ...                   [[  0.600,  0.167, -0.500],
        ...                    [ -1.300,  0.666,  0.700]]])
        >>> to_affine(array)
        np.array([[[  0.000,  0.000,  0.000,  1.000],
                   [  0.333, -0.200, -0.700,  1.000]],
                  [[  0.600,  0.167, -0.500,  1.000],
                   [ -1.300,  0.666,  0.700,  1.000]]])
    """

    shape = list(array.shape)
    shape[-1] = 1
    affine_array = np.concatenate((array, np.ones_like(array, shape=shape)), axis=-1)
    return affine_array


def from_affine(affine_array: np.ndarray) -> np.ndarray:
    """
    Transform an affine array to non-affine by removing the column of 1

    Parameters
    ----------
    affine_array: np.ndarray
        Numpy array to be transformed. The coordinates can be of cartesian or fractional type.

        Warning
        -------
        The last entry of the innermost dimension is expected to be 1.

    Returns
    -------
    array: np.ndarray
        Numpy array

    Example
    -------
    Example of an array of coordinates converted from affine::

        >>> import numpy as np
        >>> from pyece.utils.coordinates import from_affine

        >>> array = np.array([[[  0.000,  0.000,  0.000,  1.000],
        ...                    [  0.333, -0.200, -0.700,  1.000]],
        ...                   [[  0.600,  0.167, -0.500,  1.000],
        ...                    [ -1.300,  0.666,  0.700,  1.000]]])
        >>> from_affine(array)
        np.array([[[  0.000,  0.000,  0.000],
                   [  0.333, -0.200, -0.700],
                  [[  0.600,  0.167, -0.500],
                   [ -1.300,  0.666,  0.700]]])
    """

    assert np.allclose(
        np.take(affine_array, -1, axis=-1), 1
    ), "The array is affine and requires to have 1 as last coordinate in the lowest dimension."

    return affine_array[..., :-1]
