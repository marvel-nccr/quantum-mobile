r"""
This module serves as tool to map structures to orderings on the primitive lattice.

Mapping a child structure to a parent structure is a two-step process (see `Comparing crystal structures with symmetry and geometry <https://www.nature.com/articles/s41524-021-00627-0>`_ for a detailed explaination):

**1) Matching the lattice:** The parent lattice :math:`L` and the child supercell lattice :math:`S` are related to each other by an interger transformation matrices :math:`T` (so that the number of atoms in each structure matches), and a deformation matrix :math:`F` such that:

.. math:: T \cdot L = S \cdot F

**2) Matching the atomic sites:** Once the lattices match each other by deformation of the child structure, matching the atomic sites is performed by minimizing the distances separating the sites in the parent and child structures. The task is essentially performed by applying the `Hungarian algorithm <https://en.wikipedia.org/wiki/Hungarian_algorithm>`_.

Warning
-------
All equations and arrays respect the row-wise convention.
"""

import warnings
from typing import Callable

import numpy as np
from numpy.typing import NDArray
from pymatgen.core import Lattice, Structure
from scipy.optimize import linear_sum_assignment

from pyece.core.prim import Prim


def volumetric_factor(child_structure: Structure, parent_structure: Structure) -> float:
    """Determines the factor by which each lattice parameter of the child structure must be multiplied so that the volumes of the child and parent structure match.

    Parameters
    ----------
    child_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to be mapped.
    parent_structure: Structure
        Reference `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_.

        Tip
        ---
        This structure is typically your :py:obj:`~.pyece.core.prim.Prim` structure.

    Returns
    -------
    factor: float
    """
    child_volume = child_structure.volume / len(child_structure)
    parent_volume = parent_structure.volume / len(parent_structure)
    factor = np.cbrt(parent_volume / child_volume)
    return factor


def ideal_map(
    structure: Structure, prim: Prim
) -> tuple[Structure, NDArray[np.int_], np.ndarray, np.ndarray]:
    r"""
    Maps a structure to the prim assuming the structure is ideal (i.e., no lattice deformation (except volumetric in case no vacancy is considered) and no atomic displacement) and therefore uniquely corresponds to a supercell transformation of the prim.

    This mapping algorithm assumes that there is no deformation such that :math:`F=I`, with :math:`I` being the identity matrix. Therefore, the transformation matrix :math:`T` is an **integer** matrix defined as:

    .. math:: T = S \cdot L^{-1}

    and that all atomic sites can be translated to a site in the primitive structure ``prim`` by an **integer** vector in fractional coordinates (relative to the primitive lattice vectors).

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure)
    prim: Prim
        Prim object containing all references to the lattice (parent structure)

    Returns
    -------
    mapped_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ after mapping
    transformation: np.ndarray[int]
        Integer numpy array of the supercell transformation from the Prim to the stucture (in row-wise convention)
    deformation: np.ndarray
        Numpy array of deformation tensor from the Prim to the stucture (in row-wise convention)
    displacements: np.ndarray
        Numpy array of the displacement from the sites in Prim to the sites in the stucture (in row-wise convention)

    Note
    ----
    In case the system do not account for vacancies, the volumetric strain can be evaluated by equating the average atomic volume. However, in the case vacancies are accepted, the number of vacancies is a priori not known and the atomic volume cannot be determined.

    Example
    -------
    This example displays the mapping of an ideal B2 supercell with a volumetric strain of 0.5 onto the BCC lattice::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.utils.mapping import ideal

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[['Fe','Al']])

        >>> # Ideal B2 supercell with volumetric strain of 0.5
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = (transformation @ bcc_lattice) * np.cbrt(0.5 + 1)
        >>> positions = np.array([[0, 0, 0], [0.5, 0.5, 0.5]])

        >>> # Structure to be mapped
        >>> structure = structure = Structure(lattice, ["Fe", "Al"], positions)

        >>> # Mapping
        >>> mapping = ideal_map(structure, bcc)
        >>> # Mapped structure
        >>> print(mapping[0])
        >>> # Transformation
        >>> mapping[1]
        array([[0, 1, 1],
               [1, 0, 1],
               [1, 1, 0]])
    """

    # Get supercell stransformation
    # -----------------------------

    factor = (
        volumetric_factor(structure, prim.structure)
        if "Va" not in prim.elements
        else 1.0
    )
    transformation = prim.get_supercell_transformation(
        structure.lattice.matrix * factor
    )
    mapped_structure = prim.structure.make_supercell(
        transformation, to_unit_cell=True, in_place=False
    )
    deformation = np.identity(3) * factor

    # Map atomic positions
    # --------------------

    distance_matrix = structure.lattice.get_all_distances(
        structure.frac_coords, mapped_structure.frac_coords
    )
    assignment = np.nonzero(distance_matrix < 10**-prim.accuracy)

    if len(np.unique(assignment[0])) != len(np.unique(assignment[0])):
        raise RuntimeError("Some atoms are assigned to the same atomic site")

    # Map species
    # -----------

    vac_counter = 0
    for site_index, permitted_species in enumerate(
        mapped_structure.site_properties["permitted_species"]
    ):
        match_index = np.nonzero(assignment[1] == site_index)[0]

        if len(match_index):
            structure_index = assignment[0][match_index[0]]
            label = structure.labels[structure_index]
            if label in permitted_species:
                mapped_structure.replace(
                    site_index,
                    label,
                    label=label,
                    properties={"index": structure_index},
                )
            else:
                raise RuntimeError("Atomic mapping of the species is not permitted.")

        else:
            label = "Va"
            if label in permitted_species:
                mapped_structure.replace(
                    site_index,
                    "X",
                    label=label,
                    properties={"index": len(assignment[0]) + vac_counter},
                )
                vac_counter += 1
            else:
                raise RuntimeError("Vacancy detected that is not permitted.")
    mapped_structure.sort(lambda x: x.properties["index"])

    return mapped_structure, transformation, deformation, distance_matrix[assignment]


def quick_map(
    structure: Structure,
    prim: Prim,
) -> tuple[Structure, NDArray[np.int_], np.ndarray, np.ndarray]:
    r"""
    Maps a structure to the prim by assuming small perturbations to an ideal supercell from the prim (quick).
    This method is particularly well-suited for structures resulting from relaxation calculations.

    This mapping algorithm assumes that small deformations such that the deformation matrix can be written as :math:`F=I+dF` with :math:`I` being the identity matrix and :math:`dF` a matrix whose elements are small. Under this assumption, the transformation matrix :math:`T` and the deformation matrix :math:`F` are evaluated as:

    .. math:: T \cdot L = S \cdot F = S + S \cdot dF

    If we define the following matrices:

    .. math:: T' = S \cdot L^{-1}
    .. math:: dT = S \cdot dF \cdot L^{-1}

    The transformation matrix :math:`T` can be rewritten as:

    .. math:: T = T' + dT

    As a consequence of the assumption of small deformations, the matrix :math:`dT` is expected to be small as well. As a result, rounding the elements of the matrix :math:`T'` to the closest integers is expected to yield the transformation matrix :math:`T`.

    The atomic site mapping is performed using the `Hungarian algorithm <https://en.wikipedia.org/wiki/Hungarian_algorithm>`_ assuming no common rigid translation of all child atoms.

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure)
    prim: Prim
        Prim object containing all references to the lattice (parent structure)

    Returns
    -------
    mapped_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ after mapping
    transformation: np.ndarray[int]
        Integer numpy array of the supercell transformation from the Prim to the stucture (in row-wise convention)
    deformation: np.ndarray
        Numpy array of deformation tensor from the Prim to the stucture (in row-wise convention)
    displacements: np.ndarray
        Numpy array of the displacement from the sites in Prim to the sites in the stucture (in row-wise convention)

    Note
    ----
    In case the system do not account for vacancies, the volumetric strain can be evaluated by equating the average atomic volume. However, in the case vacancies are accepted, the number of vacancies is a priori not known and the atomic volume cannot be determined.

    Example
    -------
    This example displays the mapping of a slightly deformed B2 supercell onto the BCC lattice::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.utils.mapping import quick_map

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[['Fe','Al']])

        >>> # Ideal B2 supercell
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice
        >>> positions = np.array([[0, 0, 0], [0.5, 0.5, 0.5]])

        >>> # Perturbations
        >>> deformation = np.identity(3) + np.random.randn(3, 3) * 0.1
        >>> deformation
        np.array([[ 1.17640523,  0.04001572,  0.09787380],
                  [ 0.22408932,  1.18675580, -0.09772779],
                  [ 0.09500884, -0.01513572,  0.98967811]])
        >>> displacements = np.random.randn(2, 3)
        >>> displacement
        np.array([[0.41059850, 0.14404357, 1.45427351],
                  [0.76103773, 0.12167502, 0.44386323]])
        >>> np.linalg.norm(displacements, axis=1)
        np.array([1.51797599, 0.88938057])

        >>> # Structure to be mapped
        >>> structure = Structure(
        ...     lattice @ np.linalg.inv(deformation),
        ...     ["Fe", "Al"],
        ...     positions + displacements,
        ... )

        >>> # Mapping
        >>> mapping = quick_map(structure, bcc)
        >>> # Mapped structure
        >>> print(mapping[0])
        >>> # Transformation
        >>> mapping[1]
        array([[0, 1, 1],
               [1, 0, 1],
               [1, 1, 0]])
        >>> # Deformation
        >>> mapping[2]
        np.array([[ 1.17640523,  0.04001572,  0.09787380],
                  [ 0.22408932,  1.18675580, -0.09772779],
                  [ 0.09500884, -0.01513572,  0.98967811]])
        >>> # Displacements
        >>> mapping[3]
        np.array([1.51797599, 0.88938057])
    """

    structure_copy = structure.copy()

    # Determine tranformation and deformation matrices
    # ------------------------------------------------

    factor = (
        volumetric_factor(structure, prim.structure)
        if "Va" not in prim.elements
        else 1.0
    )

    structure_copy.lattice = Lattice(structure_copy.lattice.matrix * factor)
    transformation_deformation_LLL_lattice = (
        structure_copy.lattice.matrix @ np.linalg.inv(prim.lattice.lll_matrix)
    )
    transformation = (
        np.rint(transformation_deformation_LLL_lattice) @ prim.lattice.lll_mapping
    ).astype(int)

    deformation = (
        np.linalg.inv(structure_copy.lattice.matrix)
        @ transformation
        @ prim.lattice.matrix
    )

    if (
        np.around(np.abs(np.linalg.det(transformation))).astype(int) * len(prim.basis)
    ) < len(structure_copy):
        raise RuntimeError("Transformation found cannot accomodate all atoms.")

    mapped_structure = prim.structure.make_supercell(
        transformation, to_unit_cell=True, in_place=False
    )
    structure_copy.lattice = Lattice(structure_copy.lattice.matrix @ deformation)

    # Determine displacement
    # ----------------------

    distance_matrix = structure_copy.lattice.get_all_distances(
        structure_copy.frac_coords, mapped_structure.frac_coords
    )
    assignment = linear_sum_assignment(distance_matrix)

    # Map species
    # -----------

    vac_counter = 0
    for site_index, permitted_species in enumerate(
        mapped_structure.site_properties["permitted_species"]
    ):
        match_index = np.nonzero(assignment[1] == site_index)[0]

        if len(match_index):
            structure_index = assignment[0][match_index[0]]
            label = structure_copy.labels[structure_index]
            if label in permitted_species:
                mapped_structure.replace(
                    site_index,
                    label,
                    label=label,
                    properties={"index": structure_index},
                )
            else:
                raise RuntimeError("Atomic mapping of the species is not permitted.")

        else:
            label = "Va"
            if label in permitted_species:
                mapped_structure.replace(
                    site_index,
                    "X",
                    label=label,
                    properties={"index": len(assignment[0]) + vac_counter},
                )
                vac_counter += 1
            else:
                raise RuntimeError("Vacancy detected that is not permitted.")
    mapped_structure.sort(lambda x: x.properties["index"])

    return (
        mapped_structure,
        transformation,
        deformation * factor,
        distance_matrix[assignment],
    )


def quick_var_map(
    structure: Structure,
    prim: Prim,
) -> tuple[Structure, NDArray[np.int_], np.ndarray, np.ndarray]:
    r"""
    Maps a structure to the prim by assuming small perturbations to an ideal supercell from the prim (quick).
    The atomic mapping is done in a more robust manner than in quick_map.
    This method is particularly well-suited for structures resulting from relaxation calculations

    This mapping algorithm assumes that small deformations such that the deformation matrix can be written as :math:`F=I+dF` with :math:`I` being the identity matrix and :math:`dF` a matrix whose elements are small. Under this assumption, the transformation matrix :math:`T` and the deformation matrix :math:`F` are evaluated as:

    .. math:: T \cdot L = S \cdot F = S + S \cdot dF

    If we define the following matrices:

    .. math:: T' = S \cdot L^{-1}
    .. math:: dT = S \cdot dF \cdot L^{-1}

    The transformation matrix :math:`T` can be rewritten as:

    .. math:: T = T' + dT

    As a consequence of the assumption of small deformations, the matrix :math:`dT` is expected to be small as well. As a result, rounding the elements of the matrix :math:`T'` to the closest integers is expected to yield the transformation matrix :math:`T`.

    The atomic site mapping is performed using the `Hungarian algorithm <https://en.wikipedia.org/wiki/Hungarian_algorithm>`_ assuming common rigid translation of all child atoms.

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure)
    prim: Prim
        Prim object containing all references to the lattice (parent structure)

    Returns
    -------
    mapped_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ after mapping
    transformation: np.ndarray[int]
        Integer numpy array of the supercell transformation from the Prim to the stucture (in row-wise convention)
    deformation: np.ndarray
        Numpy array of deformation tensor from the Prim to the stucture (in row-wise convention)
    displacements: np.ndarray
        Numpy array of the displacement from the sites in Prim to the sites in the stucture (in row-wise convention)

    Note
    ----
    In case the system do not account for vacancies, the volumetric strain can be evaluated by equating the average atomic volume. However, in the case vacancies are accepted, the number of vacancies is a priori not known and the atomic volume cannot be determined.

    Warning
    -------
    This mapping function requires functions from the `tofa` package.

    Example
    -------
    This example displays the mapping of a slightly deformed B2 supercell onto the BCC lattice::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.utils.mapping import quick_var_map

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[['Fe','Al']])

        >>> # Ideal B2 supercell
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice
        >>> positions = np.array([[0, 0, 0], [0.5, 0.5, 0.5]])

        >>> # Perturbations
        >>> deformation = np.identity(3) + np.random.randn(3, 3) * 0.1
        >>> deformation
        np.array([[ 1.17640523,  0.04001572,  0.09787380],
                  [ 0.22408932,  1.18675580, -0.09772779],
                  [ 0.09500884, -0.01513572,  0.98967811]])
        >>> displacements = np.random.randn(2, 3)
        >>> displacement
        np.array([[0.41059850, 0.14404357, 1.45427351],
                  [0.76103773, 0.12167502, 0.44386323]])
        >>> # Removing the rigid translation common to all sites
        >>> np.linalg.norm(displacements - np.mean(displacements, axis=0), axis=1)
        np.array([0.53484505, 0.53484505])

        >>> # Structure to be mapped
        >>> structure = Structure(
        ...     lattice @ np.linalg.inv(deformation),
        ...     ["Fe", "Al"],
        ...     positions + displacements,
        ... )

        >>> # Mapping
        >>> mapping = quick_var_map(structure, bcc)
        >>> # Mapped structure
        >>> print(mapping[0])
        >>> # Transformation
        >>> mapping[1]
        array([[0, 1, 1],
               [1, 0, 1],
               [1, 1, 0]])
        >>> # Deformation
        >>> mapping[2]
        np.array([[ 1.17640523,  0.04001572,  0.09787380],
                  [ 0.22408932,  1.18675580, -0.09772779],
                  [ 0.09500884, -0.01513572,  0.98967811]])
        >>> # Displacements
        >>> mapping[3]
        np.array([0.53484505, 0.53484505])
    """
    try:
        from tofa.mapping import mapping, metrics
    except ModuleNotFoundError as exc:
        raise ImportError(
            "The 'tofa' package is required for utils.mapping but is not installed."
        ) from exc

    structure_copy = structure.copy()

    # Determine tranformation and deformation matrices
    # ------------------------------------------------

    factor = (
        volumetric_factor(structure, prim.structure)
        if "Va" not in prim.elements
        else 1.0
    )
    structure_copy.lattice = Lattice(structure_copy.lattice.matrix * factor)
    transformation_deformation = structure_copy.lattice.matrix @ np.linalg.inv(
        prim.lattice.matrix
    )
    transformation = np.around(transformation_deformation, 0).astype(int)

    if (
        np.around(np.abs(np.linalg.det(transformation))).astype(int) * len(prim.basis)
    ) < len(structure_copy):
        raise RuntimeError("Transformation found cannot accomodate all atoms.")

    deformation = (
        np.linalg.inv(structure_copy.lattice.matrix)
        @ transformation
        @ prim.lattice.matrix
    )

    mapped_structure = prim.structure.make_supercell(
        transformation, to_unit_cell=True, in_place=False
    )
    structure_copy.lattice = Lattice(structure_copy.lattice.matrix @ deformation)
    vacancies = len(mapped_structure) - len(structure_copy)

    # Determine displacement
    # ----------------------

    atomic_costs, frac_displacements, list_assignments = mapping.atomic_mapping(
        mapped_structure, structure_copy
    )

    arg_min = np.argmin(atomic_costs)
    displacement = np.zeros(len(mapped_structure))
    displacement[: len(structure_copy)] = np.linalg.norm(
        frac_displacements[arg_min] @ mapped_structure.lattice.matrix, axis=-1
    )
    if not np.allclose(
        metrics.displacement_cost(displacement, mapped_structure),
        atomic_costs[arg_min],
    ):
        print(
            "Displacement: ",
            metrics.displacement_cost(displacement, mapped_structure),
            atomic_costs[arg_min],
            "\nVacancies: ",
            vacancies,
        )
        raise RuntimeError(
            "The displacement does not yield the same atomic cost as the mapping function."
        )

    # Map species
    # -----------

    assignment = list_assignments[arg_min]
    for parent_assignment, child_assignment in zip(assignment[1], assignment[0]):
        if child_assignment < len(structure_copy):
            label = structure_copy.labels[child_assignment]
        else:
            label = "Va"
        mapped_structure.replace(
            parent_assignment, "X" if label == "Va" else label, label=label
        )

    return mapped_structure, transformation, deformation * factor, displacement


def robust_map(
    structure: Structure,
    prim: Prim,
    vac_concentration_max: float = 0.0,
    vac_concentration_min: float = 0.0,
    fixed_size: bool = True,
    lattice_weight: float = 0.5,
    unique: bool = False,
    symprec: float = 0.01,
    angle_tolerance: float = 0.1,
) -> tuple[Structure, NDArray[np.int_], np.ndarray, np.ndarray]:
    r"""
    Robustly maps a structure to the prim (slow but robust).
    This method is particularly well-suited for structures resulting from strong relaxation.

    This mapping implements the algorithm described in `Comparing crystal structures with symmetry and geometry <https://www.nature.com/articles/s41524-021-00627-0>`_.

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure)
    prim: Prim
        Prim object containing all references to the lattice (parent structure)
    vac_concentration_max: float, default: 0.0
        Maximum vacancy concentration allowed in the child structure.
    vac_concentration_min: float, default: 0.0
        Minimum vacancy concentration allowed in the child structure.
    fixed_size: bool, default: True
        Set to True if the structure is not permitted to change, i.e., if supercells of the structure should not be consdered.

        If True, the algorithm solves the equation :math:`T \cdot L = S \cdot F`.
        Otherwise, it solves the equation :math:`T \cdot L = T' \cdot S \cdot F`,
        where a supercell transformation is applied to both structures (:math:`T` to :math:`L` and :math:`T'` to :math:`S`) in orther to find supercells with the same number of atoms.

    lattice_weight: float, default: 0.5
        Weighting factor ([0,1]) for the lattice mapping cost in the total cost calculation.
    unique: bool, default: False
        If set to True, returns an error if multiple mapping exists with the same minimum cost
    symprec: float, default: 0.01
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.
    angle_tolerance: float, default: 0.1
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.

    Returns
    -------
    mapped_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ after mapping
    transformation: np.ndarray[int]
        Integer numpy array of the supercell transformation from the Prim to the stucture (in row-wise convention)
    deformation: np.ndarray
        Numpy array of deformation tensor from the Prim to the stucture (in row-wise convention)
    displacements: np.ndarray
        Numpy array of the displacement from the sites in Prim to the sites in the stucture (in row-wise convention)

    Warning
    -------
    This mapping function requires functions from the `tofa` package.

    Example
    -------
    This example displays the mapping of a Ti-:math:`\omega` structure onto a BCC lattice::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.utils.mapping import robust_map

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Ti"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[["Ti"]])

        >>> # Omega structure to be mapped
        >>> structure = Structure([[4, 0, 0], [2, np.sqrt(3) * 2, 0], [0, 0, 3]],
        ...                       ["Ti"] * 3,
        ...                       [[0, 0, 0], [1 / 3, 1 / 3, 0.5], [2 / 3, 2 / 3, 0.5]])

        >>> # Mapping (de Fontaine-Silcock transformation pathway)
        >>> mapping = robust_map(structure, bcc)
        >>> # Mapped structure
        >>> print(mapping[0])
        >>> # Transformation
        >>> mapping[1]
        array([[ 0, -1,  0],
               [-2, -1, -1],
               [ 1,  0, -1]])
    """
    try:
        from tofa.mapping import mapping, metrics
    except ModuleNotFoundError as exc:
        raise ImportError(
            "The 'tofa' package is required for utils.mapping but is not installed."
        ) from exc

    prim_structure = Structure.from_dict(prim.structure.as_dict()["structure"])

    list_maps = mapping.mapping_driver(
        prim_structure,
        structure,
        vac_concentration_max=vac_concentration_max,
        vac_concentration_min=vac_concentration_min,
        fixed_child_size=fixed_size,
        lattice_weight=lattice_weight,
        symprec=symprec,
        angle_tolerance=angle_tolerance,
    )

    if len(list_maps) == 0:
        raise RuntimeError(
            "Impossible to find a supercell of the prim structure that matches the input structure."
        )

    mapped_structure = Structure.from_dict(
        list_maps[0]["structures"]["parent_structure"]
    )
    transformation = prim.get_supercell_transformation(mapped_structure.lattice.matrix)

    deformation = list_maps[0]["lattice"]["deformation"]
    if not np.allclose(
        (
            metrics.deformation_cost(deformation)
            + metrics.deformation_cost(np.linalg.inv(deformation))
        )
        / 2,
        list_maps[0]["cost"]["lattice_cost"],
    ):
        print("Deformation")
        raise RuntimeError(
            "The deformation does not yield the same atomic cost as the mapping function."
        )

    displacement = np.zeros(len(mapped_structure))
    displacement[: len(structure)] = np.linalg.norm(
        list_maps[0]["basis"]["displacement"] @ mapped_structure.lattice.matrix,
        axis=-1,
    )
    if not np.allclose(
        metrics.displacement_cost(displacement, mapped_structure),
        list_maps[0]["cost"]["atomic_cost"],
        atol=1e-4,
    ):
        print(
            "Displacement:\n",
            metrics.displacement_cost(displacement, mapped_structure),
            list_maps[0]["cost"]["atomic_cost"],
        )
        raise RuntimeError(
            "The displacement does not yield the same atomic cost as the mapping function."
        )

    # Check multiplicity of mapping
    costs = np.array([m["cost"]["total_cost"] for m in list_maps])
    costs -= costs[0]
    multiplicity = np.abs(costs) < 1e-6
    if multiplicity.sum() > 1:
        warnings.warn("Multiple optimal mappings were identified")
        if unique:
            raise RuntimeError("Mapping is not unique")

    return mapped_structure, transformation, deformation, displacement


def calculate_wigner_seitz_radius(structure: Structure) -> float:
    """Calculate the Wigner-Seitz radius of an atomic structure.

    Parameters
    ----------
    structure : Structure
        Pymatgen structure.

    Returns
    -------
    radius : float
        Wigner-Seitz radius of the atomic structure.
    """
    radius = np.cbrt(3.0 / (4.0 * np.pi) * structure.volume / len(structure))
    return radius


def deformation_cost(
    deformation_matrix: NDArray[np.floating],
) -> NDArray[np.floating]:
    """Calculates mapping costs for a deformation matrix using svd to compute the stretch tensor.

    Parameters
    ----------
    deformation_matrix : np.ndarray[float]
        Numpy array of [...]X3x3 matrix of the deformation (in row-wise convension).

    Returns
    -------
    mapping_cost : np.ndarray[float]
        Numpy array of real positive number of the deformation costs.
    """

    # Computing the sigular values of F is sufficient as the trace operator is used for the final cost
    stretch = np.linalg.svd(deformation_matrix, compute_uv=False)

    # Normalize the stretch by deviding by the determinant**(1/3) (since strech is a diagonal vector, divide by the product**(1/3) 1 in practice)
    stretch /= np.expand_dims(np.cbrt(np.prod(stretch, axis=-1)), axis=-1)

    # The biot strain V - I (since strech is a diagonal vector, substract 1 in practice)
    biot_strain = stretch - 1

    # Calculating the mapping costs tr(B.T B) (since strain is a diagonal vector, take the mean of the diagonal**2 in practice)
    mapping_cost = np.mean(biot_strain**2, axis=-1)

    return mapping_cost


def displacement_cost(
    displacement_vector: NDArray[np.floating], structure: Structure
) -> float:
    """Calculates mapping costs for a displacement matrix.

    Parameters
    ----------
    displacement_vector : np.ndarray[float]
        (Nx3)-numpy array of atomic displacements with N being the number of atoms.
    structure : Structure
        Pymatgen structure.

    Returns
    -------
    mapping_cost : float
        Real positive number of the displacement costs.
    """

    #  average square displacement
    mean_square_disp = np.mean(displacement_vector**2)

    # Wigner-Seitz radius
    ws_radius = calculate_wigner_seitz_radius(structure)

    # Calculating the mapping costs
    mapping_cost = mean_square_disp / ws_radius**2

    return mapping_cost


def check_mapping(
    structure: Structure,
    mapped_structure: Structure,
    deformation: np.ndarray,
    displacements: np.ndarray,
    max_deformation: float = 0.2,
    max_displacement: float = 0.5,
    lattice_weight: float = 0.5,
    max_mapping_cost: float = 0.01,
    vac_concentration_max: float = 0.0,
    vac_concentration_min: float = 0.0,
) -> None:
    """
    Checks if a mapping satisfies some requirements (deformation, displacement, vacancy concentration).

    Several mapping algorithms are implemented in this module. Some of them relies on strong assumptions (e.g., small deformations or no common rigid translation). This functions tries to prevent mappings that are inconsistent with these assumptions. If the mapping does not meet all requirements, the function raises an error.

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure)
    mapped_structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ after mapping
    deformation: np.ndarray
        Numpy array of deformation tensor from the Prim to the stucture (in row-wise convention)
    displacements: np.ndarray
        Numpy array of the displacement from the sites in Prim to the sites in the stucture (in row-wise convention)
    max_deformation: float, default: 0.2
        Maximum deformation allowed (eigenvalues)
    max_displacement: float, default: 0.5
        Maximum atomic displacement allowed in Angstroms
    lattice_weight : float, default: 0.5
        Weighting factor ([0,1]) for the lattice mapping cost in the total cost calculation.
    max_mapping_cost: float, default: 0.01
        Maximum mapping cost allowed, computed as in `Comparing crystal structures with symmetry and geometry <https://www.nature.com/articles/s41524-021-00627-0>`_.
    vac_concentration_max: float, default: 0.0
        Maximum vacancy concentration allowed in the child structure.
    vac_concentration_min: float, default: 0.0
        Minimum vacancy concentration allowed in the child structure.
    """

    vac_concentration = (len(mapped_structure) - len(structure)) / len(mapped_structure)

    if not np.all(np.abs(np.abs(np.linalg.eig(deformation)[0]) - 1) < max_deformation):
        raise RuntimeError("Lattice deformation too large")

    if not np.all(displacements < max_displacement):
        raise RuntimeError("Atomic displacement too large")

    lattice_cost = (
        deformation_cost(deformation) + deformation_cost(np.linalg.inv(deformation))
    ) / 2
    basis_cost = displacement_cost(displacements, mapped_structure)
    total_cost = lattice_weight * lattice_cost + (1 - lattice_weight) * basis_cost
    if total_cost > max_mapping_cost:
        raise RuntimeError("Mapping cost too large")

    if vac_concentration < vac_concentration_min:
        raise RuntimeError("Vacancy concentration too small")

    if vac_concentration > vac_concentration_max:
        raise RuntimeError("Vacancy concentration too large")

    return


def check_pass(*args) -> None:
    """
    Checking function that accept anything.
    To be used for structure generated on the ideal lattice.
    """
    return


def map_to_prototypes(
    structure: Structure,
    list_prims: list[Prim],
    list_mapping_methods: list[Callable] = [quick_map],
    critical_cost: float = -1.0,
    lattice_weight: float = 0.5,
) -> dict:
    """
    Performs a mapping analysis of a structure to a list of Prim structures, using different mapping functions.

    Parameters
    ----------
    structure: Structure
        `Pymatgen structure <https://pymatgen.org/pymatgen.core.html#pymatgen.core.structure.Structure>`_ to map (child structure).
    list_prims: list[Prim]
        List of Prim object containing all references to the lattice (parent structure).
    list_mapping_methods: list[Callable], default: [quick_map]
        List of the different mapping functions to call.
        The mapping functions will be evaluated if and only if none of the previous mapping functions resulted in a cost lower than the critical value.
        The mapping functions must only accept as input: structure (Structure) and prim (Prim).
    critical_cost: float, default: -1.0
        Critical value of the total cost of the mapping to accept.
        The cost is evaluated as described in `Comparing crystal structures with symmetry and geometry <https://www.nature.com/articles/s41524-021-00627-0>`_
        If a map is found with a total cost below or equal to that critical cost, the following maps are not performed.

        Tip
        ---
        If you desire to perform all maps in order to compare the mapping, set `critical_weight` to a negative value.

    lattice_weight : float, default: 0.5
        Weighting factor ([0,1]) for the lattice mapping cost in the total cost calculation.

    Returns
    -------
    mapping_data: dict

    Warning
    -------
    This function requires functions from the `tofa` package.

    Example
    -------
    This example displays the mapping onto BCC and FCC of a B2-like structure that is stretched along one axis (the structure lies between an ideal B2 structure on BCC and an ideal L10 structure on FCC)::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.core.prim import Prim
        >>> from pyece.utils.mapping import map_to_prototypes

        >>> # BCC primitive structure
        >>> bcc_lattice = np.array([[-2, 2, 2], [2, -2, 2], [2, 2, -2]])
        >>> bcc_structure = Structure(bcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> bcc = Prim(structure=bcc_structure,
        ...            allowed_elements=[["Fe", "Al"]])

        >>> # FCC primitive structure
        >>> fcc_lattice = np.array([[0, 2, 2], [2, 0, 2], [2, 2, 0]])
        >>> fcc_structure = Structure(fcc_lattice, ["Fe"], [[0, 0, 0]])
        >>> fcc = Prim(structure=fcc_structure,
        ...            allowed_elements=[["Fe", "Al"]])

        >>> # Elongated B2 structure
        >>> deformation = np.diag([1.1, np.sqrt(1 / 1.1), np.sqrt(1 / 1.1)])
        >>> transformation = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]])
        >>> lattice = transformation @ bcc_lattice @ deformation
        >>> structure = Structure(lattice, ["Fe", "Al"], [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
        >>> lattice
        np.array([[4.40000000, 0.00000000, 0.00000000],
                  [0.00000000, 3.81385036, 0.00000000],
                  [0.00000000, 0.00000000, 3.81385036]])

        >>> # Mapping to primitive BCC and FCC with robust_map
        >>> mapping = map_to_prototypes(structure, [bcc, fcc])
        >>> # Mapping to BCC
        >>> mapping["prim_0"]["robust_map"]["costs"]
        {'lattice': 0.004560088554793343, 'basis': 0.0, 'total': 0.0022800442773966713}
        >>> mapping["prim_0"]["robust_map"]["mapped_structure"]
        Al1 Fe1
        1.0
        4.0000000000000000   -0.0000000000000000   -0.0000000000000000
        -0.0000000000000000    4.0000000000000000   -0.0000000000000000
        -0.0000000000000000   -0.0000000000000000    4.0000000000000000
        Al Fe
        1 1
        direct
        0.0000000000000000    0.0000000000000000    0.0000000000000000 Al
        0.5000000000000000    0.5000000000000000    0.5000000000000000 Fe
        >>> # Mapping to FCC
        >>> mapping["prim_1"]["robust_map"]["costs"]
        {'lattice': 0.009286968957981145, 'basis': 0.0, 'total': 0.004643484478990573}
        >>> mapping["prim_1"]["robust_map"]["mapped_structure"]
        Al1 Fe1
        1.0
        2.0000000000000000   -0.0000000000000000    2.0000000000000000
        2.0000000000000000   -0.0000000000000000   -2.0000000000000000
        -0.0000000000000000    4.0000000000000000   -0.0000000000000000
        Al Fe
        1 1
        direct
        0.0000000000000000    0.0000000000000000    0.0000000000000000 Al
        0.5000000000000000    0.5000000000000000    0.5000000000000000 Fe

    """

    mapping_data: dict[str, dict[str, dict[str, object]]] = {}
    for prim_index, prim in enumerate(list_prims):
        list_mappings: dict[str, dict[str, object]] = {}
        for map_fn in list_mapping_methods:
            print("\n", prim_index, map_fn.__qualname__)
            prototype_mapping: dict[str, object] = {}
            prototype_mapping = {"is_map": False}

            try:
                (
                    mapped_structure,
                    _,
                    deformation,
                    displacements,
                ) = map_fn(structure, prim)
                lattice_cost = (
                    deformation_cost(deformation)
                    + deformation_cost(np.linalg.inv(deformation))
                ) / 2
                basis_cost = displacement_cost(displacements, mapped_structure)
                total_cost = (
                    lattice_weight * lattice_cost + (1 - lattice_weight) * basis_cost
                )
                prototype_mapping["costs"] = {
                    "lattice": lattice_cost,
                    "basis": basis_cost,
                    "total": total_cost,
                }
                prototype_mapping["mapped_structure"] = mapped_structure.to_file(
                    fmt="poscar"
                )
                if total_cost < critical_cost:
                    prototype_mapping["is_map"] = True
                    break

            except (ValueError, RuntimeError) as except_err:
                prototype_mapping["mapping_error"] = str(except_err)
                print(except_err)
                continue

            finally:
                list_mappings[map_fn.__qualname__] = prototype_mapping
        mapping_data["prim_%d" % prim_index] = list_mappings
    return mapping_data
