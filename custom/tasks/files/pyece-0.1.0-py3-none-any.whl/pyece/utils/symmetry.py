import numpy as np
from numpy.typing import NDArray
from pymatgen.core.structure import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

from pyece.utils import coordinates, toolbox


def generate_rotation_matrices(
    structure: Structure,
    cartesian: bool = False,
    symprec: float = 0.01,
    angle_tolerance: float = 0.1,
):
    """
    Obtain all rotation matrices from the primitive structure using space group analyzer from pymatgen (see `SpacegroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_).

    Parameters
    ----------
    parent_structure: Structure
        Pymatgen structure
    cartesian: bool, default: False
        Boolean structure to set to True if one desires the rotation matrices in cartesian coordinates, or set it to False if fractional coordinates is desired.
    symprec: float, default: 0.01
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.
    angle_tolerance: float, default: 0.1
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.

    Returns
    -------
    np.ndarray
        Numpy array of rotation matrices obatined from the primitive strucutre.

    Warning
    -------
    All matrices respect the row-wise convention (row vectors).
    """

    # finding point group operations
    finder = SpacegroupAnalyzer(
        structure, symprec=symprec, angle_tolerance=angle_tolerance
    )
    operations = finder.get_point_group_operations(cartesian=cartesian)

    # get rotation matrices
    rotation_matrices = []

    for symmop in operations:
        rotation_matrices.append(symmop.rotation_matrix.T)

    return np.array(rotation_matrices)


def generate_spacegroup_matrices(
    structure: Structure,
    cartesian: bool = False,
    symprec: float = 0.01,
    angle_tolerance: float = 0.1,
):
    """
    Obtain all affine symmetry operation matrices from the primitive structure using space group analyzer from pymatgen (see `SpacegroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_).

    Parameters
    ----------
    parent_structure: Structure
        Pymatgen structure
    cartesian: bool, default: False
        Boolean structure to set to True if one desires the symmetry operation matrices in cartesian coordinates, or set it to False if fractional coordinates is desired.
    symprec: float, default: 0.01
        Tolerance for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.
    angle_tolerance: float, default: 0.1
        Angle tolerance (in degrees) for symmetry finding used in `Pymatgen SpaceGroupAnalyzer <https://pymatgen.org/pymatgen.symmetry.html#pymatgen.symmetry.analyzer.SpacegroupAnalyzer>`_.

    Returns
    -------
    np.ndarray
        Numpy array of affine symmetry matrices, defined up to lattice translation, obtained from the primitive strucutre.

    Warning
    -------
    All matrices respect the row-wise convention (row vectors).
    """

    # finding point group operations
    finder = SpacegroupAnalyzer(
        structure, symprec=symprec, angle_tolerance=angle_tolerance
    )
    operations = finder.get_symmetry_operations(cartesian=cartesian)

    # get rotation matrices
    symmetry_matrices = []

    for symmop in operations:
        symmetry_matrices.append(symmop.affine_matrix.T)

    return np.array(symmetry_matrices)


def get_multiplication_table(group: np.ndarray, decimals: int = 6) -> NDArray[np.int_]:
    """
    Construct the multiplication table (Cayley table) of an array containing the spacegroup symmetry operations.

    Parameters
    ----------
    group: np.ndarray
        Nx4x4 numpy array of the spacegroup operation matrices, defined up to lattice translation, in fractional affine format, where N is the group order.
    decimals: int, default: 6
        Number of decimals to be round off.

    Returns
    -------
    multiplication_table: np.ndarray[int]
        Integer numpy array of the indexes of the resulting matrix of the multiplication of the matrices i and j.
    """

    def check_table(indexes: tuple, group_size: int) -> None:
        """
        Check closure

        In order for a set of elements to form a group, the multiplication table must satisfy some requirements:
            - Each row contains all elements once and only once
            - Each column contains all elements once and only once
        The input indexes contains the row and column indexes. To check closure it is sufficient to check that the row and column indexes contain all indexes from 0 to group_size -1.
        """
        unique1 = np.unique(indexes[0])
        unique2 = np.unique(indexes[1])
        if (len(unique1) != group_size) or (len(unique2) != group_size):
            print(indexes)
            raise ValueError(
                "Multiplication table error: unable to find the group multiplication table"
            )
        return

    multiplication = group[:, np.newaxis] @ group[np.newaxis, :]
    multiplication[:, :, -1, :-1] = toolbox.within(
        multiplication[:, :, -1, :-1], decimals=decimals
    )
    multiplication_table = -np.ones((len(group), len(group)), dtype=int)
    for symmop_index, symmop in enumerate(group):
        indexes = toolbox.find(multiplication, symmop, 10**-decimals)
        check_table(indexes, len(group))
        multiplication_table[indexes[0], indexes[1]] = symmop_index
    return multiplication_table


def get_cosets(
    multiplication_table: NDArray[np.int_], subgroup_indexes: NDArray[np.int_]
) -> NDArray[np.int_]:
    """
    Construct the left cosets out of a multiplication table and the indexes of the operation belonging to the subgroup.

    Parameters
    ----------
    multiplication_table: np.ndarray[int]
        Integer numpy array of the indexes of the resulting matrix of the multiplication of the matrices i and j.
    subgroup_indexes: np.ndarray[int]
        Integer numpy array with the indexes of the symmetry operation belonging in the subgroup.

    Returns
    -------
    cosets: np.ndarray[int]
        Integer numpy array of the indexes of symmetry operations where each row correponds to a coset.
    """

    def check_cosets(
        cosets: NDArray[np.int_], multiplication_table: NDArray[np.int_]
    ) -> None:
        """
        Check closure

        Ckeck that all elements in the group are present once and once only. Elements can only be present in one unique coset, and can only be present once in this coset.
        """
        unique = np.unique(cosets.flatten())
        if len(unique) != len(multiplication_table):
            print(cosets)
            raise ValueError("Elements in each coset are not unique")
        return

    assert np.all(
        multiplication_table >= 0
    ), "Incorrect multiplication table, negative indexes detected."

    # Cosets matrix
    N = len(subgroup_indexes)
    M = len(multiplication_table)
    C = int(M / N)
    cosets = np.zeros((C, N), dtype=int)

    # Loop over group to fill cosets
    counter = 0
    mask = np.ones(M, dtype=bool)
    while np.sum(mask) != 0:
        symmop_index = np.nonzero(mask)[0][0]
        coset_indexes = multiplication_table[subgroup_indexes, symmop_index]
        mask[coset_indexes] = False
        cosets[counter] = coset_indexes
        counter += 1

    # Check cosets
    check_cosets(cosets, multiplication_table)

    return cosets


def group_action(group: np.ndarray, set_points: np.ndarray) -> np.ndarray:
    """
    Apply all symmetry operations of a spacegroup to a set of points (See :doc:`description`).

    Parameters
    ----------
    group: np.ndarray
        Nx4x4 numpy array of the spacegroup operation matrices, defined up to lattice translation, in fractional affine format, where N is the group order (number of elements in the group).
    set_points: np.ndarray
        Mx3 numpy array of a set of points in fractional coordinates, defined up to lattice translation, where M is the set order (number of points in the set).

    Returns
    -------
    np.ndarray
        Numpy array of unicell coordinates of all points in the set applied to all group symmetry operations (group.shape + set_points.shape)

    Examples
    --------
    The following example illustrate the unique set of points (orbit) of the group action of a set of points corresponding to the nearest neighbor pair cluster of a BCC structure::

        >>> import numpy as np
        >>> from pymatgen.core import Structure
        >>> from pyece.utils.symmetry import generate_spacegroup_matrices, group_action

        >>> bcc = Structure([[-1, 1, 1], [1, -1, 1], [1, 1, -1]],
        ...                       ["Fe"],
        ...                       [[0, 0, 0]])
        >>> sg = generate_spacegroup_matrices(bcc)
        >>> len(sg)
        48
        >>> ga = group_action(sg, NN_pair)
        >>> len(ga)
        48
        >>> np.unique(ga)
        np.array([[[ 0.  0.  0.],
                   [-1. -1. -1.]],
                  [[ 0.  0.  0.],
                   [-1.  0.  0.]],
                  [[ 0.  0.  0.],
                   [ 0. -1.  0.]],
                  [[ 0.  0.  0.],
                   [ 0.  0. -1.]],
                  [[ 0.  0.  0.],
                   [ 0.  0.  1.]],
                  [[ 0.  0.  0.],
                   [ 0.  1.  0.]],
                  [[ 0.  0.  0.],
                   [ 1.  0.  0.]],
                  [[ 0.  0.  0.],
                   [ 1.  1.  1.]]])
    """

    assert (
        set_points.shape[-1] == 3
    ), "The set_points array is in fractional coordinates and is required to have a last dimension of size 3."

    # Affine coordinates
    set_points = coordinates.to_affine(set_points)

    # Symmetry operations
    array_group_action = set_points @ group

    array_group_action = coordinates.from_affine(array_group_action)
    return array_group_action
