import numpy as np
from torch import Tensor


def is_integer(array: np.ndarray) -> np.bool_:
    """
    Checks if the array is composed of integers

    Parameters
    ----------
    array: np.ndarray
        Numpy array to be checked

    Returns
    -------
    bool
        Boolean value being True if the array is entirely made of integers.
    """
    return np.all(np.equal(np.mod(array, 1), 0))


def within(array: np.ndarray, decimals: int = 6) -> np.ndarray:
    """
    Wrap the values of an array within [0,1[.

    Parameters
    ----------
    array: np.ndarray
        Numpy array to be modified
    decimals: int, default: 6
        Number of decimals to be round off.

    Returns
    -------
    np.ndarray
        Numpy array with values within [0,1[.
    """
    array = np.around(array, decimals=decimals)
    return np.mod(array, 1.0)


def find(array: np.ndarray, x: np.ndarray, tolerance: float = 1e-6) -> tuple:
    """
    Find the indexes of all elements in array equal to the search element x, given a tolerance. The search element x must correspond to the innermost dimensions of the array.

    Parameters
    ----------
    array: np.ndarray
        Numpy array to search the search element x within. The innermost dimensions must be the same as the dimensions of x
    x: np.ndarray
        Numpy array of the element x to be searched
    tolerance: float, default: 1e-6
        Tolerance in the equality

    Returns
    -------
    tuple
        Indices of elements in array that are equal to x.

    Example
    -------
    Various examples of searches of elements of different ranks (from rank 0 to rank 2)::

        >>> import numpy as np
        >>> from pyece.utils.toolbox import find

        >>> # x = rank 0; array = rank 2
        >>> array = np.array([[0.111, -0.300, 0.123, 0.873, 0.631],
        ...                   [0.324, 0.873, -0.540, 0.173, 0.305]])
        >>> x = np.array(0.873)
        >>> find(array, x)
        (array([0, 1]), array([3, 1]))

        >>> # x = rank 1; array = rank 3
        >>> array = np.array([[[1, 0, 3], [-1, 2, 3]],
        ...                   [[1, 2, 3], [-1, 2, 1]],
        ...                   [[3, 2, 1], [ 3, 1, 2]],
        ...                   [[1, 0, 3], [ 1, 2, 3]]])
        >>> x = np.array([1, 2, 3])
        >>> find(array, x)
        (array([1, 3]), array([0, 1]))

        >>> # x = rank 2; array = rank 3
        >>> array = np.array([[[0.1, -0.2, 0.1], [ 0.4,  1.3, -0.9]],
        ...                   [[0.9,  0.1, 0.2], [-0.3, -0.3,  1.0]],
        ...                   [[0.2, -0.1, 0.6], [-0.1, -0.8,  2.4]],
        ...                   [[0.9,  0.1, 0.2], [-0.3, -0.3,  1.0]]])
        >>> x = np.array([[0.9, 0.1, 0.2], [-0.3, -0.3, 1.0]])
        >>> find(array, x)
        (array([1, 3]),)

    """
    rank_x = len(x.shape)
    assert rank_x <= len(array.shape), "The array must be of rank greater or equal to x"
    assert (rank_x == 0) or np.allclose(
        x.shape, array.shape[-rank_x:]
    ), "The innermost dimensions of the array must be the same as the those of x"

    return np.nonzero(
        (
            np.linalg.norm(array - x, axis=tuple(-np.arange(1, rank_x + 1)))
            if rank_x > 0
            else np.abs(array - x)
        )
        < tolerance
    )


def segment(src: Tensor, ptr: Tensor, reduce: str = "sum") -> Tensor:
    """
    Reduces all values in the last dimension of a source tensor within the ranges specified in a pointer tensor.

    Parameters
    ----------
    src: Tensor
        Pytorch tensor with the source tensor
    ptr: Tensor
        Integer pytorch tensor of a monotonically increasing pointer tensor that refers to the boundaries of segments such that :obj:`ptr[0] = 0` and :obj:`ptr[-1] = src.size(0)` (see `Compressed Sparse Row (CSR) <https://en.wikipedia.org/wiki/Sparse_matrix#Compressed_sparse_row_(CSR,_CRS_or_Yale_format)>`_).
    reduce: str, default = \'sum\'
        String with the reduction method to be chosen between \'sum\' and \'mean\'.

    Example
    -------
    An example of the segment reduction of a rank 2 tensor::

        >>> from torch import tensor
        >>> from pyece.utils.toolbox import segment

        >>> src = tensor([[ 1,  2,  3,  4,  5,  6,  7,  8],
        ...               [ 1, -3,  4,  6, -8,  2,  5,  5],
        ...               [ 0,  3, -1, -5,  9, -7,  3,  2]]).float()
        >>> ptr = tensor([0, 3, 4, 7])
        >>> segment(src, ptr)
        tensor([[ 6.,  4., 18.],
                [ 2.,  6., -1.],
                [ 2., -5.,  5.]])
        >>> segment(src, ptr, reduce="mean")
        tensor([[ 2.0000,  4.0000,  6.0000],
                [ 0.6667,  6.0000, -0.3333],
                [ 0.6667, -5.0000,  1.6667]])

    """
    dim = -1
    cumsrc = src.cumsum(dim=dim)[..., ptr - 1]
    cumsrc[..., 0] = 0
    reduced_src = cumsrc[..., 1:] - cumsrc[..., :-1]
    if reduce == "mean":
        reduced_src[..., :] /= ptr[1:] - ptr[:-1]
    return reduced_src


def merge_dict(base_dict: dict, dict_to_add: dict) -> dict:
    """
    Merges two dictionaries together, keys present in both dictionaries are gathered as lists.

    Parameters
    ----------
    base_dict: dict
        Base dictionary.
    dict_to_add: dict
        Dictionary to be added to the base dictionary.

    Returns
    -------
    dict
        Merged dictionary
    """
    base_dict.update(
        {
            key: (
                base_dict[key] + [dict_to_add[key]]
                if key in base_dict
                else [dict_to_add[key]]
            )
            for key in dict_to_add
        }
    )
    return base_dict
